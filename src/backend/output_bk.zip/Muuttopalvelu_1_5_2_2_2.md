##### 1.5.2.2.2 Muuttopalvelu
Pääsääntöisesti muutto tulee toteuttaa omatoimimuuttona. Erityisen painavalla perusteella asiakkaalle voidaan myöntää maksusitoumus Kelan kilpailuttamiin muuttopalveluihin . Tällöinkin edellytetään, että muuttoa voidaan pitää perusteltuna. Jos asiakkaalle myönnetään muuttopalvelu ei muuttorahaa huomioida menona.
Jos asiakas hakee muuttopalvelua, tulee häneltä selvittää:
 - pystyykö hän toteuttamaan muuton itse ja
 - onko hänellä omaisia tai muuta verkostoa, jotka voisivat auttaa muuton toteuttamisessa, esimerkiksi muita perheen jäseniä, asiakkaan aikuisia lapsia, ystäviä, naapureita tai muita vastaavia henkilöitä.

Asiakkaan tulee esittää erityiset perusteet siitä, ettei hän pysty hoitamaan tai järjestämään muuttoa omatoimisesti. Erityisperusteena voidaan pitää esimerkiksi tilannetta, jossa asiakkaalla on sairaus, joka estää tai rajoittaa hänen mahdollisuuksiaan hoitaa muuttoa omatoimisesti, eikä hänellä ole omaisia tai muuta verkostoa, jotka voisivat auttaa muutossa. Terveydellisestä syystä on aina esitettävä lääkärintodistus, jos sellaista ei ole jo aiemmin toimitettu Kelaan. Jos muuttoajankohdan siirto mahdollistaa itsenäisen muuton toteuttamisen, muuttoajankohdan siirron mahdollisuus tulee selvittää.
Kun harkitaan, onko muuttopalvelun myöntämiseksi olemassa erityisen painavat perusteet, tulee asiakkaan tilanne arvioida aina tapauskohtaisesti ja kokonaisvaltaisesti ottaen huomioon:
 - asiakkaan terveydentila,
 - asiakkaan perheenjäsenten mahdollisuus hoitaa tai järjestää muutto,
 - mahdollisuudet saada apua muuttoon omaisilta tai muulta verkostolta sekä
 - muut asiassa esitetyt seikat.

Jos asiakas esittää itse maksaneensa muuttopalvelun, menoksi hyväksytään enintään se määrä, mikä hänelle olisi Kelan hankintamenettelyllä myönnetty. Tämä edellyttää kuitenkin, että muuttopalvelun käytölle on ollut edellä mainitut erityisen painavat perusteet. Jos muuttopalvelun käytölle ei ole ollut perusteita, voidaan muuttoa tukea omatoimimuuton muuttorahalla, jos sen myöntämisen edellytykset muutoin täyttyvät.
Kelan kilpailuttamat muuttopalvelut jaotellaan perusmuuttoon ja kokonaismuuttoon:
 - Perusmuutto voidaan myöntää tilanteessa, jossa asiakas perheineen ei erityisestä syystä pysty itse siirtämään ja kuljettamaan muutettavia tavaroita. Perusmuutto sisältää koti-irtaimiston siirron sovitusta lähtöosoitteesta huoneiston sisältä sovittuun kohdeosoitteeseen huoneiston sisälle. Perusmuutto sisältää myös muuttotavaroiden lastauksen ajoneuvoon, niiden purkamisen ajoneuvosta ja siirtämisen huoneiston sisälle kohdeosoitteessa. Perusmuutto ei sisällä tavaroiden pakkaamista eikä pakattujen tavaroiden purkamista.

 - Kokonaismuutto voidaan myöntää tilanteessa, jossa asiakas perheineen ei erityisen poikkeuksellisesta syystä kykene edellä mainitun lisäksi myöskään pakkaamaan muutettavia tavaroita. Kokonaismuutto sisältää perusmuuttoon kuuluvien palveluiden lisäksi muuttotavaroiden pakkauksen ja purkamisen.

Kela arvioi asiakkaan toimittamien selvitysten perusteella onko asiakkaalla tarve perusmuutolle vai kokonaismuutolle. Palveluntarjoaja määrittelee Kelasta ja asiakkaalta saamiensa tietojen pohjalta muuton tarkan ajankohdan ja vastaavat yksityiskohdat asiakkaan kanssa. Jos asiakas tarvitsee muuttolaatikoita, arvioi palveluntarjoaja muuttolaatikoiden määrän muutettavan asunnon koon perusteella. Muuttopalvelu toteutetaan yleensä arkipäivisin. Lue lisää muuttopalvelut – prosessista
