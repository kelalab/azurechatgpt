#### 1.6.8.1 Vangin tulot
Vangin perustoimeentulotukioikeutta arvioitaessa selvitetään tosiasiallisesti käytettävissä olevat tulot ja varat. Käyttöraha, toimintaraha, mahdollinen palkka sekä käytettävissä olevat muut tulot ovat laskelmassa huomioitavaa tuloa. Käyttö- ja toimintaraha maksetaan kerran kuukaudessa eikä niistä tehdä ansiotulovähennystä. Käytettävissä olevien tulojen ja varojen määrä tarkistetaan vankilan maksukortin tiliotteelta.
 - Käyttörahaa maksetaan vankeusrangaistuksen suoritustavasta riippumatta kaikille vangeille 1,60 euroa jokaiselta rangaistukseksi luettavalta päivältä, myös viikonlopuilta.
 - Jos vanki ei osallistu toimintaan, niin keskimäärin hän saa käyttörahaa 48 euroa/kk (30 pv x 1,60 e).

