#### 1.6.8.3 Muut perusmenot
Vangeille voidaan huomioida toimeentulotuen laskelmassa menona muihin perusmenoihin kuuluvia menoja, jos ne eivät kuulu vankilan järjestämään ylläpitoon.
