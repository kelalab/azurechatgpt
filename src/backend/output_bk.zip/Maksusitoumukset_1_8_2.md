### 1.8.2 Maksusitoumukset 
Maksusitoumus on asiakirja, jolla Kela sitoutuu maksamaan siinä määritellyn perustoimeentulotuessa huomioitavan tuotteen tai palvelun hakijan puolesta. Maksusitoumus on yksi maksun suorittamisen tapa. Maksusitoumuksella varmistetaan, että hakija tosiasiallisesti saa tarvitsemansa palvelun tai tuotteen hankittua. Maksusitoumuksella katetaan tuote tai palvelu kokonaan tai osittain. Palveluntuottaja tai muu taho voi laskuttaa Kelalta maksusitoumuksessa määritellyn tuotteen tai palvelun. Maksusitoumus voidaan myöntää hakijalle tai hänen perheenjäsenelleen, ja se lähetetään yleensä etuuspäätöksen mukana hakijalle. Lue lisää päätöksen antamisesta . Maksusitoumuksen käyttö edellyttää henkilöllisyyden todistamista. Maksusitoumuksesta ei anneta rahaa takaisin. 
Jos hakijalla on edunvalvoja, maksusitoumus lähetetään yleensä hakijalle. Edunvalvoja saa tiedon maksusitoumuksesta päätöksestä. Edunvalvojan tai edunvalvontavaltuutetun pyynnöstä maksusitoumus voidaan toimittaa asiakkaan sijasta edunvalvojalle tai edunvalvontavaltuutetulle. 
Maksusitoumuksen käyttö edellyttää henkilöllisyyden todistamista. Maksusitoumuksesta ei anneta rahaa takaisin. 
Maksusitoumuksia voidaan myöntää esimerkiksi seuraaviin menoihin: 
 - Elintarvikkeet, katso tarkemmin Maksusitoumus elintarvikkeisiin –prosessi 
 - Lääkekustannukset, katso tarkemmin Yleiset lääkeasiat –prosessi ja Keskitetyt lääkeasiat -prosessi 
 - Proteettisen hammashoidon hammasteknisen työn kustannukset. Katso tarkemmin Hammasproteesit - prosessi 
 - Silmälasi- ja silmälääkärikustannukset. Katso tarkemmin Optikkopalvelut –prosessi, kaikki käsittelijät ja Optikkopalvelut –prosessi, keskitetyt käsittelijät 
 - Terveydenhuollon matkat, juna- ja lentomatka , linja-automatka ja taksimatka . 
 - Henkilöasiakirjat, katso tarkemmin Henkilöasiakirjat-prosessi 
 - Muuttokulut, katso tarkemmin Muuttopalvelut - prosessi 
 - Vuokravakuus, katso tarkemmin Vuokravakuus –prosessi 
 - Kotivakuutus, katso tarkemmin Kotivakuutus maksusitoumuksena -prosessi 
 - Sähkövakuus, katso tarkemmin Sähkövakuus - prosessi 

