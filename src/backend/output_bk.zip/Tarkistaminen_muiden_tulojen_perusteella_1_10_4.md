### 1.10.4 Tarkistaminen muiden tulojen perusteella
Etuus- ja ansiotulojen lisäksi asiakkaalla voi olla myös muita tuloja. Asiakas voi esimerkiksi saada vähäistä suurempia avustuksia vanhemmiltaan tai pelivoittoja. Jos muu tulo ei ole ollut tiedossa toimeentulotuesta päätettäessä, se voidaan ottaa tietyin edellytyksin jälkikäteen huomioon, jos toimeentulotukea haetaan päätöstä seuraavien kahden kalenterikuukauden aikana. Jos muu tulo ei ole ollut tiedossa toimeentulotuesta päätettäessä, voidaan se myös huomioida sen maksukuukauden päätökselle, jos kyseistä päätöstä samalla tarkistetaan. 
Lue lisää tulon jälkikäteisestä huomioimisesta ja tulon tarkistamisesta maksukuukaudelle .

