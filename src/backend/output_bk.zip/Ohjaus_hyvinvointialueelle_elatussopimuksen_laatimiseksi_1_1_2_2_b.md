##### 1.1.2.2.b Ohjaus hyvinvointialueelle elatussopimuksen laatimiseksi
Asiakasta voidaan tietyissä tilanteissa ohjata hyvinvointialueelle  laatimaan ja vahvistamaan elatussopimus:
 - vanhempi ei maksa elatusapua tai maksettavan elatusavun määrä on selvästi liian vähäinen hänen elatuskykyynsä nähden, eikä elatusavusta ole aiemmin vahvistettu sopimusta tai annettu päätöstä.
 - vanhemmat ovat keskenään sopineet elatusmaksun suuruudesta ja elatusvelvollisella olisi enemmän elatuskykyä.
 - vanhemmat ovat keskenään sopineet elatusmaksun suuruudesta ja sovitun elatusavun suuruus on pienempi kuin elatustuki (186,97 e/kk vuonna 2023), vaikka elatusavun maksajalla ei olisi enempää elatuskykyä. Kela voi maksaa elatustukea elatusavun lisäksi, jos elatusapu on vahvistettu elatustuen määrää pienemmäksi puutteellisen elatuskyvyn vuoksi.  Asiakasta ei kuitenkaan ohjata lastenvalvojalle, jos ero elatusavun ja elatustuen määrän välillä johtuu 1.1.2020 elatustukilain muutoksesta, elinkustannusindeksin noususta tai on muuten vähäinen. 

 - jos elatusapua maksavan vanhemman tulot ovat olennaisesti kasvaneet tai lapsen kanssa asuvan vanhemman tulot olennaisesti laskeneet elatussopimuksen vahvistamishetkestä, voidaan asiakasta ohjata tarkistamaan jo vahvistettu elatussopimus.
 - jos lastenvalvojan vahvistaman elatusavun määrä vaikuttaa olennaisesti liian alhaiselta elatusapua maksavan vanhemman elatuskykyyn nähden, voidaan asiakasta ohjata kuntaan tarkistamaan elatussopimus vastaamaan vanhemman todellista elatuskykyä.

