##### 1.5.4.3.1 Matkakustannusten huomioiminen etukäteen
Matkakustannukset voidaan huomioida etukäteen myöntämällä maksusitoumus tai huomioimalla meno tositetta vastaan laskelmassa.
Maksusitoumus voidaan myöntää:

 - Taksin omavastuuosuuteen Edellyttäen, että hakijalla on voimassa oleva todistus pitkäaikaisesta taksinkäytön tarpeesta tai todistus matkakorvausta varten (SV 67) tai puutteelliset liikenneolosuhteet ja hänen vuotuinen omavastuuosuutensa ei ole täyttynyt. Lue lisää taksimatka – prosessista.  Jos asiakas on kotiutumassa sairaalasta ja tarvitaan kiireellisesti maksusitoumus taksiin, katso menettely kiire-prosessista .


 - Linja-automatkaan Lue lisää linja-auto prosessista .


 - Juna- tai lentomatkaan Lue lisää juna- ja lentomatka – prosessista .



Matkakustannukset voidaan huomioida tositetta vastaan laskelmassa (ajanvarauskirje, lomake SV67 tai muu vastaava selvitys käynnistä), kun maksusitoumuksen myöntäminen ei ole mahdollista. Kulkuneuvona voi olla julkinen liikenne tai oma auto edellytysten täyttyessä.
Edellytykset oman auton käytöstä aiheutuneiden kustannusten hyväksymiselle:
 - yhdensuuntainen matka on alle 100 km
 - yhdensuuntainen matka on yli 100 km ja hakijalla on terveydenhuollon todistus (SV 67) tai puutteelliset liikenneolosuhteet tai
 - yhdensuuntainen matka on yli 100 km. Lääkärintodistusta ei tarvita, kun oman auton käyttämisestä aiheutuvat kustannukset ovat pienemmät kuin julkisella kulkuneuvolla tehdyn matkan.

Oman auton käytöstä huomioidaan sairausvakuutuslain mukainen korvaus 0,33 e/km. Katso myös oman auton käyttö – prosessi.

