##### 1.3.11.2.a Palkkatulot
Työnantajan ei tarvitse ilmoittaa tulorekisteriin eräitä palkasta tehtäviä vähennyksiä, esimerkiksi
 - ulosmittausta,
 - ammattiyhdistyksen ja työttömyyskassan jäsenmaksua tai
 - vähennysten jälkeistä maksettavaa palkan määrää.

Vapaaehtoisesti ilmoitettavilla tiedoilla voi olla kuitenkin välillistä merkitystä asian ratkaisemiseksi. Tiedoista voi olla pääteltävissä esimerkiksi hakijan yrittäjätoiminta, tulojen säännöllisyys tai niiden todellinen käytettävyys.
Jos työnantaja on toimittanut vapaaehtoisesti ilmoitettavana tietona tiedon ulosmittauksesta, saatetaan kuitenkin tarvita päätös ulosmittauksesta tai ulosottomiehen vahvistaman maksusuunnitelma. Lue lisää ulosotosta .
Perutoimeentulotulotuen ratkaisemiseksi merkityksellisiä vapaaehtoisesti ilmoitettavia tietoja voivat ovat:
 - palvelussuhteen tyyppi, kesto ja sen päättymisen syy
 - tulolajit sekä työaika- ja poikkeustilannekorvaukset
 - palkkauksen muoto; tuloerien ansainta-ajankohta
 - suorituksen kertaluonteisuus
 - vähennysten jälkeen maksettavan palkan määrä
 - osa-aikaisuus ja sovittu viikkotyöaika
 - palkallinen tai palkaton poissaolo
 - tieto siitä, että suoritus on maksettu muuna kuin rahana
 - suorituksen ulosmittaus
 - tulonsaajan osakkuusasema suhteessa suorituksen maksajaan.

