### 1.2.c Esimerkkejä menoista, joita voidaan tukea täydentävällä tai ehkäisevällä toimeentulotuella
Koska täydentävän ja ehkäisevän toimeentulotuen myöntämisessä voidaan käyttää laajaa harkintaa, hyvinvointialue voi harkintansa mukaan huomioida tuen myöntämisessä laajasti erilaisia menoja. Menoina voidaan harkinnalla huomioida esimerkiksi:
 - lapsen harrastemenot
 - huonekalut, kodinkoneet ja niihin rinnastuvat kodin hankinnat
 - lastenvaunut
 - toisen asteen ensimmäistä tutkintoa suorittavien nuorten opiskeluun liittyvät menot
 - edunvalvontapalkkio
 - hautajaiskulut
 - avopalveluista johtuvat, kuukausittain toistuvat menot, esimerkiksi ateria- ja siivouspalvelumaksu
 - poikkeuksellisen suuret vaatemenot
