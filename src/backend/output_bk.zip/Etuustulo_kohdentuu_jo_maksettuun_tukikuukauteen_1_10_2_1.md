#### 1.10.2.1 Etuustulo kohdentuu jo maksettuun tukikuukauteen
Jos etuustulo ei ole ollut tiedossa toimeentulotuesta päätettäessä, se voidaan ottaa tietyin edellytyksin jälkikäteen huomioon, jos toimeentulotukea haetaan päätöstä seuraavien kahden kalenterikuukauden aikana. Jos etuustulo ei ole ollut tiedossa toimeentulotuesta päätettäessä, voidaan etuustulo myös huomioida sen maksukuukauden päätökselle, jos kyseistä päätöstä samalla tarkistetaan. 
Lue lisää tulon jälkikäteisestä huomioimisesta ja tulon tarkistamisesta maksukuukaudelle .
