###### 1.5.1.4.6.b Vuokrankorotus tai perhekoon muutos
Vuokran määrän muuttuessa asumismenojen kohtuullisuutta tulee arvioida uudelleen.
Jos asunnossa asuvien henkilöiden lukumäärä muuttuu, siirrytään käyttämään uuden henkilömäärän mukaista asumisnormia ja tehdään asumismenojen kohtuullisuusarviointi uudelleen.
Jos asumismenot
 - on kohtuullistettu, annetaan 1 kuukauden järjestelyaika, jonka jälkeen asumismenot kohtuullistetaan vastaamaan uuden henkilömäärän mukaista asumisnormia.
 - on hyväksytty kokonaisuudessaan, annetaan kehotus etsiä edullisempaa asuntoa, jos perusteita korkeammille asumiskustannuksille henkilömäärän pienentyessä ei ole.

Jos asunnossa asuvien henkilöiden lukumäärä kasvaa, esimerkiksi lapsen syntymän johdosta, siirrytään käyttämään uuden henkilömäärän mukaista asumisnormia. Perhekoon kasvaminen ei kuitenkaan välttämättä tarkoita sitä, että perhe tarvitsee suuremman asunnon. Lue lisää muuton tukemisesta .
Jos asunnossa asuvien henkilöiden lukumäärä muuttuu kuoleman johdosta, tehdään asumismenojen kohtuullisuusarviointi uudelleen.
Jos asumismenot
 - on kohtuullistettu, annetaan tarvittaessa pidempi järjestelyaika (kuitenkin enintään 6 kuukautta).
 - on hyväksytty kokonaisuudessaan, annetaan kehotus etsiä edullisempaa asuntoa viimeistään 6 kuukauden kuluttua, jos perusteita korkeammille asumiskustannuksille henkilömäärän pienentyessä ei ole.

