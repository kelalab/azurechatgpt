### 1.12.3 Takaisinperinnän edellytykset ja esteet
Toimeentulotuen takaisinperintä edellyttää, että:
 - korvausvelvollisella on takaisinperinnästä päätettäessä tai myöhemmin sellaisia tuloja tai varoja, joista takaisinperittävä määrä voidaan periä ja
 - takaisinperintä ei vaaranna korvausvelvollisen tai sellaisen henkilön toimeentuloa, josta hän pitää huolta tai on velvollinen pitämään huolta.

Toimeentulotuen takaisinperinnän ei tule aiheuttaa tilannetta, jossa korvausvelvollinen tai hänestä riippuvaiset henkilöt joutuisivat takaisinperinnän johdosta uudelleen toimeentulotuen tarpeeseen, eli takaisinperintää ei esimerkiksi määrätä kohdistumaan asiakkaan tulevaan työsuhteeseen ja siitä saatavaan ansiotuloon.
Takaisinperintähakemus hallinto-oikeudelle laaditaan sen laatimisen aikaisten olosuhteiden perusteella ja tällöin myös arvioidaan täyttyvätkö takaisinperinnän edellytykset. Toimeentulotukipäätökseen lisättävän perintämääräyksen antamisen yhteydessä tilannetta ei tarvitse vielä arvioida.
Elatusvelvollisen laiminlyönnin ollessa kyseessä tulee takaisinperintähakemusta tehtäessä arvioida:
 - oliko elatusvelvollisella tuen myöntämisen ajankohtana riittävä elatuskyky sekä
 - onko elatusvelvollisella nyt hakemusta laadittaessa sellaisia tuloja tai varoja, joista tuki voidaan periä takaisin.

Elatusvelvollisen maksukykyä arvioitaessa ei voida huomioida sellaisia tuloja tai varoja, jotka eivät ole hänen käytettävissään tai joiden saamisesta ei ole varmuutta.
Sen sijaan, kun kyseessä on takaisinperintä asiakkaan tuloista tai varoista, jotka eivät ole suoraan asiakkaan käytettävissä (esimerkiksi kiinteistö tai osuus kuolinpesästä), on yleensä riittävää, että asiakkaalla on takaisinperintähakemusta tehtäessä edelleen oikeus kyseiseen omaisuuteen tai sen realisoimisesta saatuihin varoihin tai niiden tilalle tulleeseen omaisuuteen.
Korvausvelvollisen vakinaista asuntoa, tarpeellista asuinirtaimistoa tai tarpeellisia työvälineitä ei voida hänen elinaikanaan myydä pakkotoimin tai muutoin käyttää toimeentulotuen takaisinperintään. Tukea ei voida periä takaisin edellä mainituista varoista korvausvelvollisen kuoltuakaan, jos periminen vaarantaisi sellaisen henkilön toimeentuloa, josta hän on pitänyt huolta tai olisi ollut velvollinen pitämään huolta.
