#### 1.3.4.5 Vakuutuskorvaus, vahingonkorvaus ja rikosperusteinen korvaus
Vakuutuskorvaus, vahingonkorvaus ja rikosperusteinen korvaus huomioidaan yleensä kokonaisuudessaan tuloksi. Korvaus voidaan kuitenkin jättää huomioimatta tulona siltä osin kuin hakija on esittänyt selvityksen, että korvausta käytetään tai tullaan käyttämään rikoksesta tai vahingosta aiheutuneisiin menoihin, kuten terapiakustannuksiin tai tuhoutuneen irtaimiston uusimiseen.
Vakuutuskorvauksista, vahingonkorvauksista ja rikosperusteisista korvauksista otetaan tulona huomioon yksin asuvalta 50 euron ja toimeentulotukiperheeltä 100 euron yli menevä osuus.
>ESIMERKKI: Iirikselle on maksettu 20.5. kivusta ja särystä rikosvahingon korvauksena 450 euroa. Koska Iiris ei ole osoittanut käyttäneensä osaakaan saamastaan korvauksesta toimeentulotuessa hyväksyttäviin tarkoituksiin, korvauksesta huomioidaan vähäisen tulon vähennyksen jälkeen 400 euroa toukokuun laskelmalla tulona.

