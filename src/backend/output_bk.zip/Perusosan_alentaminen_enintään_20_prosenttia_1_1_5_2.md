#### 1.1.5.2 Perusosan alentaminen enintään 20 prosenttia
Asiakkaan perusosaa voidaan alentaa enintään 20 %, jos
 - asiakas ei ole ilmoittautunut työttömäksi työnhakijaksi. Yleensä asiakkaan voidaan edellyttää olevan kokoaikatyötä hakeva työtön työnhakija

 - asiakas on ilman perusteltua syytä kieltäytynyt yksilöidysti ja todistetusti tarjotusta työstä tai julkisesta työvoimapalvelusta, joka kohtuullisen pitkän (vähintään kuukauden) ajan turvaisi hänen toimeentulonsa
 - asiakas on laiminlyönnillään aiheuttanut sen, ettei työtä tai julkista työvoimapalvelua ole voitu tarjota
 - ammatillista koulutusta vailla oleva, 18–24 - vuotias asiakas, on keskeyttänyt koulutuksen tai kieltäytynyt koulutuksesta niin, että hän ei ole työttömyysturvalain 2 luvun 13 tai 14 §:n perusteella oikeutettu työttömyysetuuteen
 - Suomeen muuttanut henkilö, joka oleskelee maassa muuta kuin matkailua tai siihen verrattavaa lyhytaikaista oleskelua varten myönnetyllä luvalla tai jonka oleskeluoikeus on rekisteröity taikka jolle on myönnetty oleskelukortti, on ilman perusteltua syytä kieltäytynyt kotoutumissuunnitelman laatimisesta tai osallistumasta kotoutumissuunnitelmassa yksilöidysti sovittuihin, työllistymistä edistäviin toimenpiteisiin

 - edellä mainittu Suomeen muuttanut henkilö on laiminlyönnillään aiheuttanut sen, ettei kotoutumissuunnitelmaa ole voitu laatia
 - kuntouttavasta työtoiminnasta annetun lain 3 §:ssä tarkoitettu työtön työmarkkinatukeen oikeutettu tai toimeentulotukea työttömyyden johdosta saava asiakas on kieltäytynyt osallistumasta aktivointisuunnitelman tai monialaisen työllistymissuunnitelman laatimiseen. kieltäytynyt kuntouttavasta työtoiminnasta ilman työttömyysturvalain mukaista pätevää syytä keskeyttänyt tai omasta syystään joutunut keskeyttämään kuntouttavan työtoiminnan ilman työttömyysturvalain mukaista pätevää syytä.


Perustoimeentulotuen perusosaa on mahdollista alentaa vain, jos kaikki alentamiselle asetetut edellytykset täyttyvät. 
Katso myös kannattamaton yritystoiminta ja opiskelijan perusosan alentaminen .
