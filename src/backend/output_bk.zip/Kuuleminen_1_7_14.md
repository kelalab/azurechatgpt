### 1.7.14 Kuuleminen
Kuuleminen merkitsee tilaisuuden varaamista asiakkaalle esittää oma käsityksensä asiasta ennen sen ratkaisua. Asiakkaalla on oikeus saada tietoonsa asiassa kertynyt aineisto ja esittää saamiensa tietojen perusteella oma käsityksensä asiasta. Asiakkaan kuuleminen on keskeinen oikeussuojan tae. Se on hakemuksen ja siihen liittyvien selvitysten ohella keino hankkia tietoa oikeaan lopputulokseen pääsemiseksi ja palvelee osaltaan myös asian selvittämistä.
Lähtökohtana on kuulemisen ensisijaisuus ja kuulematta jättäminen voidaan tehdä vain erittäin poikkeuksellisesta syystä.
Perustoimeentulotuen ratkaisutoiminnassa kuuleminen tulee kyseeseen esimerkiksi seuraavissa tilanteissa:
 - takaisinperintä ja elatusvelvollisuus 
 - tarkistaminen vahingoksi 
 - perusosan alentaminen 
 - avo- ja avioliittotilanteet 

Lue tarkemmin tilanteista, joissa ei tarvitse kuulla .
