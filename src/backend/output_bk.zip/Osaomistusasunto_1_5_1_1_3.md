##### 1.5.1.1.3 Osaomistusasunto
Osaomistusasunnossa huomioitavia menoja ovat:
 - vuokra
 - erikseen maksettavat lämmitys- ja vesimaksut
 - saunamaksu

Osaomistukseen oikeuttavan osamaksun maksamista varten otettujen lainojen korkoja ei huomioida asumismenoiksi.
