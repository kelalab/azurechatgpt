## 1.9 Hyvinvointialueen kanssa tehtävä yhteistyö
Kelan ja hyvinvointialueen tulee tehdä yhteistyötä asiakkaiden ja heidän perheidensä toimeentulon turvaamiseksi ja itsenäisen selviytymisen edistämiseksi. Kelan on tarvittaessa ohjattava ja neuvottava perustoimeentulotuen hakijaa, miten hyvinvointialueen sosiaalihuollon palveluihin hakeudutaan. 
Kun perustoimeentulotuen käsittelyssä havaitaan, että on tarpeen saada sosiaalihuollon näkemys asiakkaan tilanteesta, voidaan ottaa yhteyttä hyvinvointialueen sosiaalihuoltoon. Samalla asiakkaalle tulee tiedottaa asiasta . 
Yhteistyö sosiaalihuollon kanssa voi toteutua esimerkiksi asiakkaan yhteisen tapaamisen, sosiaalihuollon lausunnon tai molempien mainittujen avulla. Sosiaalihuolto arvioi itsenäisesti, onko tarvetta monialaiselle yhteistyölle tai sosiaalihuollon Kelalle annettavalle lausunnolle . 
Yhteistyötarve voi liittyä myös hyvinvointialueen yhteydenottoon. 
