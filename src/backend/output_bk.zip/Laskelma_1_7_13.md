### 1.7.13 Laskelma
Oikeus perustoimeentulotukeen ratkaistaan tekemällä laskelma toimeentulotuessa huomioitavista tuloista , varoista ja menoista hakijan ja hänen perheenjäsentensä osalta.
Menot huomioidaan esitettyjen, etuusjaksona maksettujen tai erääntymässä olevien menoselvitysten mukaisina. Menolta edellytetään, että ne erääntyvät etuusjakson aikana. Myös perusosa on laskelmassa menoa.
Toimeentulotuessa huomioitavien tulojen ja menojen erotuksesta muodostuu hakemiskuukauden perustoimeentulotuen määrä.
Oikeus perustoimeentulotukeen määräytyy laskelman perusteella.
Lisätietoa takautuvan laskelman tekemisestä .
