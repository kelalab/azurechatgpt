#### 1.6.5.1 Avohuollon asumispalvelut
Hyvinvointialueet voivat hankkia ja tarjota sosiaalihuollon asumiseen, hoivaan ja huolenpitoon liittyviä palveluja avohuoltona. Sosiaalihuollon asumispalveluja järjestetään henkilöille, jotka erityisestä syystä tarvitsevat apua tai tukea asumisessa tai asumisensa järjestämisessä. Avohuollon asumispalvelun muotoja ovat:
 - kotiin annettavat palvelut ,
 - yhteisöllinen asuminen , (aiemmin palveluasuminen)
 - pitkäaikainen ympärivuorokautinen palveluasuminen (aiemmin pitkäaikainen tehostettu palveluasuminen) ja
 - pitkäaikainen perhehoito .

