### 1.4.2 Nopeasti määräaikana myytävissä oleva varallisuus
Ennen kuin asiakas tai hänen perheensä turvautuu toimeentulotukeen, hänen tai heidän on ensisijaisesti turvattava toimeentulonsa käytettävissä olevilla varoillaan ja tarvittaessa realisoitava omaisuuttaan elinkustannustensa kattamiseksi. Nopeasti myytävissä oleva omaisuus on sellaista varallisuutta, joka on realisoitavissa lähikuukausien aikana. Tällaista omaisuutta ovat esimerkiksi kulkuneuvot ja arvoesineet.
Kulkuneuvojen osalta myyntiä ei edellytetä, jos se on tarpeellinen
 - työssäkäynnin,
 - kulkuyhteyksien,
 - jatkuvan toimeentulon turvaamiseksi tai
 - muun vastaavan syyn perusteella, kuten esimerkiksi sairauden tai vamman vuoksi.

Näissäkin tilanteissa, jos kulkuneuvon arvo on tavanomaista suurempi, voidaan asiakasta edellyttää vaihtamaan se edullisempaan.
Nopeasti myytävissä olevan varallisuuden myyntiä ei kuitenkaan edellytetä, jos myyntikulujen jälkeen myynnistä saatava tulo on niin pieni, ettei sillä voida katsoa olevan merkitystä toimeentulotuen turvaamisen osalta.
Jos asiakas tai perheenjäsen omistaa nopeasti myytävissä olevaa varallisuutta, annetaan kahden kuukauden määräaika, jonka aikana omaisuus tulee myydä. Kun omaisuus on myyty, huomioidaan myynnistä saatu tulo laskelmalla tulona. Pääsääntönä on, että jos omaisuutta ei myydä määräajassa, huomioidaan omaisuuden arvo laskelmalla käytettävissä olevina varoina.
Nopeasti myytävissä olevan omaisuuden arvo määritetään yleensä asiakkaan antaman ilmoituksen ja saatujen selvitysten perusteella. Jos omaisuuden arvo ei ole tiedossa, se selvitetään asiakkaalta ennen ratkaisun antamista. Asiakas voi selvittää esimerkiksi kulkuneuvon arvoa toimittamalla kopion rekisteröintitodistuksesta tai kauppakirjasta.
Nopeasti realisoitava varallisuus huomioidaan myynnille annetun määräajan päätyttyä laskelmalla varoina niin kauan kuin se on asiakkaan ja hänen perheensä käytettävissä. Varallisuudesta voidaan vähentää myynnistä aiheutuneet myyntihetkellä maksettavaksi tulevat kulut, joista asiakkaan tulee esittää selvitys. Asiakkaan tulee esittää selvitys myynnistä sekä selvitys myynnistä saaduista tuloista.
Lue lisää nopeasti myytävissä olevasta varallisuudesta .
