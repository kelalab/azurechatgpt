#### 1.7.15.a Laskujen johdosta annettavat päätökset 
Erillistä päätöstä ei anneta, jos hakija toimittaa jälkikäteen laskun, joka kohdistuu ajalle, jolle tukea on jo myönnetty, ja maksu maksetaan laskun mukaisesti. Asiakas saa Kelasta näissä tilanteissa maksuilmoituksen. Päätös annetaan kuitenkin, jos laskusta huomioidaan vain osa tai sitä ei voida huomioida perustoimeentulotuessa lainkaan.
Lue kuinka päätöksen antamisessa menetellään etuudensaajan tai edunvalvojan kuolemantapauksessa tai asiakkaan kuoleman tapauksessa . Lue myös hallintolain soveltamisen ohjeista edunvalvonnan päättymisestä etuudensaajan tai edunvalvojan kuoleman johdosta .
Etuuspäätökset annetaan maksutta.
Päätökset annetaan suomeksi tai ruotsiksi väestötietojärjestelmästä saatavan asiakkaan kielitiedon perusteella. Huomaa myös tilanteet, joissa päätös annetaan asiakkaan käyttämällä saamen kielellä.
Katso myös asiaratkaisu vai tutkimatta jättäminen , päätöksen muoto ja sisältö ja päätöksen perusteleminen .
Huomaa, että perustoimeentulotuen päätöksiin ei sovelleta päätöksen poistamista koskevaa ohjeistusta. Perustoimeentulotuessa ei ole myöskään lakkautus- ja väliaikaisia täytäntöönpanopäätöksiä.
