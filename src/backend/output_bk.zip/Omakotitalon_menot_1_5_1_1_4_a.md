###### 1.5.1.1.4.a Omakotitalon menot
Omakotitalon huomioitavia menoja ovat:
 - lämmityskustannukset
 - vesimaksut
 - jätevedestä ja hulevedestä aiheutuvat maksut Nämä menot eivät vaikuta vesimaksun kohtuullisuutta arvioitaessa.

 - lokakaivon tyhjennys
 - palovakuutus
 - tontin vuokra
 - kiinteistövero Hakijan tulee toimittaa kiinteistöverolasku tai muu verottajan selvitys kiinteistöverosta. Hakijaa ohjataan tarvittaessa selvittämään kunnasta tai verottajalta, voiko hän saada maksuvapautuksen kiinteistöverosta tai maksamaan kiinteistöveron osissa.

 - puhtaana pidosta aiheutuvat kustannukset, esimerkiksi jätemaksut
 - omakotitaloasumiseen kuuluvat välttämättömät huoltomenot, esimerkiksi tiehoito- ja aurausmaksu ja nuohous
 - henkilökohtaisen asunto- tai perusparantamislainan korot

Katso kohdasta Asumismenot, joita ei huomioida , mitä menoja omakotitalossa ei voida huomioida.
