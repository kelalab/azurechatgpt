##### 1.5.1.1.6 Erikseen maksettavat vesi-, taloussähkö-, kotivakuutus ja saunamaksut
Erikseen maksettavat vesi-, taloussähkö-, kotivakuutus ja saunamaksut osoitetaan joko vuokrasopimuksella tai laskun perusteella. Ennen menon huomioimista, on arvioitava menon kohtuullisuutta.
