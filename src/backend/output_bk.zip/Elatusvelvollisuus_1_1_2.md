### 1.1.2 Elatusvelvollisuus
Elatusvelvolliselta saatava elatus on ensisijainen toimeentulon lähde perustoimeentulotukeen nähden. Samalla kun päätetään perustoimeentulotuen myöntämisestä, voidaan määrätä, että myönnetty tuki tai osa siitä peritään takaisin elatusvelvolliselta, joka on tahallaan laiminlyönyt elatusvelvollisuutensa. Hakemusta ei koskaan voida hylätä sillä perusteella, että elatusvelvollinen laiminlyö elatusvelvollisuutensa.
Elatusvelvollisia ovat:
 - aviopuolisot toisiinsa nähden
 - rekisteröidyn parisuhteen osapuolet toisiinsa nähden
 - vanhemmat alle 18-vuotiaasta lapsestaan

Ennen ensimmäisen toimeentulotuen päätöksen antamista tulee selvittää, osallistuuko elatusvelvollinen asiakkaan elatukseen:
 - Jos elatusvelvollinen osallistuu asiakkaan elatukseen, selvitetään tosiasiallisesti maksetun elatuksen määrä ja huomioidaan se asiakkaan laskelmalla tulona. Samalla arvioidaan, osallistuuko elatusvelvollinen riittävästi asiakkaan elatukseen ottaen huomioon hänen elatuskykynsä vai laiminlyökö hän elatusvelvollisuutensa kokonaan tai osittain, jolloin tuki voidaan tältä osin määrätä takaisinperittäväksi elatusvelvolliselta.
 - Jos elatusvelvollinen ei osallistu asiakkaan elatukseen lainkaan, tulee arvioida olisiko elatusvelvollisella kuitenkin riittävä elatuskyky osallistua asiakkaan elatukseen, jolloin elatusvelvollisuuden laiminlyöntiä voidaan pitää tahallisena ja määrätä tuki takaisinperittäväksi elatusvelvolliselta.

Jotta asiakkaalle myönnetty perustoimeentulotuki voitaisiin periä takaisin elatusvelvolliselta, tulee elatusvelvollisuuden laiminlyönnin olla tahallista. Käytettävissä olevien tietojen perusteella arvioidaan, osallistuuko elatusvelvollinen elatuskykyynsä nähden riittävästi asiakkaan elatukseen vai laiminlyökö hän elatusvelvollisuutensa kokonaan tai osittain. Elatuskykyä arvioitaessa otetaan huomioon:
 - elatusvelvollisen käytettävissä olevat tulot ja varat sekä kiinteät menot, kuten asumiskulut, sekä
 - elatusvelvollisen elatusvelvollisuus muihin henkilöihin.

Jos elatusvelvollisella ei ole riittävää elatuskykyä, ei elatusvelvollisuuden laiminlyönti ole tahallista eikä takaisinperintään ryhdytä.
Jos käytettävissä olevien selvitysten perusteella arvioidaan, että elatusvelvollinen pystyisi tulojensa ja varojensa perusteella osallistumaan asiakkaan elatukseen ja että hänen voidaan katsoa tahallisesti laiminlyöneen elatusvelvollisuutensa kokonaan tai osittain, toimeentulotukipäätöksessä määrätään, että asiakkaalle myönnetty toimeentulotuki tai osa siitä tullaan perimään elatusvelvolliselta takaisin. Tällöin jokaiseen asiakkaan toimeentulotukipäätökseen laitetaan maininta takaisinperinnästä.
Toimeentulotukipäätöksissä tehdyt määräykset takaisinperinnästä ovat edellytys takaisinperinnän toteuttamiselle. Lopullisesti takaisinperinnästä päättää aina hallinto-oikeus.
Lue lisää takaisinperinnän perusteista , takaisinperintäprosessista ja elatusvelvollisuuden selvittämisestä.
