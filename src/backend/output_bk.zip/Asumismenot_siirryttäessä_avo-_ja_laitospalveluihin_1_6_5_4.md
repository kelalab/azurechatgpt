#### 1.6.5.4 Asumismenot siirryttäessä avo- ja laitospalveluihin
Asiakkaan siirtyessä pitkäaikaiseen laitoshoitoon, yhteisölliseen asumiseen, ympärivuorokautiseen palveluasumiseen tai perhehoitoon hänellä voi olla asumiskustannuksia kahdesta asunnosta samanaikaisesti. Kun asiakas siirtyy edellä mainittuihin palveluihin, voidaan menona huomioida sen asunnon asumismenot, josta hän muuttaa, siltä osin kuin niitä ei ole vähennetty asiakasmaksun perustana olevista tuloista hyvinvointialueen asiakasmaksupäätöksessä. Aika lasketaan palveluun siirtymisestä alkaen.
Asumismenot voidaan huomioida seuraavasti:
 - omistusasunnosta aiheutuvat välttämättömät ja kohtuulliset kulut enintään 6 kuukaudelta
 - vuokra-asunnon vuokra ja muut asumisesta aiheutuvat välttämättömät ja kohtuulliset kulut vuokralaisen irtisanomisajalta
 - asumisoikeusasunnon käyttövastike ja muut asumisesta aiheutuvat välttämättömät ja kohtuulliset kulut enintään kolmelta kuukaudelta.

