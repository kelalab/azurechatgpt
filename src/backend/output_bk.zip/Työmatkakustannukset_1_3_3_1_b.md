##### 1.3.3.1.b Työmatkakustannukset
Työmatkakustannukset vähennetään niiden aiheutumiskuukautena maksettavasta ansiotulosta. Jos työmatkakustannusten aiheutumiskuukautena ei ole laskelmalla huomioitavia ansiotuloja, ei työmatkamenoja voida vähentää.
>ESIMERKKI: Matti osti kuukausilipun linja-autoon 5.8. ja 5.9. Matti sai ensimmäisen palkan 15.9. Kuukausilippu, joka on ostettu 5.9., voidaan huomioida vähennyksenä syyskuussa. Koska Matilla ei ole ansiotuloja elokuussa, 5.8. ostettua kuukausilippua ei voida vähentää.

Työmatkakustannukset huomioidaan edullisimman kulkuneuvon mukaisesti, ellei hakijalla ole esittää perusteltua syytä suurempaan kuluun.
Perusteltuja syitä ovat esimerkiksi:
 - puuttuvat tai erityisen hankalat liikenneyhteydet
 - sairaus tai vamma, joka edellyttää omaa autoa
 - työtehtävät

Oman auton käytöstä aiheutuvat työmatkakustannukset huomioidaan tosiasiallisten polttoainekustannusten mukaisesti, kuitenkin enintään 0,33 e/km. Hakijan tulee toimittaa luotettava selvitys oman auton käytöstä. Tällaisena selvityksenä voidaan pitää esimerkiksi työvuorolistoja sekä kuitteja polttoaineostoista. Kohtuulliset tosiasialliset työmatkakustannukset voidaan vähentää enintään siihen ansiotulon nettomäärään asti, josta on ensin tehty ansiotulovähennys. Hakijaa ohjataan selvittämään työmatkakulujen vähentäminen verotuksessa oikean ennakonpidätyksen määrän selvittämiseksi.
