##### 1.5.1.1.2 Asumisoikeusasunto
Asumisoikeusasunnossa huomioitavia menoja ovat:
 - käyttövastike, mukaan lukien käyttövastikkeeseen sisältyvä perusvastike, hoitovastike, tonttivastike, rahoitus-/pääomavastike
 - erikseen maksettavat lämmitys- ja vesimaksut
 - saunamaksu
 - henkilökohtaisten asuntolainojen korot

Asunnon hallinta osoitetaan kirjallisella asumisoikeussopimuksella. Jos sopimuksesta ei käy ilmi kuukausittain maksettavien asumismenojen määrä, pyydetään asiakkaalta erittely menoista esimerkiksi vastikelasku.
