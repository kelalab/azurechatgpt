##### 1.5.4.5.c Terveydenhuollon tulosidonnaiset asiakasmaksut
Terveydenhuoltona järjestettäviä palveluita, joista määrätään tulosidonnaisia asiakasmaksuja ovat:
 - pitkäaikainen laitoshoito
 - säännöllinen ja jatkuva kotisairaanhoito .

