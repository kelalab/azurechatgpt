###### 1.5.1.4.6.e Avo- ja laitospalvelut
Lisätietoa avo- ja laitospalvelussa olevien asumismenojen huomioisesta.
