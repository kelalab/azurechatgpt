#### 1.7.10.2 Käsittelyaika seuraavaa kuukautta ja sitä myöhäisempää ajanjaksoa koskevassa hakemuksessa
Asiakas voi jättää hakemuksen perustoimeentulotuesta jo huomattavasti ennen etuusjaksoa, jolle hän tukea hakee. Tällaisten hakemusten päätöksen antamista varten on kahdenlaiset määräajat:
 - Jos hakemus koskee hakemusajankohtaa seuraavaa kuukautta, se on käsiteltävä niin, että tuki on maksussa viimeistään etuusjakson ensimmäisenä arkipäivänä. Edellytyksenä on, että hakemuksen saapumisesta Kelaan on kulunut silloin enemmän kuin seitsemän arkipäivää.
 - Jos tukea haetaan myöhäisemmälle ajankohdalle kuin seuraavalle kuukaudelle, hakemus on käsiteltävä niin, että tuki on maksussa viimeistään hakemuksessa tarkoitetun etuusjakson ensimmäisenä arkipäivänä.

>ESIMERKKI: Asiakas toimittaa hakemuksen tammikuussa ja hakee tukea 1.3. alkaen. Päätös tulee tehdä niin, että etuus on maksussa viimeistään maaliskuun ensimmäisenä pankkipäivänä.

