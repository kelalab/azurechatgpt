###### 1.6.5.1.2.a Lyhytaikainen yhteisöllinen asuminen
Lyhytaikaisesta yhteisöllisestä asumisesta peritään yleensä tasasuuruinen asiakasmaksu. Perustoimeentulotuessa voidaan huomioida maksusta se osuus, joka kuuluu muihin perusmenoihin.
Perustoimeentulotuen hakemuksen ratkaisemiseksi tarvitaan erittelyt maksuun liittyvistä menoista. Erittelyistä pitää käydä ilmi eri palveluiden osuudet euroissa tai niiden prosenttiosuudet koko maksun määrästä. Jos asiakasmaksun sisällöstä ei saada riittäviä tietoja, ei asiakasmaksua huomioida menona.
