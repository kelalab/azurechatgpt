### 1.3.7 Tulojen jakaminen osiin
Pääsääntöisesti tulot huomioidaan etuusjakson ajalta. Etuusjakso on yleensä kalenterikuukausi. Tulo voidaan kuitenkin jakaa eriin otettavaksi huomioon useampana etuusjaksona, jos se
 - tulon kertaluonteisuus
 - tulon saamisen peruste tai
 - käyttötarkoitus

huomioon ottaen on kohtuullista.
Hakijalle kerrotaan päätöksellä etukäteen varautumisen velvollisuudesta .
Tulo voidaan jakaa osiin joko vyöryttämällä tai jaksottamalla, mutta tämä ei saa johtaa hakijan kannalta kohtuuttomaan lopputulokseen. Kohtuullisuutta harkitaan tapauskohtaisesti käytettävissä olevien tietojen perusteella. Harkinnassa otetaan huomioon:
 - Onko hakijalle kerrottu varautumisen velvollisuudesta? 
 - Onko hakija käyttänyt tai aikooko hän käyttää tulon toimeentulotuessa hyväksyttäviin tarkoituksiin? 
 - Millaiset ovat hakijan tai perheen yksilölliset olosuhteet? 
 - Vaikuttaako hakija tai perheen sosiaaliseen tilanteeseen muita tekijöitä? 


