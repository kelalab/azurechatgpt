#### 1.3.4.4 Pääomatulot
Pääomatulot huomioidaan tulona. Pääomatuloa ovat esimerkiksi
 - talletusten korot
 - osinkotulot
 - luovutusvoitto eli voitto, joka syntyy omaisuuden myynnistä
 - vuokratulot
 - henkivakuutuksen tuotto.

Pääomatulot voivat selvitä esimerkiksi hakemuksesta, verotustiedoista tai tiliotteilta.
