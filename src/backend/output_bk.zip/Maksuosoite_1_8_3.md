### 1.8.3 Maksuosoite
Perustoimeentulotuki maksetaan tilille, jonka hakija tai hänen valtuuttamansa henkilö on ilmoittanut.
Tilinumeromuutokset tehdään hakijan ilmoituksen perusteella. Hakija voi ilmoittaa tilinumeromuutoksen lomakkeella Y121, verkkoasioinnissa tai tietyissä tilanteissa suullisesti.
Perustoimeentulotuki voidaan maksaa myös ulkomaiselle tilille.
