#### 1.7.3.1 Takautuva hakuaika
