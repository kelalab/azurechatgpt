##### 1.5.4.5.b Terveydenhuollon tasasuuruiset asiakasmaksut
Terveydenhuollon tasasuuruisia asiakasmaksuja ovat esimerkiksi:
 - lääkärin ja hammashoidon maksut, esimerkiksi terveyskeskusmaksut
 - tilapäisen kotisairaanhoidon tai muun terveydenhuollon työntekijän suorittaman kotikäynnin maksut
 - poliklinikkamaksut
 - sairaalan potilasmaksut
 - hoitoon liittyvän lääkärinlausunnon maksut, ei kuitenkaan ajokorttia varten hankittu lausunto
 - julkisen terveydenhuollon fysioterapian maksut

Perustoimeentulotuessa ei huomioida menona julkisen terveydenhuollon peruuttamattomasta käynnistä aiheutunutta kustannusta.
