#### 1.10.2.2 Etuustulo kohdentuu maksamattomaan tukikuukauteen
Perustoimeentulotuki tarkistetaan muun etuuden maksukuukauden alusta alkaen.
