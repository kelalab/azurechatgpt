##### 1.6.5.3.a Terveydenhuollon palvelut
Terveydenhuollon lyhytaikaisen laitoshoidon tasasuuruiset päihdehuollon maksut huomioidaan menona perustoimeentulotuessa.
