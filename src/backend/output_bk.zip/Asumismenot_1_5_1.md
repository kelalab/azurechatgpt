### 1.5.1 Asumismenot
Asumismenojen huomioimisen tarkoituksena on turvata perustoimeentulotuen hakijan asuminen.
Toimeentulotukilaissa on määritelty hyväksyttävät asumismenot. Muita menoja ei voida huomioida perustoimeentulotuessa.
Asumismenoina voidaan huomioida vain ne menot, jotka maksaa hakija tai toimeentulotukiperheeseen kuuluva henkilö ja jotka kohdistuvat asuntoon, jossa he tosiasiallisesti asuvat.
Yleensä asumismenot huomioidaan kokonaisuudessaan esitettyjen tositteiden perusteella, jos kustannukset ovat kohtuulliset. Asumismenojen kohtuullisuusarvioinnissa otetaan huomioon perheen yksilöllinen tilanne. Jos asumismenot ovat kohtuullista tasoa suuremmat, voidaan asumismenoista huomioida kohtuullinen määrä.
