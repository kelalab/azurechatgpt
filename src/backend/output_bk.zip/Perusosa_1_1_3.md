### 1.1.3 Perusosa
Perusosa on kiinteä summa, joka on tarkoitettu jokapäiväisen elämän välttämättömiin menoihin. Näitä menoja ei huomioida erikseen toimeentulotuessa, vaan ne sisältyvät perusosaan yhtenä kokonaisuutena. Asiakas voi itse päättää, mihin hän perusosansa käyttää. Perusosan käyttämisestä ei pyydetä selvityksiä.
Perusosalla katetaan
 - ravintomenot
 - vaatemenot
 - vähäiset terveydenhuoltomenot
 - henkilökohtaisesta ja kodin puhtaudesta aiheutuvat menot
 - paikallisliikenteen käyttö
 - sanomalehden tilaus
 - puhelimen ja tietoliikenteen käyttö
 - harrastus- ja virkistystoiminta
 - vastaavat muut henkilön ja perheen jokapäiväiseen toimeentuloon kuuluvat menot esimerkiksi viivästys- ja perintäkulut sekä lainojen- ja luottojen lyhennykset.

Perustoimeentulotuessa voidaan huomioida vain Suomessa oleskelusta syntyneitä kuluja. Ulkomailla oleskelun pituus vaikuttaa asiakkaan toimeentulotukeen seuraavasti:
 - Jos asiakas oleskelee satunnaisesti ulkomailla enintään 7 päivää etuusjaksosta, huomioidaan hänelle täysi perusosa koko etuusjaksolta. Lyhyellä ja satunnaisella ulkomailla oleskelulla ei ole vaikutusta perustoimeentulotukeen.
 - Jos asiakas oleskelee ulkomailla yli 7 päivää etuusjakson aikana, huomioidaan hänelle perusosa vain Suomessa oleskelun päiviltä.
 - Jos asiakas oleskelee ulkomailla koko kuukauden, perusosaa ei huomioida lainkaan, mutta tosiasialliset asumiskustannukset esimerkiksi vuokra, vesi ja sähkö voidaan hyväksyä 3 kuukauden ajan.

