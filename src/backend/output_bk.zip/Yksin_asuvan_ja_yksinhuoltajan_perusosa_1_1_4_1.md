#### 1.1.4.1 Yksin asuvan ja yksinhuoltajan perusosa
Yksin asuvana pidetään henkilöä, jolla on oma itsenäinen taloutensa. Jos henkilö asuu huoneistossa, jossa on muitakin asukkaita, edellytetään, että hänellä on oma vuokra- tai alivuokrasopimus, ja että huoneisto mahdollistaa itsenäisen talouden ylläpitämisen. Henkilön on pystyttävä tämä luotettavasti selvittämään . Itsenäisessä taloudessa asuvina ei voida pitää henkilöitä, jotka kokonaisarvion perusteella asuvat yhteistaloudessa .
Yksin asuvan perusosa huomioidaan myös
 - vanhemmalle, joka asuu yhdessä yli 18 vuotta täyttäneen lapsensa kanssa eikä ole avio- tai avoliitossa eikä rekisteröidyssä parisuhteessa,
 - isovanhemmalle, joka asuu lapsensa perheen luona,
 - opiskelijoille, jotka asuvat opiskelija-asuntoloiden soluasunnoissa ja
 - yksinhuoltajalle 14 %:lla korotettuna myös silloin, kun hän asuu lapsineen esimerkiksi omien vanhempiensa kanssa samassa asunnossa.

Katso myös taulukko perusosien ja asumismenojen huomioimisesta .

