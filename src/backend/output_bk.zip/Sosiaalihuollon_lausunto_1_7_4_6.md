#### 1.7.4.6 Sosiaalihuollon lausunto 
Hyvinvointialueen sosiaalihuolto voi antaa asiakkaastaan lausunnon Kelalle perustoimeentulotukiasian käsittelyä varten. Lue lisää sosiaalihuollon lausunnosta . 
