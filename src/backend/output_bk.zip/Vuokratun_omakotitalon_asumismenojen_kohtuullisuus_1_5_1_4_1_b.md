###### 1.5.1.4.1.b Vuokratun omakotitalon asumismenojen kohtuullisuus
Omakotitalossa vuokralla asuvilla lämmitys ei yleensä sisälly vuokraan. Hakijalla voi olla lisäksi myös muita omakotitalon hoitoon liittyviä menoja, jotka voidaan huomioida vuokrasopimuksen mukaisesti. Jos kuukausittaiset omakotitalon hoitoon liittyvät menot ja lämmitysmenot eivät ole tiedossa, hakijaa pyydetään toimittamaan arvio kokonaiskustannuksista ennen kohtuullisuusarvioinnin tekemistä.
Kun kaikki hyväksyttävät asumismenot ovat tiedossa, arvioidaan kuukausittaisten menojen määrä ja lasketaan menot yhteen. Kuukausittaisia kokonaiskustannuksia verrataan paikkakunnan asumisnormiin.
 - Jos asunnossa on sähkölämmitys, joka laskutetaan yhdessä taloussähkön kanssa, korotetaan määrää taloussähkön normilla.
 - Jos vesimaksu sisältyy vuokraan, voidaan asumisnormia korottaa 24,00 eurolla/henkilö 1.1.2023 alkaen (22,80 eurolla/henkilö vuonna 2022).

>ESIMERKKI: Maarit asuu yksin vuokralla omakotitalossa. Vuokra on 300 euroa ja siihen sisältyy vesimaksu. Vuokrasopimuksessa on sovittu, että vuokran lisäksi Maarit maksaa lämmityksestä, maalämpö, kulutuksen mukaan. Lämmitysmenot ovat vuokranantajan arvion mukaan noin 125 e/kk. Maaritin kokonaisasumismenoja vuokra 300 euroa + lämmitys 125 euroa verrataan Kelan asumisnormiin, joka on paikkakunnalla 413,00 euroa/kk (asumisnormi 389 euroa + vesinormi 24,00 euroa). Maaritin asumismenot ylittävät Kelan normin 12,00 eurolla. Maaritin asumismenot voidaan harkinnalla huomioida kokonaisuudessaan.

>ESIMERKKI: Teppo asuu vuokraamassaan omakotitalossa, jossa on sähkölämmitys. Vuokra on 600 euroa ja se ei sisällä vesimaksua. Sähkölaskut ovat keskimäärin 150 euroa/kk. Tepon asumisen kokonaiskustannukset ovat noin 750 euroa/kk. Tepon asumiskustannuksia verrataan paikkakunnan yhden hengen asumisnormiin: vuokra 498 euroa + taloussähkö 45 euroa = 543 euroa. Tepon asumismenot ylittävät Kelan asumisnormin 207 eurolla. Teppo ei esitä perusteita kohtuullista tasoa korkeammille asumismenoille, joten hänelle annetaan kehotus etsiä edullisempaa asuntoa.

Jos kokonaiskustannukset ylittävät asumisnormin, harkitaan asumismenojen kohtuullisuutta. Katso kohta asumismenot ylittävät Kelan asumisnormin .
Harkinnassa on huomioitava asunnon maantieteellinen sijainti ja vuodenajan vaikutus lämmitysmenoihin.
 - Jos vuokran ja lämmitysmenojen kokonaiskustannukset alittavat kesäkuukausina asumisnormin, voidaan vastaavasti talvella huomioida asumismenoja enemmän.
 - Jos asumismenot ylittävät asumisnormin vähäisesti, voidaan talvikuukausina harkinnalla huomioida asumismenoja enemmän, eikä muuttokehotusta tarvitse antaa.

>ESIMERKKI: Ajalla maaliskuu-syyskuu Harrin asumismenot (vuokra, sähkölämmitys, vesi ja taloussähkö) alittavat Kelan asumisnormin 100 eurolla. Loka-helmikuussa asumismenot ovat 130 euroa suuremmat, kuin kesäaikana. Voidaan hyväksyä 30 euron asumismenojen ylitys talviaikana.

>ESIMERKKI: Samin vuokra-, lämmitys- ja vesimenot ovat yhteensä 550 euroa kuukaudessa hänen vuokraamassaan omakotitalossa. Paikkakunnan asumisnormi yhdelle henkilölle on 600 euroa + vesimaksu 24,00 euroa eli 624,00 euroa. Sami esittää 100 euron laskun nuohouksesta. Vuokrasopimuksessa on sovittu, että vuokralainen vastaa menosta. Samille voidaan hyväksyä lisää asumismenoja kiinteiden kustannusten lisäksi noin 74,00 euroa/kk. Kyseessä on kertaluonteinen kustannus, joka voidaan jakaa useammalle kuukaudelle. Meno voidaan siten hyväksyä kokonaisuudessaan Samin laskelmalla.

