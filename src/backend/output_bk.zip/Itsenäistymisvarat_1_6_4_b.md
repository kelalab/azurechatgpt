#### 1.6.4.b Itsenäistymisvarat
Jälkihuollossa olevalle nuorelle on voinut kertyä lastensuojelulain mukaisia itsenäistymisvaroja. Pääsääntö on, ettei itsenäistymisvaroja huomioida varoina jälkihuollon aikana. Jos nuori kuitenkin saa itsenäistymisvaroja käyttöönsä jälkihuollon aikana, huomioidaan tämä osuus itsenäistymisvaroista tulona laskelmalla.
Jälkihuollossa olevalta nuorelta pyydetään tieto itsenäistymisvarojen käytöstä.
 - Kelaan ei tarvitse toimittaa koko jälkihuoltosuunnitelmaa, vaan riittää, että toimitetaan hyvinvointialueen selvitys siitä, mihin itsenäistymisvaroja käytetään.
 - Jos jälkihuoltosuunnitelmaan on kirjattu, että itsenäistymisvaroja on tarkoitus käyttää perustoimeentulotuen muihin perusmenoihin esimerkiksi vuokravakuuteen, ei näitä menoja huomioida perustoimeentulotuessa.

Jälkihuollon päättyessä nuori saa jäljelle jääneet itsenäistymisvarat käyttöönsä. Varat huomioidaan jälkihuollon päätyttyä varallisuutena laskelmassa. Jälkihuollon päätyttyä toimeentulotukihakemuksen liitteeksi on toimitettava hyvinvointialueen selvitys itsenäistymisvarojen määrästä.
