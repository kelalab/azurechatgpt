##### 1.5.5.2.a Ylijäämä enintään 20 euroa (yhden hengen talous) tai 50 euroa (perhe)
Asiakkaalle voidaan myöntää ylijäämästä huolimatta maksusitoumus lääkkeisiin, jos kaikki alla olevat edellytykset täyttyvät
 - ylijäämä on enintään 20 euroa (yhden henkilön talous) tai enintään 50 euroa (perhe) ja
 - asiakkaalla on säännöllisinä toistuvat tulot esimerkiksi eläke tai työttömyyskorvaus ja
 - ylijäämä muodostuu säännöllisistä kuukausittain toistuvista saman suuruisista menoista esimerkiksi vuokra ja vesimaksu ja
 - asiakkaalla on säännöllisesti käytettäviä lääkkeitä ja
 - lääkkeet maksavat enemmän kuin ylijäämä on.

Asiakkaan tulee ilmaista lääketarve, mutta lääkkeitä ei tarvitse yksilöidä. Hakemuksen liitteeksi tarvitaan ei-korvattavista lääkkeistä potilasohje tai Omakannasta saatava kopio sähköisestä reseptistä.
Jos säännöllisesti käytettävät lääkkeet maksavat asiakkaalle enemmän kuin ylijäämä, asiakkaalle myönnetään maksusitoumus lääkkeisiin, vaikka perustoimeentulotuki muilta osin hylätään. Maksusitoumus annetaan vain niille perheenjäsenille, joilla on säännöllisesti käytettäviä lääkkeitä. Maksusitoumus voidaan antaa pääsääntöisesti vuosiomavastuun (lääkekatto) ylittymiseen saakka. Lue lisää maksusitoumuksesta ylijäämätilanteessa.
