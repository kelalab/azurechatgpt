#### 1.5.6.2 Yksityisen varhaiskasvatuksen menot
Koska asiakasmaksujen alentaminen tai niistä vapauttaminen on mahdollista vain kunnallisissa palveluissa, yksityisestä varhaiskasvatuksesta aiheutuneet kustannukset huomioidaan vain poikkeustilanteessa ja erityisin perustein. Jos asiakas hakee toimeentulotukea yksityisen varhaiskasvatuksen kustannuksiin, hänet ohjataan välittömästi hakemaan kunnallista varhaiskasvatuspaikkaa.
Yksityisen hoidon kustannukset voidaan hyväksyä hakemiskuukauden sekä enintään sitä seuraavan kuukauden ajalta täysimääräisinä riippuen siitä, missä vaiheessa kuukautta toimeentulotukihakemus ratkaistaan. Asiakkaalta pyydetään seuraavan hakemuksen liitteeksi:
 - kunnan päätös kunnallisesta varhaiskasvatuspaikasta tai
 - tosite siitä, että hakemus varhaiskasvatuspaikasta on vireillä kunnassa.

Jos asiakas on hakenut kunnallista varhaiskasvatuspaikkaa, tehdään hänelle kuukauden pituisia toimeentulotukipäätöksiä ja yksityisen varhaiskasvatuksen maksut huomioidaan menona, kunnes siirto kunnalliseen varhaiskasvatukseen on mahdollista. Asiakkaan tulee toimittaa kunnan päätös kunnallisesta varhaiskasvatuspaikasta ja siitä perittävästä maksusta, jonka jälkeen menot huomioidaan tämän päätöksen mukaisina.
Kunnan varhaiskasvatuspaikkaa tulisi hakea viimeistään neljä kuukautta ennen kuin varhaiskasvatuspaikkaa tarvitaan. Kiireellisessä tilanteessa, esimerkiksi vanhemman työllistyessä, tulee kunnan järjestää varhaiskasvatuspaikka kahden viikon kuluessa hakemuksen saapumisesta. Jos asiakas ei ole saanut kunnallista varhaiskasvatuspaikkaa neljän kuukauden kuluessa siitä, kun häntä on ohjattu ensimmäisen kerran hakeutumaan kunnalliseen varhaiskasvatukseen, tulee selvittää tarkemmin, miksi varhaiskasvatuspaikkaa ei ole tarjottu. Asiaa voidaan asiakkaan suostumuksella selvittää suoraan kunnan varhaiskasvatuspalveluista tai asiakas voi esittää kunnan päätöksen tai selvityksen asiasta.
 - Jos ilmenee, että asiakas ei ole ottanut kunnallista varhaiskasvatuspaikkaa vastaan, ei yksityisen varhaiskasvatuksen maksua voida huomioida menona kunnallisesta varhaiskasvatuspaikasta kieltäytymisestä lukien.
 - Jos asiakas ei kirjallisesta ohjauksesta huolimatta hae kunnan järjestämää varhaiskasvatuspaikkaa, maksuja ei yleensä huomioida menona. Tällöin tulona ei vastaavasti huomioida lasten kotihoidon ja yksityisen hoidon tuesta annetun lain mukaista tukea.

Yksityisen varhaiskasvatuksen maksu voidaan kuitenkin ottaa poikkeuksellisesti perheen erityisten tarpeiden tai olosuhteiden vuoksi perustoimeentulotuessa huomioon myös pidempiaikaisesti. Tällainen tilanne voi esimerkiksi olla:
 - pitkäaikaisen hoitosuhteen jatkuminen on esimerkiksi lastensuojelun tai erikoissairaanhoidon antaman selvityksen perusteella poikkeuksellisen tärkeää lapsen kasvun ja kehityksen kannalta,
 - toimeentulotuen tarve arvioidaan lyhytaikaiseksi,
 - kielisyyt (suomi, ruotsi, saame) tai
 - lapsella todetut erityistarpeet, jos vastaavaa hoitoa ei ole saatavissa kunnan järjestämänä. Asiakkaan on tullut hakea kunnan järjestämää varhaiskasvatuspaikkaa ja hänen tulee esittää kunnan selvitys siitä, ettei lapsen erityistarpeita vastaavaa hoitoa voida järjestää kunnan toimesta.

Tarvittaessa asiakkaan tulee toimittaa esimerkiksi hyvinvointialueen sosiaalitoimen selvitys perusteista, joiden vuoksi lapsen yksityinen varhaiskasvatus on välttämätöntä. Jos asiakas toimittaa selvityksen, jossa esitettyä perustetta voidaan pitää hyväksyttävänä, voidaan yksityisen varhaiskasvatuksen maksu huomioida menona.
Jos yksityisen hoidon kustannukset huomioidaan menona, niin tulona huomioidaan seuraavat tuet, jos ne ovat maksussa asiakkaalle itselleen:
 - lasten kotihoidon ja yksityisen hoidon tuesta annetun lain mukainen tuki
 - yksityisen hoidon tuen hoitolisä
 - muu mahdollinen kunnan maksama taloudellinen tuki yksityisen hoidon käyttämiseen.

