##### 1.7.15.1.a Muu kuin kiireellinen perustoimeentulotukihakemus
Ensimmäinen päätös tehdään asiakkaalle yleensä 1-2 kuukauden ajalle.
Päätös tehdään yhden kalenterikuukauden ajalle, jos
 - henkilön palkkatulo vaihtelee kuukausittain
 - henkilö saa soviteltua työttömyysetuutta
 - kysymyksessä on tuloton, alle 25-vuotias nuori päätös voidaan tehdä 2-3 kuukaudelle, jos sosiaalitoimi on tietoinen asiakkaan tilanteesta päätös voidaan tehdä pidemmälle, jos se tukee sosiaalitoimen kanssa tehtyä asiakassuunnitelmaa

 - tilanne on ensisijaisten etuuksien osalta keskeneräinen (TotuL 23 §)
 - henkilöllä on omaisuutta, jonka realisointitarvetta selvitetään
 - toimeentulotukea myönnettäessä on määrätty toimeentulotuen takaisinperinnästä
 - asiakasmaksua on tarpeen alentaa

Toimeentulotuen perusosan alentamista koskeva päätös voidaan tehdä enintään kahdeksi kuukaudeksi kerrallaan. Käytännössä alentaminen tehdään kuukaudeksi kerrallaan.
Jos on epäselvää, mille kuukaudelle asiakas on hakemuksen tehnyt, esimerkiksi hakeeko asiakas tukea hakemiskuukaudelle vai seuraavalle kuukaudelle, hakuaika tarkistetaan asiakkaalta. Jos hakemuksesta puuttuu hakuajan päättymisajankohta, tehdään päätös yhdelle kuukaudelle.
