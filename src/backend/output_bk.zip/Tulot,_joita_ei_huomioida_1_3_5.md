### 1.3.5 Tulot, joita ei huomioida
