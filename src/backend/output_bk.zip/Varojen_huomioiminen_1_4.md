## 1.4 Varojen huomioiminen
Asiakkaan ja hänen perheensä on ensisijaisesti turvattava toimeentulonsa käytettävissä olevilla varoillaan sekä tarvittaessa realisoimalla omaisuuttaan.
Laskelmalla voidaan ottaa huomioon vain se varallisuus , joka on asiakkaan tai perheen tosiasiallisesti käytettävissä toimeentulotuesta päätettäessä. Käytettävissä olevilla varoilla tarkoitetaan sellaista omaisuutta, jonka käytettäväksi saattaminen ei edellytä realisoimista tai joka on heti realisoitavissa. Myös asiakkaan ja hänen perheensä ulkomailla oleva varallisuus on selvitettävä ja se otetaan huomioon laskelmalla.
Laskelmalla otetaan huomioon asiakkaan ja hänen perheensä käytettävissä olevat varat, lukuun ottamatta:
 - asiakkaan tai perheen käytössä olevaa vakinaista asuntoa ja tarpeellista asuinirtaimistoa
 - tarpeellisia työ- tai opiskeluvälineitä
 - alle 18-vuotiaan lapsen varoja siltä osin, kuin ne ylittävät hänen osaltaan hänen perusosansa ja muut perusmenonsa
 - muita sellaisia varoja, jotka ovat tarpeen jatkuvan toimeentulon turvaamiseksi.

Jos asiakkaalla tai perheellä on varallisuutta, joka ei ole heti käytettävissä oman elatuksen turvaamiseksi, kehotetaan asiakasta myymään omaisuus. Riippuen omaisuuden lajista, voidaan joko antaa omaisuuden myynnille määräaika, jonka jälkeen se huomioidaan laskelmalla varoina tai toimeentulotukea myönnettäessä voidaan määrätä, että myönnetty tuki tai osa siitä peritään takaisin kyseisestä omaisuudesta. Takaisinperinnän tulee ilmetä toimeentulotukipäätöksestä.
Koska toimeentulotuen tarkoitus on edistää asiakkaan itsenäistä selviytymistä, ei sellaista omaisuutta kuitenkaan vaadita realisoitavaksi, joka on tarpeen asiakkaan tai perheen jatkuvan toimeentulon turvaamiseksi.
On myös mahdollista jättää varallisuus harkinnalla kokonaan huomioimatta tai huomioida se vain osittain, jos
 - varallisuus turvaa asiakkaan toimeentuloa, esimerkiksi perheessä oleva auto voi olla tarpeen työn vuoksi ja toimeentulon turvaamiseksi

 - varallisuudesta saatavissa oleva myyntitulo on vähäinen,
 - varallisuutta ei pystytä realisoimaan tai
 - kyseessä on lasten tavanomaiset harrastusvälineet.

Myös avopuolison varallisuus otetaan huomioon perheen tuen tarvetta laskettaessa. Jos avopuolison omaisuus myydään, se otetaan tulona huomioon perheen yhteisessä laskelmassa. Avopuolison varoista ei kuitenkaan voida periä takaisin toiselle avopuolisolle myönnettävää toimeentulotukea, koska avopuolisot eivät ole elatusvelvollisia toisiaan kohtaan. Sama koskee myös muita tilanteita, joissa samaan toimeentulotukiperheeseen kuuluu henkilöitä, joiden välillä ei ole elatusvelvollisuutta, kuten esimerkiksi avo- tai aviopuolison muut kuin yhteiset lapset. Katso myös takaisinperinnän prosessi .
Asiakkaalta kysytään hakemuksessa asiakkaan ja perheen varallisuustiedot. Tietoja varallisuudesta voi käydä ilmi myös esimerkiksi asiakkaan tai perheen verotustiedoista.
