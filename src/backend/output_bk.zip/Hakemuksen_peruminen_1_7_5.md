### 1.7.5 Hakemuksen peruminen
Perustoimeentulotuen hakija voi perua hakemuksen, jos päätöstä ei ole vielä annettu. Perumisen voi tehdä suullisesti tai kirjallisesti. Hakemus raukeaa peruutuksen seurauksena. Asian raukeamisesta ilmoitetaan asiakkaalle kirjeellä tai viestillä. Lue lisää hakemuksen perumisesta .
