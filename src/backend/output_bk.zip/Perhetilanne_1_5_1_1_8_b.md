###### 1.5.1.1.8.b Perhetilanne
Kahden asunnon asumismenoja voidaan harkinnalla huomioida poikkeuksellisesti muutaman kuukauden ajan, jos toisen asunnon kustannukset ovat perusteltuja esimerkiksi puolison tutkintoon johtavan opiskelun tai työn teon perusteella.
>ESIMERKKI: Perheen äiti suorittaa pakollista opintoihin kuuluvaa harjoittelua 3 kuukauden ajan Oulussa. Perhe asuu vakinaisesti omakotitalossa Jyväskylässä. Voidaan huomioida perheen asumiskulut vakinaisessa asunnossa sekä äidin vuokraaman tilapäisasunnon kustannukset harjoittelun aikana.

