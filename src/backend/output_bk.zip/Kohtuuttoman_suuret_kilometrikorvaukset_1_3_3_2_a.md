##### 1.3.3.2.a Kohtuuttoman suuret kilometrikorvaukset
Jos kilometrikorvaukset ovat kohtuuttoman suuret suhteessa ansiotulon määrään, tulee hakijan esittää luotettava selvitys kustannusten perusteista, esimerkiksi ajopäiväkirja.
Kun kilometrikorvaukset ovat kohtuuttoman suuret suhteessa ansiotulon määrään, ne voidaan huomioida kohtuullisen määrän ylittävältä osin tulona. Kilometrikorvauksista vähennetään niiden perusteena olevien kilometrien mukainen tosiasiallinen polttoainekustannus, kuitenkin enintään 0,33 e/km ja erotus huomioidaan tulona.
>ESIMERKKI: Maija saa palkkaa 200 euroa ja kilometrikorvauksia 1 000 euroa. Maija on työkseen kampaaja. Maija ei toimita ajopäiväkirjaa eikä Maijan tiliotteilla näy polttoaineostoja esitetyn mukaisesti. Maijan kilometrikorvaukset ovat kohtuuttoman suuret palkkaan nähden. Koska Maija ei ole esittänyt luotettavaa selvitystä kilometrikorvauksista, voidaan kilometrikorvaukset huomioida tulona.

