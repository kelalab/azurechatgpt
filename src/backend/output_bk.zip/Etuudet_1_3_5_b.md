#### 1.3.5.b Etuudet 
Tuloina ei huomioida 
 - työttömyysetuutta saavan hakijan kulukorvausta 
 - työllistymistä edistävään palveluun osallistumisen aikana maksettavaa korotusosaa ja korotettua ansio-osaa 
 - kuntouttavaan työtoimintaan osallistuvan henkilön toimintarahaa 
 - täydentävänä tai ehkäisevänä toimeentulotukena saatua tuloa 
 - oikaisuvaatimuskeskuksen päätöksellä saatua tuloa 
 - äitiysavustusta 
 - vammaisetuuksia alle 16-vuotiaan vammaistuki  16 vuotta täyttäneen vammaistuki ja  eläkettä saavan hoitotuki  veteraanilisä  

 - kuntoutus- ja kuntoutusrahaetuuksista annetun lain mukaisia ylläpitokorvauksia 
 - koulumatkatukea 
 - opintolainan korkoavustusta 
 - koulutarvikemäärärahaa (kuntoutus) 
 - opintorahan oppimateriaalilisää 
 - liikkuvuusavusta siltä osin kuin hakija pystyy näyttämään käyttäneensä avustuksen työssäkäynnin matkustuskustannuksiin tai muuttokustannuksiin 
 - joulukuussa 2022 maksettu ylimääräinen lapsilisä 

 
