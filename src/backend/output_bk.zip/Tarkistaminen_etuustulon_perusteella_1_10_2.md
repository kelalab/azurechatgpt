### 1.10.2 Tarkistaminen etuustulon perusteella

Jos etuuteen on tehty saatavasuunnitelma eli kuittaus odotettavissa olevasta etuudesta, tarkistusta tai tulon jälkikäteistä huomioimista ei yleensä tehdä, vaan etuus kuitataan toimeentulotukeen. Tarkistus tai tulon jälkikäteinen huomioiminen tehdään, jos saatavasuunnitelma ei kata koko takautuvaa aikaa tai takautuvalta ajalta maksettava etuus on suurempi kuin toimeentulotukeen kohdistuva kuittaus.
Katso myös saatavasuunnitelma eli kuittaus odotettavissa olevasta etuudesta . 
Lue lisää tulon jälkikäteisestä huomioimisesta ja tulon tarkistamisesta maksukuukaudelle .
