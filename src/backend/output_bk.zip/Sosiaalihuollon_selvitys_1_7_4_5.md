#### 1.7.4.5 Sosiaalihuollon selvitys
Jos Kelassa on käytössä hyvinvointialueen sosiaalihuollon selvitys asiakkaan tilanteessa vaikuttavista asioista, se tulee huomioida ratkaisua tehtäessä. Erityisesti tulee kiinnittää huomiota lastensuojelusta saatuun selvitykseen. Asiakkaalle annettavassa etuuspäätöksessä tulee viitata sosiaalihuollon antamaan selvitykseen ja kertoa, miten se on vaikuttanut päätöksen sisältöön. 
Lue lisää näkemyksen pyytämisestä ja yhteistyöstä hyvinvointialueen kanssa .
