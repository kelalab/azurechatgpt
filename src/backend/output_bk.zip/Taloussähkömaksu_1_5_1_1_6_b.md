###### 1.5.1.1.6.b Taloussähkömaksu
Taloussähköllä tarkoitetaan esimerkiksi kodinkoneisiin, valaistukseen ja elektroniikkaan käytettävää sähköä. Taloussähköllä ei kateta lämmityskustannuksia.
Taloussähkölaskuista huomioitavia menoja ovat
 - sähkön siirto- ja kulutusmenot sekä kuukausimaksut (usein perusmaksu),
 - sähkövero ja
 - huoltovarmuusmaksu.

Taloussähkömenoja ei voida huomioida ennakkolaskujen perusteella, vaan niiden tulee perustua todelliseen kulutukseen.
Toimeentulotuessa ei huomioida:
 - sähkön katkaisu-, avaus-, kytkentä- ja muita maksuja
 - sähköyhtiöltä ostettuja lisäpalveluita esimerkiksi vihreä sähkö, lähisähkö, hintakatto, vaihtoturva, aurinkovalinta

Lue lisää taloussähkölaskun kohtuullisuuden arvioimisesta .
Jos hakija ei saa tehtyä sähkösopimusta ilman vakuusmaksun maksamista, hakijalle voidaan myöntää Kelasta sähkövakuus.
