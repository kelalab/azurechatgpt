### 1.3.8 Tulojen arvioiminen
Laskelmalla huomioitavan tulon määrä voidaan arvioida, jos
 - asiakkaalle maksetaan säännöllisesti määrältään vaihtelevia tuloja,
 - tulojen määrä vaihtelee kuukausittain vähäistä enemmän
 - eikä riittävää selvitystä etuusjakson aikana tosiasiallisesti maksettavista tuloista vielä päätöstä tehtäessä ole käytettävissä.

Tällöin päätös tehdään aina kuukaudeksi kerrallaan. Päätöksessä kerrotaan, että tulo on arvioitu sekä mihin arvio perustuu. Tulojen arvioimista voidaan käyttää kaikissa tulolajeissa, kuten esimerkiksi
 - ansiotuloissa
 - sovitellussa työttömyysetuudessa
 - pelivoitoissa
 - avustuksissa
 - elatusavussa
 - yrittäjien ansiotuloissa 

Arvio voidaan tehdä esimerkiksi hakijan oman arvion sekä edeltävinä kuukausina saatujen tulojen perusteella, jollei sitä voida pitää kohtuuttomana. Jos osa hakukuukauden tuloista on jo päätöstä annettaessa tiedossa, huomioidaan tiedossa oleva tulo laskelmalla ja arvioidaan vain loppukuukauden tulot. Tulojen arvioimisessa käytetään tapauskohtaista kokonaisharkintaa hakijan yksilöllinen tilanne huomioiden.
>ESIMERKKI: Piian ansiotulojen määrä vaihtelee, mutta hänellä on joka kuukausi jonkin verran ansiotuloja eri työnantajilta. Piia hakee toimeentulotukea huhtikuulle, mutta huhtikuun ansiotulot eivät ole vielä päätöstä annettaessa tiedossa. Piia on saanut ansiotuloja tammikuussa yhteensä 550 euroa, helmikuussa yhteensä 1 000 euroa ja maaliskuussa yhteensä 600 euroa. Edeltävien kuukausien ansiotulojen perusteella Piian huhtikuun laskelmalle viedään arvioitua ansiotuloa 700 euroa.

>ESIMERKKI: Minnan ansiotulojen määrä vaihtelee kuukausittain. Tämän lisäksi palkka maksetaan hänelle kaksi kertaa kuukaudessa, kuun 6. ja 20. päivä. Edeltävien kuukausien palkanmaksujen perusteella Minnan tammikuun tulojen määräksi voidaan arvioida yhteensä 1 000 euroa. Tammikuun päätöstä annettaessa tiedetään, että 6.1. Minnalle on maksettu 600 euroa ansiotulona. Tiedossa ei kuitenkaan ole 20.1. maksettavan ansiotulon määrä. Koska edeltävien kuukausien perusteella Minnan koko tammikuun palkkojen yhteismääräksi on arvioitu 1 000 euroa, arvioidaan loppukuusta maksettavan ansiotulon määräksi 400 euroa (1 000 euroa – 600 euroa). Minnan tammikuun laskelmalla huomioidaan 6.1. maksettu ansiotulo 600 euroa sekä loppukuun arvioitu ansiotulo 400 euroa.

>ESIMERKKI: Sallan tiliotteilla on nähtävissä joka kuukausi yhteensä noin 220-470 euroa avustuksia läheisiltä. Salla on saanut avustuksia huhtikuussa yhteensä 220 euroa, toukokuussa 470 euroa ja kesäkuussa 310 euroa. Tulo on säännöllinen ja sen määrä vaihtelee enemmän kuin vähäisesti kuukausittain. Koska heinäkuun avustusten määrä ei ole tiedossa päätöstä annettaessa, arvioidaan heinäkuun laskelmalle avustusten määräksi 300 euroa. Arviosta vähennetään yksin asuvalta Sallalta 50 euroa, jolloin tulona huomioidaan 250 euroa.

