### 1.12.2 Takaisinperinnän tilanteet
Kela voi päättäessään perustoimeentulotuen myöntämisestä samalla määrätä, että toimeentulotuki tai osa siitä peritään takaisin:
 - tuensaajalta, jos hänellä on tuloja tai varoja tai oikeus elatusta turvaavaan etuuteen, jotka eivät ole tukea myönnettäessä hänen määrättävinään tai hän ei muista syistä voi niitä silloin käyttää
 - tuensaajalta, jos hän on tahallaan laiminlyönyt velvollisuuden pitää huolta omasta elatuksestaan
 - tuensaajalta, jos tuen myöntäminen on aiheutunut lakkoon osallistumisesta
 - tuensaajan elatusvelvolliselta, jos hän on tahallaan laiminlyönyt elatusvelvollisuutensa.

Edellä mainituissa tilanteissa Kelan päätöksellä annettu määräys takaisinperinnästä on edellytys sille, että hallinto-oikeus voi tehdä varsinaisen takaisinperintäpäätöksen. Määräys tarkoittaa sitä, että perustoimeentulotukipäätöksessä kerrotaan nimenomaisesti takaisinperinnästä. Määräystä ei voi tehdä jälkikäteen päätöksen antamisen jälkeen. Päätöksestä tulee ilmetä, keneltä tuki on tarkoitus periä takaisin ja millä perusteella.
Jos tuen myöntäminen on perustunut tahallaan annettuihin erehdyttäviin tietoihin tai ilmoitusvelvollisuuden tahalliseen laiminlyöntiin, voidaan toimeentulotuki periä takaisin ilmoitusvelvollisuuden laiminlyöneeltä siltä osin, kuin tuen myöntäminen on perustunut tästä syystä virheellisiin tietoihin. Tällöin ei edellytetä, että päätöstä tehtäessä olisi määrätty erikseen takaisinperinnästä. Lue lisää tietojenanto- ja ilmoitusvelvollisuudesta .
