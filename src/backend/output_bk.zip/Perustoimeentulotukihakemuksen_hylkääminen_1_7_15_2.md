#### 1.7.15.2 Perustoimeentulotukihakemuksen hylkääminen
Kun asiakkaan tukihakemusta käsitellään, hänen tuloistaan ja varoistaan tehdään laskelma. Hakemus perustoimeentulotuesta hylätään, jos laskelma osoittaa, että asiakkaan perustoimeentulotuessa huomioitavat tulot ja varat ovat suuremmat kuin hänen menonsa. Tukea ei kuitenkaan voida hylätä tulevalta ajanjaksolta kuukautta pidemmältä ajalta.
Eräissä tilanteissa hakemus hylätään poikkeuksellisilla perusteilla:
 - Jos asiakas ei toimita pyynnöstä huolimatta annettuun määräaikaan mennessä hakemuksen ratkaisemiseksi välttämättömiä tietoja (muun muassa tiliotetta, tulotietoja).
 - Kiireellisenä myönnettyyn perustoimeentulotukipäätökseen ei voida myöntää jatkoa, jos siitä puuttuu tiliote, vaikka muut liitteet olisikin toimitettu.
 - Kotikunnattomille turvapaikanhakijoille, jotka ovat kirjoilla vastaanottokeskuksissa, ei myönnetä perustoimeentulotukea. Vastaanottokeskukset turvaavat turvapaikanhakijoiden toimeentulon.
 - Perustoimeentulotukea ei myönnetä ulkomailla asuvalle henkilölle, kun kulut muodostuvat ulkomailla.

