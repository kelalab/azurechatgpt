#### 1.7.8.c Turvakieltoasiakkaiden etuusasiat
Turvakieltoasiakkaiden etuusasiat valmistellaan ja ratkaistaan keskitetysti. Lue lisää turvakieltoasiakkaiden ratkaisutyön keskittämisestä kohdasta Turvakielto .
