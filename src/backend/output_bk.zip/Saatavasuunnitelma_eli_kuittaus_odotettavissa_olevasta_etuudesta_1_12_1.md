### 1.12.1 Saatavasuunnitelma eli kuittaus odotettavissa olevasta etuudesta
Toimeentulotuki voidaan periä suoraan henkilön odotettavissa olevasta etuudesta kuittaamalla, jolloin perintä ei edellytä hallinto-oikeuden päätöstä. Menettelyä kutsutaan saatavasuunnitelmaksi. Odotettavissa olevalla etuudella tarkoitetaan tässä yhteydessä esimerkiksi:
 - työttömyysetuutta
 - yleistä asumistukea
 - eläkettä
 - elatusapua
 - avustusta tai
 - muuta jatkuvaa tai kertaluontoista tuloa, korvausta tai saamista.

Myös ulkomailta maksettavaa ensisijaista etuutta voidaan kuitata. Katso lisää saatavasuunnitelmasta ulkomaille .
Ensisijaiset Kelan etuudet on ratkaistava aina ensin silloin, kun se on mahdollista. Toimeentulotukihakemuksen käsittely ei kuitenkaan saa viivästyä tämän vuoksi.
Perimisen edellytys on, että toimeentulotuki on myönnetty joko kokonaan tai osaksi ennakkona odotettavissa olevaa etuutta vastaan. Toimeentulotukea myönnettäessä päätöksestä tulee käydä ilmi, mihin tuloon perintä tarkalleen kohdistuu. Päätös tehdään yleensä yhdeksi kuukaudeksi.
Saatava voidaan periä vain siltä osin kuin se kohdistuu samaan ajanjaksoon, jolta toimeentulotukea on maksettu. Toimeentulotuen kuittaukseen käytettyjen varojen jälkeen jäljelle jääneet varat on välittömästi suoritettava etuuden maksajalle. Jos samaan tuloon tai saatavaan kohdistuu sekä Kelan että hyvinvointialueen maksuvaatimus, tulot tai saatavat maksetaan ensin Kelalle. Kela suorittaa tällöin perustoimeentulotuen kuittaukseen käytettyjen varojen jälkeen jäljelle jääneet varat hyvinvointialueelle.
Tulon, korvauksen tai saamisen suorittajalle on ilmoitettava etukäteen, ettei suoritusta saa maksaa asiakkaalle itselleen. Jos ilmoitus on tehty tulon suorittajalle vähintään kaksi viikkoa ennen maksupäivää, voi maksu tapahtua laillisin vaikutuksin vain Kelalle. Kelan ilmoituksesta on käytävä ilmi se ajanjakso, jolta toimeentulotukea on myönnetty ennakkona kyseistä tuloa vastaan.
Jos odotettavissa olevaa etuutta on kuitattu perustoimeentulotukeen, laskelmalla huomioidaan tulona asiakkaalle kuittauksen jälkeen tosiasiallisesti maksettava etuuden määrä.
Katso lisää saatavasuunnitelmasta .
