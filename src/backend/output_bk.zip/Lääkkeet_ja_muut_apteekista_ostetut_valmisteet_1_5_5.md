### 1.5.5 Lääkkeet ja muut apteekista ostetut valmisteet
Terveydenhuoltomenoja katetaan sekä toimeentulotuen perusosalla, että muina perusmenoina. Perusosalla katetaan vähäiset terveydenhuoltomenot, joita ovat esimerkiksi:
 - ilman reseptiä ostetut lääkkeet
 - laastarit
 - kosmetiikka
 - luontaistuotteet
 - hammastahnat ja suuvedet.

Muina perusmenoina voidaan hyväksyä terveydenhuollon ammattihenkilön määräyksellä hankitut lääkkeet ja valmisteet, jotka ovat tarpeellisia asiakkaan sairauden tai terveysongelman hoidossa. Lisäksi voidaan huomioida joitakin sellaisia menoja, jotka eivät johdu sairauden hoidosta, kuten esimerkiksi:
 - kustannukset hedelmöityshoidosta,
 - ehkäisypillereistä
 - tupakan vieroituslääkkeistä.

Joistain valmisteista tarvitaan erillinen lääketieteellinen selvitys, jonka perusteella arvioidaan valmisteen tarpeellisuus asiakkaan hoidossa.
Hakija ja perheenjäsenet saavat yleensä myönteisen perustoimeentulotukipäätöksen yhteydessä maksusitoumuksen apteekkiin, Maksusitoumus lääkekustannuksiin. Lisäksi menona voidaan huomioida asiakkaan itse maksamia lääkekuluja samojen yleisten periaatteiden mukaisesti kuin maksusitoumusta myönnettäessä. Lue lisää asiakkaan itse maksamista lääkekuluista .
Asiakas voi saada lääkkeitä kerralla
 - enintään 3 kuukauden hoitoaikaa vastaavan lääkemäärän, ellei toimitettavaa lääkemäärää ole erikseen maksusitoumuksessa rajattu. Lääkemäärä lasketaan lääkemääräyksen annostusohjeen perusteella.
 - enintään 1 kuukauden hoitoaikaa vastaavan lääkemäärän, jos yhden korvattavan pakkauksen arvonlisäverollinen vähittäishinta on toimitushetkellä korkeampi kuin 1000 euroa (kalliit lääkkeet). Lääkemäärä lasketaan lääkemääräyksen annostusohjeen perusteella.

Asiakas voi hankkia uuden lääke-erän vasta, kun edellinen erä on käytetty lääkkeen määrääjän ohjeen mukaan lähes kokonaan. Jos asiakas hankkii lääkkeitä enemmän kuin annostusohjeen mukaan on tarpeen, voidaan kyseessä olevat valmisteet rajata pois maksusitoumukselta tai niiden kustannuksia ei oteta menona huomioon perustoimeentulotuessa.
Määrätty lääkevalmiste tulee vaihtaa halvempaan vaihtokelpoiseen lääkevalmisteeseen paitsi silloin, jos lääkkeen määrääjä on kieltänyt vaihdon tai jos kyseessä on lääkkeen valtakunnallinen saatavuusongelma. Jos asiakas kieltää vaihdon, maksaa asiakas itse hinnan erotuksen. Tätä itse maksettua osuutta ei hyväksytä menona perustoimeentulotuessa.
Asiakkaan ensisijaiset etuudet (lääkekorvausoikeudet ja –korvaukset) tulisi olla ratkaistuna ennen perustoimeentulotukea tai ne tulisi selvittää viimeistään perustoimeentulotukihakemuksen käsittelemisen yhteydessä.
