#### 1.3.3.3 Luontoisedut
Puhelin- ja ravintoetu huomioidaan yleensä tulona, koska niistä aiheutuvat kustannukset sisältyvät perustoimeentulotuen perusosaan. Luontoisedut huomioidaan toimeentulotuen laskelmalla ansiotulona niiden verotusarvon mukaisesti.
