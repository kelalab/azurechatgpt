#### 1.1.7.1 Tietopyyntö rahalaitokselta
Pääsääntö on, että asiakas toimittaa itse kaikki asian ratkaisemiseksi tarvittavat selvitykset. Jos asiakas ei pyydettäessä toimita tarvittavia selvityksiä, hakemus yleensä hylätään, jos tukea ei ole ehditty vielä maksaa asiakkaalle. Vasta viimesijaisena keinona voidaan tietoja pyytää rahalaitoksilta. Rahalaitoksia ovat pankit, muut luottolaitokset sekä rahamarkkinarahastot.
Rahalaitostiedustelu voidaan tehdä vain, jos
 - riittäviä tietoja ja selvityksiä ei muutoin saada ja
 - on perusteltua syytä epäillä asiakkaan tai hänen laillisen edustajansa antamien tietojen riittävyyttä ja luotettavuutta.

Asiakasta tulee kuulla ennen rahalaitostiedustelun tekemistä. Asiakasta pyydetään samalla itse toimittamaan puuttuvat tiedot. Jos kuulemisen jälkeenkään käytettävissä olevia tietoja ei voida pitää riittävinä ja luotettavina, tehdään rahalaitostiedustelun tekemisestä päätös. Päätös tehdään vain niistä puuttuvista selvityksistä, joista asiakasta on kuultu. Kun päätös on lainvoimainen, voidaan tietopyyntö rahalaitokselle tehdä. Rahalaitokselta pyydettävien tietojen tulee olla välttämättömiä toimeentulotukioikeuden selvittämiseksi. Lue lisää väärinkäytösepäilyn selvittämisen prosessista .
>ESIMERKKI: Minna on pitkäaikainen toimeentulotuen asiakas. Minna on toimittanut tiliotteen toimeentulotukihakemuksensa liitteeksi ja tiliotteelta käy ilmi toinen Minnan nimissä oleva tili, josta hän ei ole ilmoittanut Kelaan. Minnaa pyydetään toimittamaan tiliotteet toisesta tilistään ja samalla kuullaan rahalaitostiedustelun tekemisestä. Minna ei toimita pyydettyjä tiliotteita, joten hänelle tehdään päätös rahalaitostiedustelun tekemisestä, jonka jälkeen Kela pyytää kyseiset tiedot rahalaitokselta.


