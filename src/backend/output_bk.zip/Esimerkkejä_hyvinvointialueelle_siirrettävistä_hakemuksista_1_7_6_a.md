#### 1.7.6.a Esimerkkejä hyvinvointialueelle siirrettävistä hakemuksista 
Jos asiakas pyytää hyvinvointialueelle siirtoa, hakemus siirretään hyvinvointialueelle riippumatta siitä, syntyykö asiakkaalle oikeutta perustoimeentulotukeen, jos hakemuksessa on muita kuin perusosalla tai muina perusmenoina huomioitavia menoeriä, esimerkiksi
 - lapsen harrastemenot
 - huonekalut ja niihin rinnastuvat kodin hankinnat
 - lastenvaunut
 - toisen asteen ensimmäistä tutkintoa suorittavien nuorten opiskeluun liittyvät menot
 - edunvalvontapalkkio
 - hautajaiskulut
 - avopalveluista johtuvat, kuukausittain toistuvat menot, esimerkiksi ateriamaksu, joita perustoimeentulotuessa ei huomioida, voidaan poikkeuksellisesti siirtää kuntaan käsiteltäväksi.

