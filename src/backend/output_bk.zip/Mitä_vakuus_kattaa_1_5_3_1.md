#### 1.5.3.1 Mitä vakuus kattaa
Vakuudella voidaan kattaa vakuuden voimassaoloaikana syntyneet ja erääntyneet
 - laiminlyödyt sähköenergia- ja sähkönsiirtomaksut sekä palvelumaksut
 - sähköjen katkaisemiseen ja kytkemiseen liittyvät maksut
 - laskutuslisät, perintäkulut ja toimistokulut

Sähkövakuudesta ei korvata maksuja, jotka ovat syntyneet ennen vakuuden antamista.
