#### 1.3.4.3 Elatusapu
Lapsesta maksettava elatusapu huomioidaan tulona sille vanhemmalle tai lapselle, jolle se maksetaan.
 - Jos elatusapua tosiasiallisesti maksetaan, se huomioidaan tulona, vaikka elatusavusta ei olisi kunnan tai hyvinvointialueen toimielimen vahvistamaa sopimusta tai tuomioistuimen päätöstä.
 - Jos elatusavusta on kunnan tai hyvinvointialueen toimielimen vahvistama sopimus tai tuomioistuimen päätös, mutta sitä ei tosiasiallisesti makseta, ei elatusapua huomioida tulona.
 - Jos elatusapua maksetaan osittain, huomioidaan tulona vain tosiasiallisesti maksettu määrä.

Jos elatusapua ei makseta tai sitä maksetaan liian vähän, tulee aina selvittää lapsesta erillään asuvan vanhemman elatuskyky ja tarvittaessa määrätä takaisinperinnästä.
Lue lisää vanhemman elatusvelvollisuudesta .
