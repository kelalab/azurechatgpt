#### 1.7.4.4 Selvitykset menoista
Perusosaan kuuluvista menoista ei tarvitse toimittaa selvitystä. Poikkeuksen tästä muodostavat kuitenkin esimerkiksi laitoshoidossa olevat ja vankeusrangaistusta tai asevelvollisuutta suorittavat asiakkaat.
Hakemukseen tarvitaan liitteeksi laskut, kuitit tai muu välttämätön selvitys muista perusmenoista, jotka halutaan otettavaksi huomioon perustoimeentulotuessa. Menojen eräpäivän tulee kohdistua ajalle, jolle perustoimeentulotukea on haettu. Menoselvityksiä pyydetään toimittamaan hakemuksen yhteydessä, mutta niitä voidaan toimittaa myös jälkikäteen. Maksetuista laskuista riittää yleensä laskukopio.
Jos asiakkaalle on jo myönnetty perustoimeentulotukea ja hän hakee samaan menoon uudestaan samalle ajanjaksolle perustoimeentulotukea, Kela ei voi sitä myöntää. Asiakas ohjataan hyvinvointialueen sosiaalipalveluihin, joka voi harkita menon huomioimisen täydentävän tai ehkäisevän toimeentulotuen menona.
Lue lisää menojen huomioimisesta .
