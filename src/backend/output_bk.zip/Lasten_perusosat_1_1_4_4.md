#### 1.1.4.4 Lasten perusosat
Alaikäiset lapset kuuluvat yleensä vanhempiensa toimeentulotukiperheeseen. Lapselle huomioidaan iän mukainen perusosa.
Jos kyseessä on vuoroasuva lapsi, jaetaan lapsen perusosa vanhempien kesken. Samoin, jos lapsi asuu puolet ajasta vanhemman ja muun huoltajan luona, lapsen perusosa jaetaan vanhemman ja lapsen oman laskelman kesken.
Alaikäinen lapsi voi myös asua yksin ja lapselle voidaan myöntää toimeentulotukea toimeentulotuen myöntämisen edellytysten täyttyessä kuten muillekin hakijoille. Yksin asuvalle alaikäiselle tehdään oma toimeentulotukipäätös ja hänen perusosanaan käytetään yksin asuvan perusosaa.
Jos avopuolisoista molemmat tai toinen ovat alaikäisiä, he eivät muodosta yhdessä toimeentulotukiperhettä. Molemmille tehdään oma toimeentulotukipäätös. Perusosina käytetään tällöin yhteistaloudessa asuvien 18 vuotta täyttäneiden perusosaa, joka on 85 % yksin asuvan perusosasta.
Lapselle, joka asuu muun henkilön kuin oman vanhempansa luona, huomioidaan iän mukainen perusosa.
Lue lisää alaikäisistä ja perusosien ja asumismenojen huomioimisesta .

