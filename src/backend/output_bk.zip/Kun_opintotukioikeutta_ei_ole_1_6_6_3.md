#### 1.6.6.3 Kun opintotukioikeutta ei ole
Jos opinnot eivät oikeuta opintotukeen tai oikeus opintotukeen on päättynyt, tulee opiskelijan tilanteesta riippuen
 - ilmoittautua työmarkkinoiden käytettävissä olevaksi työttömäksi työnhakijaksi,
 - hakeutua opintotuella tuettuihin opintoihin tai
 - hankkia elatuksensa ansiotyöllä.

Jos oikeus opintotukeen on päättynyt, on aina selvitettävä mahdollisuus opintotukiajan pidentämiseen:
 - Korkeakouluopintojen opintotukiaikaa voidaan opintotukilain mukaan pidentää. Tukiajan pidennyksen voi saada vain, jos opinnot ovat viivästyneet sairauden tai muun erityisen painavan syyn takia. Opintotukiajan pidentäminen kuuluu opintotukiharkintaan.

 - Toisen asteen opiskelija saa opintotukea ensin opintojen laajuutta vastaavaksi ajaksi. Jos opinnot jatkuvat sen jälkeen, hän voi hakea lisäajalle tukea erikseen.

Opintotuen jatkuvan saamisen edellytyksenä on opinnoissa edistyminen. Jos opintotuki on opintojen riittämättömän edistymisen vuoksi lakkautettu, opiskelijan edellytetään suorittavan opintotuen lakkautuspäätöksessä selvitetyt opinnot saadakseen takaisin opintotukioikeuden. Jos opiskelija ei etene opinnoissaan riittävästi, voidaan harkita perusosan alentamista.
Jos opiskelijalla ei ole oikeutta opintotukeen, tulee selvittää tarkemmin hänen tilanteensa ja siihen mahdollisesti sopivat Kelan etuudet, kuten esimerkiksi kuntoutusraha, työmarkkinatuki tai sairauspäiväraha.
