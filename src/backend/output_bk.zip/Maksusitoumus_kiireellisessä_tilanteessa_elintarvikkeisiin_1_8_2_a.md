#### 1.8.2.a Maksusitoumus kiireellisessä tilanteessa elintarvikkeisiin 
Kiireellisessä tilanteessa välttämätön tuki voidaan maksaa kokonaan maksusitoumuksilla. Hakijan suostumuksella kiireellisessä tilanteessa maksusitoumus voidaan myöntää elintarvikkeisiin. Hakijan suostumus pyydetään suullisesti tai kirjallisesti hakemisen yhteydessä. Maksusitoumuksen vaihtoehtona on tuen maksaminen pankkitilille. Lue lisää Maksuosoite . 
Katso lisää kiireellinen toimeentulotuki ja maksusitoumus elintarvikkeisiin prosessi . 
 
