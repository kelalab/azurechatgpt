##### 1.5.3.3.a Uuden sähkövakuuden myöntäminen, kun edellinen on realisoitunut
Sähkövakuuden realisoiminen päättää aina sähkövakuuden voimassaolon.
Jos sähkösopimus jatkuu edellisen vakuuden realisoimisen jälkeen ja asiakas on oikeutettu perustoimeentulotukeen, Kela voi jatkaa maksusitoumuksena annetun vakuuden voimassaoloa ilman erillistä hakemusta. Sähköyhtiön tulee ilmoittaa realisointivaatimuksessa, jatkuuko asiakkaan sopimus realisoinnista huolimatta.
Kun asiakkaan sähkövakuus realisoituu, käsittelijä ottaa aina yhteyttä asiakkaaseen sosiaalityöntarpeen selvittämiseksi. Tarvittaessa tehdään sosiaalityön ilmoitus. Lue lisää sähkövakuuden myöntämisestä. 
