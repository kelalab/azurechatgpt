##### 1.3.4.4.a Vuokratulo omistusasunnosta
Tulona huomioidaan vuokralla olevan omaisuuden vuokratulo.
Vuokratulosta voidaan vähentää tulonhankkimiskuluina vuokralla olevan huoneiston hoitovastike, saman asunnon lainan korkomenoja, jos asunto on hankittu lainarahoituksella, sekä maksettu ennakkoveron määrä. Tulonhankkimiskulut voidaan vähentää
 - niiden aiheutumiskuukautena saadusta vuokratulosta,
 - vain kyseisen huoneiston vuokrauksesta saadusta vuokratulosta ja
 - vain, jos kulut on maksettu.

Jos kulua ei ole maksettu, on vuokratulo tältä osin käytettävissä hakijan omaan elatukseen.
Hakijan tulee toimittaa kuukausikohtainen selvitys, josta käy ilmi
 - saadun vuokratulon määrä,
 - maksetut vastikkeet ja ennakkoverot sekä
 - vuokralla olevaan asuntoon mahdollisesti kohdistuvat kuukausikohtaiset korkomenot.

Vuokrattuun omaisuuteen määrätään yleensä takaisinperintä .
