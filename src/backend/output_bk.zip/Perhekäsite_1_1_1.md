### 1.1.1 Perhekäsite
Perustoimeentulotuki on perhekohtainen etuus. Tuen määrä ratkaistaan koko perheelle yhteisesti. Toimeentulotuessa perheellä tarkoitetaan yhteistaloudessa asuvia
 - vanhempia,
 - vanhemman alaikäistä lasta,
 - aviopuolisoita,
 - kahta henkilöä, jotka elävät avioliitonomaisissa olosuhteissa sekä
 - rekisteröidyn parisuhteen osapuolia.

Toimeentulotukilaskelmassa huomioidaan kaikkien perheenjäsenten käytettävissä olevat tulot ja varat sekä perustoimeentulotuessa huomioitavat menot. Toimeentulotukea myönnettäessä kaikkia perheenjäseniä pidetään toimeentulotuen saajina. Pääsääntö on, että toimeentulotuen katsotaan jakautuvan sen saajien kesken kullekin yhtä suurena osuutena. Jos toimeentulotukiperheessä on yhteistaloudessa asuvat avo- tai aviopuolisot, joista toinen on edunvalvonnassa, tulee maksettavan toimeentulotuen jakaminen selvittää. Lue lisää toimeentulotuen jakamisesta, kun hakija tai puoliso on edunvalvonnassa. 
Toimeentulotukiperheiden muodostuminen tietyissä tilanteissa:
 - Avioliitonomaisia olosuhteita arvioitaessa lähtökohtana pidetään henkilöiden omaa ilmoitusta. Suhteen tulkitseminen avoliitoksi harkitaan tapauskohtaisesti ja ratkaisu tehdään kokonaisharkinnan perusteella. Harkinnassa otetaan huomioon esimerkiksi asunnon koko, yhdessä asumisen kesto, keskinäiset tilisiirrot, yhteinen asumishistoria, yhteiset lapset, vuokrasopimuksesta ja vuokranmaksusta saadut selvitykset sekä muista asumisolosuhteista saadut tiedot.
 - Täysi-ikäinen lapsi ei ole samaa toimeentulotukiperhettä vanhempiensa kanssa, vaikka hän asuisi samassa asunnossa. Täysi-ikäisen lapsen tulee hakea toimeentulotukea omalla hakemuksella. Katso myös vanhempien luona asuvan 18 vuotta täyttäneen perusosa ja asumismenojen jakaminen perheiden kesken.
 - Muun henkilön kuin oman vanhempansa luona asuva alaikäinen lapsi muodostaa toimeentulotuessa oman perheen. Tällöin lapsen toimeentulotuen määrään eivät vaikuta lapsen hoitajan tai lapsen muualla asuvan vanhempansa tulot ja varat. Katso myös muita tilanteita kohdasta alaikäinen .

 - Jos isovanhempi tai isovanhemmat asuvat perheen kanssa samassa taloudessa, hänen tai heidän katsotaan muodostavan oman perheen. Isovanhemman tai isovanhempien tulee hakea toimeentulotukea omalla hakemuksella. Asumismenot ja asumistuki jaetaan perheiden kesken. Lue lisää asumismenojen jakamisesta perheiden kesken .

 - Jos toinen puolisoista on avohuollon asumispalvelussa, pitkäaikaisessa laitoshoidossa tai vankilassa , heidän ei katsota tosiasiallisesti elävän yhteistaloudessa. Kummallekin tehdään oma laskelma, koska he eivät muodosta toimeentulotukilain mukaista perhettä.

