#### 1.11.1.3 Päätöksen korjaaminen asiakkaan vahingoksi, kun virhe on ilmeinen ja kysymys on hakijan menettelystä
Näissä tilanteissa on yleensä kyse väärinkäytöksestä ja sovelletaan päätöksen tarkistamista koskevia ohjeita. Lue lisää ilmoitusvelvollisuuden laiminlyönnistä .
