##### 1.5.2.2.1 Omatoimimuutto
Pääsääntö on, että asiakas järjestää muuton omatoimisesti. Jos asiakas on hakenut toimeentulotukea muuttokustannuksiin ja muuttoa voidaan pitää perusteltuna, voidaan laskelmalla huomioida muuttoraha menona. Muuttoraha sisältää asuinirtaimiston kuljetusmenot sekä muut muutosta aiheutuvat välttämättömät kustannukset. Muuttoraha on toimeentulotukiperhekohtainen ja se voidaan huomioida joko etukäteen tai jälkikäteen.
Muuttorahan määrä, kun:
 - muuton lähtöosoitteesta on alle 200 km muutettavaan kohdeosoitteeseen 120 euroa (1-3 henkilön toimeentulotukiperhe) 180 euroa (4 tai useamman henkilön toimeentulotukiperhe)

 - muuton lähtöosoitteesta on yli 200 km muutettavaan kohdeosoitteeseen 180 euroa (toimeentulotukiperheen henkilömäärästä riippumatta)

Muuttokulut huomioidaan kuitenkin todellisen suuruisina, jos asiakas hakee toimeentulotukea muuttorahaa pienemmälle summalle. Asiakkaan ei edellä mainituissa tilanteissa tarvitse toimittaa muuttokustannuksista tositteita.
Jos asiakas hakee omatoimimuuton kustannuksia enemmän kuin muuttorahan verran, voidaan kuluja huomioida poikkeuksellisesti myös yllä mainittuja summia enemmän, jos:
 - asiakkaan muuttomatka on pitkä, esimerkiksi 500 km muuton lähtöosoitteesta kohdeosoitteeseen ja/tai
 - perheen koko on poikkeuksellisen suuri.

Näissä tilanteissa voidaan harkinnalla korvata välttämättömät ja kohtuulliset kustannukset, jotka ovat asiakkaalle todellisuudessa aiheutuneet. Asiakkaan tulee toimittaa aiheutuneista kustannuksista esimerkiksi polttoainekuluista kuitit.
>ESIMERKKI: Matin seitsemänhenkinen perhe muuttaa vanhempien työn takia Lappeenrannasta Seinäjoelle. Välimatka on 420 kilometriä. Matille on myönnetty muuttoraha 180 euroa etukäteen. Muuton jälkeen Matti ilmoittaa, että muuton kustannukset ovat yhteensä olleet 280 euroa. Mattia pyydetään toimittamaan kuitit kaikista muutosta aiheutuneista kuluista. Matti toimittaa kuitit muuttoauton vuokrasta (200 euroa) ja polttoainekuluista (80 euroa). Menona voidaan huomioida muuttorahan ylimenevät kustannukset eli 100 euroa, koska matka on ollut pitkä ja perheen koko huomioon ottaen kustannukset ovat kohtuulliset.

