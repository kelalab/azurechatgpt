#### 1.8.3.b Maksuosoitus
Poikkeustapauksessa toimeentulotuki voidaan maksaa myös maksuosoituksena pankille, jos tilille maksaminen tai Prepaid-kortin käyttäminen ei ole mahdollista ja jos hakija esittää Kelalle erityisen syyn.
Maksuosoituksen käyttö edellyttää, että asiakkaalla on Suomessa postiosoite sekä henkilöllisyystodistus. Lisätietoa maksuosoituksen käyttämisestä.
