###### 1.5.1.4.1.a Vuokra-asunnon asumismenojen kohtuullisuus
Kohtuullisuusharkinnassa hakijan vuokraa verrataan Kelan asumisnormiin. Jos vesimaksu sisältyy vuokraan, korotetaan asumisnormia 24,00 eurolla/henkilö 1.1.2023 alkaen (22,80 eurolla/henkilö vuonna 2022). 

>ESIMERKKI: Aunen vuokra sisältää vesimaksun ja on suuruudeltaan 495 euroa. Paikkakunnan vuokranormi on 475 euroa. Aunen maksamaa vuokraa verrataan vuokran ja vesinormin yhteismäärään eli 499,00 euroon (475 e + 24,00 e). Aunen vuokraa voidaan pitää kohtuullisena ja se voidaan hyväksyä kokonaisuudessaan menona laskelmalla.

Jos vuokra ylittää asumisnormin, harkitaan asumismenojen kohtuullisuutta. Katso kohta asumismenot ylittävät Kelan asumisnormin .
