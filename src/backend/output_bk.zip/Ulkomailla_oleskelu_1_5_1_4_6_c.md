###### 1.5.1.4.6.c Ulkomailla oleskelu
Lisätietoa ulkomailla oleskelevan henkilön asumismenojen huomioimisesta.
