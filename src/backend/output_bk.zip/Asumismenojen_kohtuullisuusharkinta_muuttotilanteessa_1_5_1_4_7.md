##### 1.5.1.4.7 Asumismenojen kohtuullisuusharkinta muuttotilanteessa
Asumismenojen kohtuullisuutta tulee arvioida myös silloin, kun hakija muuttaa. Yleensä hakijan muuttoa tuetaan vain sellaiseen asuntoon, joka vastaa kustannuksiltaan paikkakunnan asumisnormia. Katso muuton perusteet . Asumismenot voivat kuitenkin ylittää vähäisesti, noin 5 %, Kelan asumisnormin.
Jos uuden asunnon asumismenot ylittävät Kelan asumisnormin, selvitetään
 - onko hakijalla erityisiä perusteita Kelan asumisnormin ylittäville asumiskustannuksille
 - onko paikkakunnalla tarjolla edullisempia asuntoja
 - onko hakija hakenut edullisempaa asuntoa

Perustellusta syystä vuokravakuus ja muuttokustannukset voidaan hyväksyä myös kohtuuhintaista kalliimpaan asuntoon. Perusteltuja syitä voi olla esimerkiksi
 - katso yleisen asumistuen ohjeesta , milloin apuvälineet aiheuttavat lisätilan tarvetta
 - asiakkaan terveydentila, esimerkiksi hissin tarve talossa
 - kunnan järjestämä tuettu asuminen

Jos muuttoa kohtuullista tasoa kalliimpaan asuntoon tuetaan vuokravakuudella, asumismenot hyväksytään kokonaisuudessaan ja muuttokehotus edullisempaan asuntoon annetaan vuoden kuluttua tai kun määräaikainen vuokrasopimus on päättymässä. Hakijalle kerrotaan vuokravakuutta myönnettäessä, että vuokravakuus on myönnetty poikkeuksellisesti kohtuullisen tason ylittävään asuntoon ja määräajan kuluttua kohtuullisuutta arvioidaan uudelleen.
>ESIMERKKI: Antti on asunnoton ja hänellä on päihdeongelma. Kunta on hankkinut hänelle asunnon, jossa tuetaan päihteetöntä elämää ja asumista. Vuokra ylittää Kelan kohtuullisena pidetyn vuokran 150 euroa. Antti myönnetään vuokravakuus asuntoon, koska kunta on järjestänyt asunnon ja asiasta on saatu myös selvitys sosiaalitoimelta.

Vuokravakuutta Kelan asumisnormin ylittävään asuntoon ei myönnetä, jos edullisempia asuntoja on tarjolla. Hakijaa ohjataan hakemaan edullisempaa asuntoa.
Jos hakija muuttaa Kelan ohjauksesta huolimatta Kelan asumisnormin ylittävään asuntoon, kohtuullistetaan asumiskustannukset välittömästi. Asumismenot voidaan kohtuullistaa välittömästi, jos hakijan voidaan katsoa tienneen Kelan asumisnormeista, vaikka hakija ei olisi hakenut Kelasta toimeentulotukea muuttoon liittyviin menoihin. Hakijan katsotaan tienneen Kelan asumisnormeista, jos hakijalle on kerrottu normeista päätöksellä, yhteydenoton yhteydessä tai asiakasta on ohjattu hakemaan edullisempaa asuntoa.
