##### 1.6.5.3.b Sosiaali- ja päihdehuollon palvelut
Sosiaali- ja päihdehuoltolain perusteella määrätyistä asiakasmaksuista voidaan huomioida menoina ne osuudet, jotka kuuluvat perustoimeentulotuen muihin perusmenoihin (esimerkiksi asuminen ja terveydenhuoltomenot). Jos palvelu sisältää ateriat, vähennetään asiakkaan perusosasta ravintomenot heti palvelun alkaessa. Jos asiakasmaksun sisällöstä ei saada riittäviä tietoja, ei asiakasmaksua huomioida menona.
Jos palvelut, joista asiakas- ja palvelumaksut peritään, eivät kuulu muihin perusmenoihin tai ne sisältyvät perusosaan, niitä ei huomioida. Tällaisia menoja ovat esimerkiksi ateriamaksu.
Poikkeuksellisesti näitä päihdehuollosta syntyviä kuukausittain toistuvia menoja voidaan asiakkaan pyynnöstä siirtää suoraan hyvinvointialueelle käsiteltäväksi.
Jos asiakkaalla ei ole hyvinvointialueen maksusitoumusta tai -päätöstä päihdehuoltoon, hänen katsotaan käyttävän yksityisiä palveluita eikä maksuihin pääsääntöisesti myönnetä perustoimeentulotukea. Lue lisää yksityisen terveydenhuollon kustannuksista .
Lue lisää avo- ja laitospalvelut prosessista ja asiakasmaksun alentamisesta tai perimättä jättämisestä .
