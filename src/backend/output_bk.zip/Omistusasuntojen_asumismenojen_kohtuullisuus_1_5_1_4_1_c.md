###### 1.5.1.4.1.c Omistusasuntojen asumismenojen kohtuullisuus
Omistusasunnon hyväksyttävät menot lasketaan yhteen ja kokonaiskustannuksia verrataan paikkakunnan asumisnormiin.
 - Osakeasunnossa kohtuullisuusarvioinnissa lasketaan yhteen asiakkaan esittämät hyväksyttävät vastikkeet, muut hoitomenot, lämmitys, jos se ei kuulu vastikkeeseen sekä henkilökohtaisen asuntolainan korot. Jos asunnossa on sähkölämmitys, joka laskutetaan yhdessä taloussähkön kanssa, korotetaan määrää taloussähkön normilla. Jos vesimaksu sisältyy vastikkeeseen, voidaan asumisnormia korottaa 24,00 eurolla/henkilö.

 - Omakotitalon kohtuullisuusarvioinnissa lasketaan yhteen asiakkaan esittämät omakotitalon hoitomenot, lämmitys sekä henkilökohtaisten asuntolainojen korot. Jos asunnossa on sähkölämmitys, joka laskutetaan yhdessä taloussähkön kanssa, korotetaan määrää taloussähkön normilla. Vesimaksu voidaan hyväksyä 24,00 e/henkilö.

Jos kokonaiskustannukset ylittävät asumisnormin, harkitaan asumismenojen kohtuullisuutta. Katso kohta asumismenot ylittävät Kelan asumisnormin .
