##### 1.5.1.3.a Täysi-ikäinen lapsi asuu vanhempiensa luona
Jos hakija on yli 18-vuotias ja hän asuu vanhempiensa luona, tehdään täysi-ikäiselle lapselle oma laskelma. Pääsääntö on, että täysi-ikäiselle hakijalle huomioidaan hänen osuutensa perheen asumismenoista.
 - Jos hakija on tehnyt vanhemman kanssa vuokrasopimuksen, huomioidaan vuokrasta kohtuullinen osuus menona.
 - Jos vuokrasopimusta ei ole tehty, huomioidaan hakijalle pääluvun mukainen osuus asumismenoista.

Tulona huomioidaan hakijan osuus yleisestä asumistuesta.
>ESIMERKKI: Minna asuu yhdessä 22-vuotiaan tyttärensä Veeran kanssa. Veera on sähköasentaja ja käy säännöllisessä ansiotyössä. Minna on työtön ja hakee toimeentulotukea. Minna esittää maksavansa yksin asunnon asumismenot yhteensä 700 euroa. Asumismenoista voidaan huomioida Minnalle puolet eli 350 euroa ja mahdollisesta asumistuesta puolet tuloksi.

Edellä mainitusta pääsäännöstä voidaan poiketa, jos täysi-ikäinen hakija on tuloton. Tällöin asumismenot huomioidaan kokonaan vanhempien menoksi ja asumistuki vanhempien tuloksi.
Jos hakijalla on alivuokralainen, huomioidaan asumismenoina osuus, josta on vähennetty alivuokralaisen maksaman vuokran määrä.
Katso myös taulukko perusosien ja asumismenojen huomioimisesta .
