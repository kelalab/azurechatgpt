#### 1.7.9.2 Esteellisyyden toteaminen
