### 1.6.6 Opiskelija
Opiskelijan ensisijaiset etuudet ovat opintotuki sekä yleinen asumistuki. Opiskelijan tulona voi olla myös esimerkiksi aikuiskoulutustuki tai oppisopimusopiskelijan erilaiset taloudelliset tuet. Jos ensisijaiset etuudet tai muut tulot ja varat eivät riitä toimeentulon turvaamiseen, voi opiskelijalla olla oikeus toimeentulotukeen.
Jos opiskelija suorittaa toimeentulotuen turvin opintoja, jotka eivät oikeuta opintotukeen tai oikeus opintotukeen on päättynyt, kyseeseen voi tulla perusosan alentaminen.
