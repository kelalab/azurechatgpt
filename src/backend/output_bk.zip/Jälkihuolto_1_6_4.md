### 1.6.4 Jälkihuolto
Jälkihuolto on sijaishuollon tai pitkän avohuollon sijoituksen päättymisen jälkeen lastensuojelulain nojalla annettavaa taloudellista ja muuta tukea. Hyvinvointialueen velvollisuus jälkihuollon järjestämiseen päättyy 5 vuoden kuluttua siitä, kun lapsi on sijoittamisen päättymisen jälkeen ollut viimeksi lastensuojelun asiakas ja viimeistään, kun nuori täyttää 25 vuotta.
