#### 1.6.5.3 Päihdehuolto
Päihdehuollon palveluita järjestetään sekä terveydenhuollon (yleensä katkaisuhoito) että sosiaali- ja päihdehuollon palveluna (muut päihdehuollon palvelut). Laitoshoitona järjestetään pääasiassa lyhytaikaista katkaisuhoitoa ja kuntoutusta sekä pitkäaikaisempaa kuntoutusta tukevaa hoitoa hoito- ja huoltokodeissa.
