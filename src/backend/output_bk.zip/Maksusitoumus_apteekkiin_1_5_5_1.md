#### 1.5.5.1 Maksusitoumus apteekkiin
Maksusitoumus on henkilökohtainen ja se on yleensä voimassa saman ajan kuin perustoimeentulotukipäätös. Maksusitoumus voidaan antaa joissain tapauksissa myös lyhyemmäksi ajaksi. Maksusitoumusta ei voi myöntää takautuvalle ajalle.
 - Jos perustoimeentulotuen päätös tehdään loppukuusta, eikä asiakas ole hakenut perustoimeentulotukea tai hänellä ei ole oikeutta perustoimeentulotukeen seuraavana kuukautena, järjestelmä muodostaa asiakkaalle maksusitoumuksen. Maksusitoumuksen viimeinen voimassaolopäivä on kaksi viikkoa ratkaisupäivästä.

 - Jos hakemus ratkaistaan vasta seuraavan kuukauden puolella, myönnetään asiakkaalle kertakäyttöinen maksusitoumus. Lue lisää kertakäyttöisestä maksusitoumuksesta.

Lääkemaksusitoumukset ovat yleensä sähköisessä muodossa, jolloin apteekki saa tiedon maksusitoumuksesta Kelan suorakorvaustietojen kyselypalvelun kautta. Myös tieto maksusitoumuksen rajauksesta välittyy apteekkiin tätä kautta. Asiakas voi asioida haluamassaan apteekissa, ellei esimerkiksi annosjakelu- tai apteekkisopimusta ole tehty tietyn apteekin kanssa. Tieto maksusitoumuksesta näkyy apteekissa yleensä päätöksen antamista seuraavana päivänä. Perustoimeentulotukipäätöksen mukana asiakas saa ohjeen maksusitoumuksen käyttämiseen.
Yleensä asiakkaalla on voimassa yksi maksusitoumus samalle ajanjaksolle. Jos maksusitoumuksen sisältö muuttuu kesken myöntöjakson, voimassa oleva maksusitoumus lakkautetaan ja uusi maksusitoumus myönnetään uusin ehdoin. Maksusitoumus lakkautetaan näissä tilanteisessa heti ja uusi maksusitoumus saatetaan voimaan samasta ajankohdasta.
Maksusitoumustyypit ovat:
