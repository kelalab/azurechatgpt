#### 1.9.2.2 Lastensuojelulakiin perustuva lastensuojeluilmoitus hyvinvointialueelle
Kelan toimihenkilöillä on tarpeen vaatiessa myös ilman asiakkaan suostumusta velvollisuus viipymättä tehdä salassapitosäännösten estämättä lastensuojeluilmoitus hyvinvointialueelle. Lastensuojelulain mukainen lastensuojeluilmoitus tehdään, jos Kelan työntekijä on saanut tehtävässään tietää lapsesta, jonka hoidon ja huolenpidon tarve, kehitystä vaarantavat olosuhteet tai oma käyttäytyminen edellyttävät lastensuojelutarpeen selvittämistä. Lastensuojeluilmoituksen tekemiseen on velvoitettu se henkilö, joka on saanut tietää mahdollisesta lastensuojelun tarpeesta. Käsittelijä voi konsultoida esimiestään tai osaamiskeskusta lastensuojeluilmoituksen tekemisestä. Lapsiin liittyvissä asioissa voi tarvittaessa konsultoida myös hyvinvointialueen lastensuojelua anonyymisti.
Lastensuojeluilmoituksen syynä voi olla esimerkiksi:
 - lapsen tarpeiden laiminlyönti, lapsen heitteillejättö, lapsen pahoinpitely tai seksuaalinen hyväksikäyttö tai niiden epäily tai uhka
 - lapsen hoidossa tai huolenpidossa muuten havaitut puutteet tai osaamattomuus, joka vaarantaa lapsen hyvinvointia
 - lapsesta huolehtivan aikuisen päihde- tai mielenterveysongelmat, jaksamattomuus tai oman hoidon laiminlyöminen tai myös arjen tukiverkon puuttuminen silloin, kun se saattaa vaarantaa lapsen hyvinvointia
 - lapsen oma päihteiden käyttö, mielenterveysongelmat, rikoksilla oireilu tai lapsen itsetuhoisuus

Lastensuojeluilmoitus tehdään aina lapsen tai lasten nimillä. Ilmoitus tehdään jokaisesta lapsesta erikseen. Ennakollinen lastensuojeluilmoitus (koskee syntymätöntä lasta tai lapsia) tehdään raskaana olevan henkilön nimellä. Ilmoitus tehdään ensisijaisesti yhdessä lapsen tai hänen vanhempansa kanssa keskustellen huolta herättävästä tilanteesta. Ilmoitus tulee kuitenkin aina tehdä viipymättä myös, vaikka suostumusta ei saataisi. Suostumuksen hankkiminen ei saa viivästyttää ilmoituksen tekemistä siten, että lapsen tilanne vaarantuu. Ilman asiakkaan suostumusta tehdystä ilmoituksesta informoidaan asiakasta.
Kiireellisessä tilanteessa lastensuojeluilmoitus tehdään ottamalla yhteyttä hyvinvointialueen sosiaalipalveluihin.
Ilmoitukseen kirjataan:
 - ilmoituksen syy, perusteet ja ilmoituksen tekemiseen johtaneet tapahtumat
 - tieto siitä, onko lapselle tai tämän huoltajalle kerrottu ilmoituksen tekemisestä
 - ilmoittajan nimi ja yhteystiedot mahdollista lisätietojen selvittämistä varten

Lue lisää lastensuojelulakiin perustuvan ilmoituksen tekemisestä hyvinvointialueelle .
