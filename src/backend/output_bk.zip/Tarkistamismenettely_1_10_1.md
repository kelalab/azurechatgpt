### 1.10.1 Tarkistamismenettely
Päätös voidaan tarkistaa joko
 - asiakkaan hakemuksen tai yhteydenoton perusteella tai
 - Kelan aloitteesta, esimerkiksi tulorekisteristä tai työeläkelaitoksesta saadun tiedon perusteella.

Päätöksen tarkistamiseen ei tarvita asiakkaan suostumusta. Tarkistamismenettelyn yhteydessä on kuitenkin huolehdittava asian riittävästä selvittämisestä ja tarvittaessa asiakkaan kuulemisesta.
Tarkistus voi vaikuttaa asiakkaille myönnettyihin maksusitoumuksiin. Lue tarkemmin etuusprosessista .
