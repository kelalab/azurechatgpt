### 1.8.1 Osissa maksaminen
Perustoimeentulotuki maksetaan yleensä yhdessä osassa. Maksu on kuitenkin mahdollista jakaa asiakkaalle maksettaessa kahteen tai neljään yhtä suureen osaan. Silloin maksupäivät ovat kuukauden 1., 9., 16., ja 23. päivä. Ensimmäinen osa maksetaan yleensä kuun ensimmäisenä pankkipäivänä. Muuna kuin säännöllisenä maksupäivänä maksettu perustoimeentulotuki maksetaan takautuvalta osin aina yhdessä osassa.
Osissa maksamisen tarkoitus on tukea hakijaa taloudellisen tilanteen hallitsemisessa ja se voidaan tehdä asiakkaan suostumuksella. Osissa maksaminen tehdään vähintään kuukaudeksi kerrallaan. Se on voimassa myös tulevissa ratkaisuissa, ellei asiakas pyydä muutosta maksamisen tapaan. Osissa maksamista ei muuteta kesken kuukauden.
Lue lisää osissa maksamisesta .
