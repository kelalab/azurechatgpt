###### 1.5.1.1.5.b Kimppa-asunto
Kimppa-asuntoihin sovelletaan samoja periaatteita kuin muuhun vuokra-asumiseen. Kimppa-asunnon menot huomioidaan yleensä vuokrasopimuksen mukaisesti, jos menot ovat kohtuulliset .
Katso kohta Vuokra-asunto .
