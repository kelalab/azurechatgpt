#### 1.7.13.a Tuloylijäämä
Jos tulot ylittävät menot, tuloksena on tuloylijäämä. Jos toimeentulotukea haetaan edelleen, ylijäämä siirtyy seuraavalle kuukaudelle tuloksi, ellei sen määrä ole vähäinen eikä sitä pidetä kohtuuttomana.
>ESIMERKKI: Tammikuun päätöksessä asiakkaalla on tuloylijäämää. Asiakas ei hae toimeentulotukea helmikuulle. Asiakas hakee toimeentulotukea maaliskuussa. Maaliskuun laskelmalle ei kopioidu tammikuun ylijäämä. Jos tulo on asiakkaan tilillä maaliskuussa, voidaan se huomioida varallisuutena.

