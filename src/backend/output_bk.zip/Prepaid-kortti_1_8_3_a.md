#### 1.8.3.a Prepaid-kortti
Toimeentulotuki voidaan maksaa Prepaid-kortille, jos asiakkaalla ei ole pankkitiliä eikä henkilöllisyystodistusta. Prepaid-kortille voidaan maksaa Kelan etuudet siihen saakka, kun asiakas on saanut avattua pankkitilin.
Lisätietoa Prepaid-kortin käyttämisestä.
Huomaa, että myös muut tahot voivat myöntää Prepaid-kortin kuten esimerkiksi Rikosseuraamuslaitos. Lue lisää Vankien toimeentulotuki - prosessista.
