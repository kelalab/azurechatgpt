#### 1.7.4.3 Selvitykset varallisuudesta
Asiakkaan tulee toimittaa selvitys kaikesta omasta sekä perheensä varallisuudesta, kuten esimerkiksi:
 - säästöistä
 - osakkeista ja rahastoista
 - kiinteistöistä
 - asunto-osakkeista
 - osuudesta kuolinpesään (perukirja)
 - kulkuneuvoista ja arvoesineistä sekä
 - virtuaalivaluutoista.

Selvityksestä tulee käydä ilmi, mistä varallisuudesta on kyse sekä varallisuuden arvo.
Lue lisää varallisuudesta .
