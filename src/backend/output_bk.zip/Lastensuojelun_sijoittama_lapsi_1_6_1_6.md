#### 1.6.1.6 Lastensuojelun sijoittama lapsi
Jos kyseessä on lastensuojelun sijoittama lapsi, lapsesta on lastensuojelun huostaanottopäätös tai sijoituspäätös joko lapsen sukulaiselle, sijaisperheeseen tai lastensuojelulaitokseen. Lastensuojelun sijoittama lapsi ei muodosta toimeentulotukiperhettä samassa taloudessa asuvien sijaisvanhempien tai muun sijaishuoltopaikan edustajan kanssa. Lastensuojelun sijoittamalla lapsella ei ole toimeentulotuen tarvetta, koska hyvinvointialue vastaa lapsen kustannuksista. Hyvinvointialue vastaa esimerkiksi lapsen:
 - ravinnosta,
 - asumisesta,
 - harrastuksista,
 - henkilökohtaisista tarpeista,
 - tavanomaisista terveydenhuollon kustannuksista,
 - lapsen käyttövaroista sekä
 - vanhemmalle lapsen tapaamisesta aiheutuvista kustannuksista siihen saakka, kunnes sijoitus on päättynyt.

Jos lastensuojelun sijoittamalle lapselle haetaan toimeentulotukea, toimeentulotuki yleensä hylätään, koska lapsen kaikki menot korvataan lastensuojelusta. Laskelmaa ei tehdä. Tarvittaessa asiaa selvitään yhdessä hyvinvointialueen lastensuojelun kanssa.
>ESIMERKKI: Hannan poika Kalle on huostaanotettu. Kalle on äitinsä luona viikoittain perjantaista sunnuntaihin. Hanna saa itselleen Kallesta maksettavan lapsilisän sekä elatustuen, joilla hänen tulee hyvinvointialueen mukaan kattaa Kallen tapaamisesta aiheutuneet kulut. Hannalle ei huomioida tulona näitä etuuksia eikä Hannalle huomioida menona Kallen tapaamiskuluja. Jos Kallesta aiheutuneet tapaamiskulut ylittävät lapsilisän ja elatustuen määrän, tulee Hannan hakea niihin tukea hyvinvointialueelta, koska hyvinvointialue vastaa tapaamiskuluista koko huostaanoton ajan. Hannalle huomioidaan yksinasuvan perusosa, koska lastensuojelu vastaa Kallen kustannuksista eikä Kalle asu pysyväisluonteisesti Hannan kanssa.

Lapsen toimeentulotukipäätös lähetetään aina lapselle ja tiedoksi lapsen huoltajalle sekä hyvinvointialueen lastensuojeluun. Katso myös lisää lapsen asioita koskevista tiedonsaantioikeuksista.
Jos lapsi on lastensuojelun sijoittamana perheessä, voidaan sijaisvanhemmalle huomioida yksinhuoltajan perusosa, jos hänellä ei ole puolisoa.
