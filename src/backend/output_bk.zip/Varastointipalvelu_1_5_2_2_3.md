##### 1.5.2.2.3 Varastointipalvelu
Varastointipalveluissa käytetään Kelan kilpailuttamia palveluntuottajia niillä paikkakunnilla, joilla Kela on tehnyt sopimukset varastointipalveluiden hankinnasta. Jos paikkakunnalla tai sen lähialueella ei ole tehty hankintasopimusta varastoinnista, hankitaan varastointipalvelu suoraan muulta palveluntuottajalta. Lue lisää varastointipalvelut -prosessista.
Varastointipalvelu myönnetään vain erityisen painavasta syystä ja lisäksi muuton tulee olla perusteltu. Käytännössä se tapahtuu ainoastaan silloin, kun
 - asiakas on saanut häädön vanhasta asunnosta eikä uutta asuntoa tai osoitetta vielä ole ja
 - asiakkaalla on suunnitelma asumisen järjestämiseksi, esimerkiksi hyvinvointialueen sosiaalipalveluissa tehty suunnitelma.

Asiakkaan tarve varastointipalvelulle tulee harkita kokonaisvaltaisesti ottaen huomioon asiakkaan kokonaistilanne sekä varastointipalvelun myöntämisen tarkoituksenmukaisuus. Varastointipalvelua voidaan yleensä tukea perustoimeentulotukena enintään 3 kuukauden ajan.
>ESIMERKKI: Ville on saanut häädön edellisestä asunnosta. Hyvinvointialueen sosiaalipalveluissa on tehty suunnitelma Villen asumisen järjestämiseksi. Ville on saamassa tukiasunnon kolmen kuukauden päästä. Ville saa kyseiseksi ajaksi tavaroilleen varastointipalvelun.

