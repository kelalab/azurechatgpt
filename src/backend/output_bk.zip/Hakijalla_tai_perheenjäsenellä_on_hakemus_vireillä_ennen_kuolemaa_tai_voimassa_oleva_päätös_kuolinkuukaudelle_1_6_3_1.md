#### 1.6.3.1 Hakijalla tai perheenjäsenellä on hakemus vireillä ennen kuolemaa tai voimassa oleva päätös kuolinkuukaudelle
