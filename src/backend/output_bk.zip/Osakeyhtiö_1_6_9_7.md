#### 1.6.9.7 Osakeyhtiö
Osakeyhtiön voi perustaa yksin tai yhdessä useamman henkilön kanssa. Osakeyhtiön on pidettävä julkista osakasluetteloa. Osakkeenomistajan vastuu yrityksen sitoumuksista ulottuu pelkästään omaan sijoitukseensa. Osakeyhtiö on itsenäinen verovelvollinen, eli sen tulo verotetaan osakeyhtiön tulona. Osakeyhtiön maksamat osingot ja palkat verotetaan osakkaiden henkilökohtaisessa verotuksessa. Osakeyhtiö on kirjanpitovelvollinen.
Jos asiakas on osakkaana osakeyhtiössä, selvitetään, työskenteleekö asiakas yrityksessä sekä omistaako hän lisäksi sellaisen osuuden yrityksen osakkeista, että häntä voidaan pitää yrittäjänä. Selvityksessä otetaan huomioon esimerkiksi määräysvallan suuruus ja muiden osakkaiden omistusosuudet. Jos asiakasta pidetään yrittäjänä, ei yrityksen osakkeita huomioida käytettävissä olevina varoina. Jos kyse on pelkästä osakkeiden omistajuudesta, ei asiakasta pidetä yrittäjänä ja omistetut osakkeet huomioidaan käytettävissä olevina varoina. Jos osakeyhtiössä työskentelevällä asiakkaalla on tämän toiminnan vuoksi YEL-vakuutus, on kyseessä toimeentulotuen näkökulmasta yleensä yrittäjä. Jos sen sijaan asiakas on osakkaana yrityksessä ja työskentelee siinä työntekijän lakisääteisellä työeläkevakuutuksella, on hän yleensä palkansaaja. Asiassa huomioidaan TE-palvelujen tulkinta tilanteesta. Kummassakin tapauksessa kaikki yrityksestä saadut tulot huomioidaan kuitenkin asiakkaan laskelmalla tulona. Lue lisää osakkeiden huomioimisesta .
Osakeyhtiön osakkaan tuloa voi esimerkiksi olla:
 - starttiraha
 - osingot
 - palkat ja palkkiot
 - luontoisedut (kuten asunto-, auto-, puhelin- tai ateriaetu)
 - varat jotka olisi mahdollista nostaa kyseisenä kuukautena palkkoina
 - yritystilin yksityiskäyttö
 - tavaroiden yksityiskäyttö
 - kohtuuttoman suuret kilometrikorvaukset ja päivärahat
 - lainat

Osakeyhtiön osakas ei saa tehdä yksityisottoja. Jos asiakas on kuitenkin tehnyt yksityisottoja, eli nostanut rahaa yrityksestä omaan käyttöönsä, huomioidaan ne ansiotulona laskelmalla.
Koska osakkeenomistaja ei voi nostaa yrityksestä rahaa valintansa mukaan, eivät yrityksen rahavarat ole yleensä sellaisenaan yrittäjän käytettävissä. Arvioitaessa osakkaan mahdollisuuksia saada tuloja yrityksestään, tulee aina huomioida ovatko tulot tai varat tosiasiallisesti yrittäjän omaan elatukseen käytettävissä. Yrityksestä saatavissa olevat tulot ja varat ovat asiakkaan käytettävissä esimerkiksi silloin, kun hän
 - on saanut tuloja yrityksestä käyttöönsä,
 - on käyttänyt yritystiliä omiin henkilökohtaisiin menoihinsa tai
 - itse tai yhdessä toimeentulotukiperheensä kanssa voisi päättää yrityksen varojen jakamisesta.

>ESIMERKKI: Martti omistaa 100 % yrityksensä osakkeista. Martti on nostanut palkkaa tammikuussa 1 500 euroa ja helmikuussa saman verran. Yrityksen tiliotteella on 15 000 euroa, josta voidaan esitettyjen selvitysten perusteella vähentää yritystoiminnan menoja 6 000 euroa. Yrityksellä voidaan katsoa olevan mahdollisuus maksaa palkkaa myös maaliskuussa, joten maaliskuulle voidaan huomioida tammi- ja helmikuun palkkaa vastaava määrä 1 500 euroa.

Jos yrityksen omistus on hajautunut ja asiasta saadun selvityksen perusteella voidaan arvioida, että osakeyhtiön olisi pitänyt pystyä juoksevien kulujen ja investointien jälkeen maksamaan osakkaille palkkaa, mutta palkkaa ei ole maksettu, pyydetään asiakkaalta kirjanpitäjän selvitys siitä, olisiko varoja voitu jakaa yrityksestä.
Osakeyhtiön osakkaalta voidaan pyytää esimerkiksi seuraavat selvitykset tulojen ja varojen selvittämiseksi:
 - TO4-lomake
 - yritystoiminnan esitäytetty veroilmoitus
 - yrittäjän ja yrityksen tiliotteet
 - kuukausikohtainen kirjanpito
 - tilinpäätös
 - yrityksen perustamissopimus ja osakasluettelo
 - yhtiökokouksen päätös varojen käytöstä
 - kassavirtalaskelma käteisvaroista tai muu selvitys käteisvarojen määrästä ja käytöstä
 - kirjanpitäjän selvitys yrityksestä saaduista tuloista edelliseltä kuukaudelta, esimerkiksi palkat, luontoisedut
 - kirjanpitäjän selvitys siitä, olisiko varoja voitu jakaa yrityksestä.

Jos yrityksellä ei ole kirjanpitäjää, pyydetään asiakkaan oma selvitys vastaavista tiedoista.
