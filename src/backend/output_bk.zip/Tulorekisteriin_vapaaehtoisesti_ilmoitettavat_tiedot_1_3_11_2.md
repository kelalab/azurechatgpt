#### 1.3.11.2 Tulorekisteriin vapaaehtoisesti ilmoitettavat tiedot
Osa tulorekisterin tiedoista on vapaaehtoisesti ilmoitettavia tietoja, joiden ilmoittaminen on maksajalle vapaaehtoista. Perustoimeentulotuen ratkaisemiseksi välttämättömät tiedot ovat pääosin pakollisia tietoja, jotka työnantajan tai etuuden maksajan on ilmoitettava tulorekisteriin.
