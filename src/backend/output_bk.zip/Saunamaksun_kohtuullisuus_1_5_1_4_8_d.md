###### 1.5.1.4.8.d Saunamaksun kohtuullisuus
Jos saunamaksu ylittää yli 10 euroa kuukaudessa, huomioidaan asiakkaan esittämästä menosta 10 euroa.
