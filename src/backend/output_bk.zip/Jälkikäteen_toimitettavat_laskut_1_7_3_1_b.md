##### 1.7.3.1.b Jälkikäteen toimitettavat laskut
Jälkikäteen toimitettaville perustoimeentulotuessa hyväksyttäville laskuille ei ole hakuaikaa. Lasku voidaan huomioida menona, jos asiakkaalle on tehty joko myöntävä tai hylkäävä laskelman sisältävä päätös sille kuukaudelle, jolla jälkikäteen toimitettu lasku on erääntynyt.
