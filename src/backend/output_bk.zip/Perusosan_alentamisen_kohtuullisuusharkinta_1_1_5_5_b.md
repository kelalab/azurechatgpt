##### 1.1.5.5.b Perusosan alentamisen kohtuullisuusharkinta 
Kohtuullisuusharkinnassa kiinnitetään huomiota erityisesti 
 - asiakkaan kykyyn huolehtia itsestään, 
 - voiko pidempiaikainen perusosan alentaminen johtaa asiakkaan osalta kohtuuttomaan tilanteeseen tai ihmisarvoisen edellyttämän turvan vaarantumiseen Yllä mainittu tilanne on kyseessä esimerkiksi silloin, kun terveyden tai elinkyvyn säilyttämisen kannalta välttämätön ravinto tai asuminen taikka itsenäinen selviytyminen vaarantuu.  
 - asiakkaan tarpeeseen ja mahdollisuuteen saada Kelan muita etuuksia ja palveluja kuten moniammatillinen palvelu ja toimeentulotukeen liittyvä henkilökohtainen keskustelu sekä kuntoutuspalvelut 
 - asiakkaan hyvinvointialueen järjestämien sosiaalipalvelujen ja hyvinvointialueelle tehtävien ilmoitusten tarpeeseen. 

Osana kohtuullisuusharkintaa voidaan tarvittaessa pyytää tai saada hyvinvointialueelta sosiaalihuollon lausunto . 
Pitkäaikaista, yli 6 kuukauden yhtämittaista, perusosan alentamista ei voida pitää kohtuullisena. 
