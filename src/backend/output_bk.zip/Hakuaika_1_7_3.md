### 1.7.3 Hakuaika
Perustoimeentulotukea myönnetään yleensä hakemuksen saapumiskuukauden tai sitä seuraavan kuukauden alusta lukien. Hakemuksen voidaan katsoa saapuneen ajoissa, jos se saapuu Kelaan viikon sisällä hakemiskuukauden päättymisestä.
Yli viikon myöhässä hakemiskuukauden päättymisestä saapuvaa hakemusta pidetään takautuvana hakemuksena . Toimeentulotukea voidaan myöntää takautuvasti vain poikkeustilanteessa ja erityisestä syystä. Asiakkaan ja perheen oikeus takautuvaan toimeentulotukeen on aina arvioitava yksilöllisesti.
