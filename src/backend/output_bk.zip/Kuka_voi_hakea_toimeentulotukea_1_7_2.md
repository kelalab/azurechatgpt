### 1.7.2 Kuka voi hakea toimeentulotukea
Toimeentulotuki on perhekohtainen etuus, jota voi hakea kuka tahansa perheen jäsenistä. Tässä luvussa kerrotaan, kuka voi hakea toimeentulotukea missäkin tilanteessa. Jos yhteistaloudessa asuvat hakijat eivät muodosta perhettä, he hakevat toimeentulotukea omilla hakemuksillaan. Lue lisää perhekäsitteestä .
