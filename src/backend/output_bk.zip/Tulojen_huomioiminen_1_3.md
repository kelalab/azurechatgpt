## 1.3 Tulojen huomioiminen
Toimeentulotuen laskelmalla huomioidaan hakijan ja hänen perheensä tulona kaikki etuusjakson aikana käytettävissä olevat tulot riippumatta siitä, onko tulo veronalaista vai verovapaata. Tulot huomioidaan laskelmalla nettomääräisenä. Myös kaikki ulkomailta saatavat tulot huomioidaan tuloina.
Tulo voi olla esimerkiksi
 - etuustuloa
 - ansiotuloa
 - pääomatuloa
 - myyntituloa
 - satunnaista avustusta

Kela saa Suomessa maksetuista ansiotuloista sekä laitosten maksamista etuus- ja muista tuloista tiedot tulorekisteristä. Tarvittaessa hakijaa pyydetään toimittamaan tarkempi selvitys tuloistaan Kelaan.
Yleensä tulo huomioidaan sen maksupäivän mukaiselle kuukaudelle tulona, jolloin sen voidaan katsoa olevan tosiasiallisesti käytettävissä hakijan ja tämän perheen elatukseen. Kuukauden viimeisenä pankkipäivänä maksettu tulo on seuraavan kuukauden käytettävissä olevaa tuloa.
