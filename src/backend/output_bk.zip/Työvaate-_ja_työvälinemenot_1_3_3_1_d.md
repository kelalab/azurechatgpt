##### 1.3.3.1.d Työvaate- ja työvälinemenot
Työssäkäynnistä aiheutuvat kohtuulliset työvaate- ja työvälinemenot voidaan vähentää huomioitavasta ansiotulosta. Kustannusten kohtuullisuutta arvioidaan suhteessa hakijan ansiotulon määrään.
>ESIMERKKI: Ollille on maksettu palkkaa 350 euroa ja työnantaja on vähentänyt siitä työvaatekustannuksia 25 euroa. Toimeentulotuen laskelmassa huomioidaan 375 euroa ansiotulona ja työvaatekustannus 25 euroa huomioidaan menona. Lisäksi ansiotulosta tehdään 150 euron ansiotulovähennys.

