#### 1.5.3.2 Vakuushakemuksen käsittely
Asiakas hakee sähkövakuutta toimittamalla sähköyhtiön vakuusvaatimuksen Kelaan.
Jos asiakkaalla on oikeus perustoimeentulotukeen sähkövakuuden erääntyessä, voi Kela myöntää hakijalle sähkövakuuden. Poikkeustilanteissa sähkövakuus voidaan myöntää harkinnalla myös silloin, kun hakijan laskelma on tuloylijäämäinen.
Sähkövakuus voidaan myöntää, vaikka asumismenot ylittäisivät kohtuullisen asumismenoille määritellyn tason. Sähkövakuuden myöntämisellä ei ole myöskään vaikutusta asumismenojen kohtuullisuusharkintaan.
Kun Kela on myöntänyt asiakkaalle sähkövakuuden, maksetaan asiakkaan toimittamat sähkölaskut jatkossa suoraan sähköyhtiölle.
Sähkövakuus toimitetaan asiakkaalle päätöksen liitteenä. Asiakkaan suostumuksella sähkövakuus voidaan myös toimittaa suoraan sähköyhtiölle.
