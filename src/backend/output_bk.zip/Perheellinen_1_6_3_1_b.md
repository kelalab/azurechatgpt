##### 1.6.3.1.b Perheellinen
Jos kuollut henkilö on perheellinen ja perheelle on myönnetty perustoimeentulotuki, tarkistetaan perheen päätös ja poistetaan kuolleen henkilön henkilökohtaiset menot (esimerkiksi terveydenhuoltomenot) kuolinkuukauden laskelmalta.
Kuolleen henkilön maksusitoumukset lakkautetaan kuoleman jälkeiseen päivään.
Lue lisää kuolleen henkilön hakemuksen käsittelystä .
