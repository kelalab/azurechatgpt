#### 1.7.4.1 Määräaika lisäselvityksille
Lisäselvityspyynnön yhteydessä asiakkaalle annetaan määräaika, johon mennessä pyydetyt lisäselvitykset tulee toimittaa. Määräajan tulee olla riittävä ottaen huomioon pyydettävien lisäselvitysten laatu. Määräaika on
 - yleensä kaksi viikkoa,
 - OmaKelan viestipalvelua käytettäessä yleensä yksi viikko
 - tai asiakkaan kanssa voidaan sopia myös lyhyemmästä tai pidemmästä määräajasta.

Jos asiakasta on pyydetty edellisessä päätöksestä toimittamaan liite/liitteitä, hakemusta ei ratkaista sen asian osalta ennen kuin kyseiset liitteet toimitettu.
 - Asiakasta pyydetään toimittamaan kyseiset liitteet lisäselvityksenä hakemusta käsiteltäessä ja annetaan normaali määräaika liitteiden toimittamiselle. Jos määräajassa ei toimiteta lisäselvityksiä tai esitetä hyväksyttävää syytä pyydettyjen selvitysten viivästymiselle, hakemus ratkaistaan käytettävissä olevien tietojen perusteella. Jos pyydettyjä lisäselvityksiä ei toimiteta, hakemus hylätään tältä osin. Lue lisää perustoimeentulotukihakemuksen hylkäämisestä .

 - Ratkaisu on tehtävä viimeistään 7 arkipäivän kuluessa siitä, kun asian ratkaisemiseksi tarvittavat tiedot on saatu tai määräaika selvitysten antamiselle on kulunut. Lue lisää käsittelyajasta .

Jos asiakas pyytää, päätös toimeentulotuesta voidaan tehdä käytettävissä olevien tietojen pohjalta myös ennen määräajan päättymistä. Lisäksi jos asiakas muutoin ilmaisee, että hän ei halua toimittaa muita selvityksiä, voidaan asiakkaaseen olla yhteydessä ja tiedustella haluaako hän, että päätös annetaan käytettävissä olevin tiedoin. Vaikka selvitys olisi saapunut määräajan kuluttua umpeen, se otetaan huomioon päätöksenteossa. Jos päätös on jo tehty, se voidaan tarvittaessa korjata tai tarkistaa.
