### 1.5.2 Muuttoon liittyvät menot
Perustoimeentulotuella voidaan kattaa välttämättömiä muuttoon liittyviä menoja, joita ovat asuinirtaimiston kuljetusmenot ja vuokravakuus sekä poikkeustilanteissa varastointipalvelut.
Muuttoa voidaan pääsääntöisesti tukea perustoimeentulotuella, jos
 - hakijalla on oikeus perustoimeentulotukeen vuokravakuuden erääntymiskuukaudelle,
 - muutto on perusteltu,
 - asunto on Kelan asumisnormin mukainen tai hakijalla on erityiset perusteet kohtuullista tasoa kalliimmalle asunnolle ja
 - asunto on asuinkäyttöön sopiva.

Muuttoon liittyvien menojen huomioimisessa on aina otettava huomioon asiakkaan yksilöllinen kokonaistilanne ja käytettävä tapauskohtaista harkintaa.
Muuttoa pidetään perusteltuna esimerkiksi seuraavissa tilanteissa:
 - avo- tai avioero
 - terveydelliset syyt, joista voidaan edellyttää lääkärinlausuntoa ja/tai sosiaalitoimen lausuntoa
 - perhekoon muutoksesta johtuva lisätilan tarve tapauskohtaisesti on harkittava, aiheuttaako lapsen syntymä heti lisätilan tarpeen

 - asunnottomuus
 - asunnottomuuden uhka
 - työpaikan saaminen toiselta paikkakunnalta huomioitava esimerkiksi työsuhteen kesto

 - tutkintoon johtavan opiskelupaikan saaminen toiselta paikkakunnalta
 - muutto toiselle paikkakunnalle perustellusta syystä esimerkiksi sosiaaliset perusteet kuten muuttaminen lähemmäksi tavattavaa omaa alaikäistä lasta tai omaishoitajaksi ryhtyminen muutto vastaanottokeskuksesta, kun asiakas on saanut ensimmäisen oleskeluluvan haettuaan kansainvälistä suojelua  tilapäistä suojelua saavan asiakkaan muutto vastaanottopalvelujen aikaisesta majoituksesta, kun asiakkaan oleskelu on katsottu perustoimeentulotuen näkökulmasta vakinaiseksi ja hänen vastaanottopalvelunsa ovat päättymässä asiakkaan saatua kotikunnan

 - asunnon vaihtaminen edullisempaan kohtuullisuusharkinnan vuoksi
 - asunnon vaihtaminen huomattavasti edullisempaan asuntoon, vaikka nykyinen asunto olisi Kelan asumisnormin mukainen huomioitava esimerkiksi kuukausittainen säästö, muutosta aiheutuvat kustannukset, vuokrasopimuksen pituus

 - jälkihuollossa olevan nuoren itsenäistyminen sijaishuollosta tai vanhempien kotoa

>ESIMERKKI: Sohvi asuu Helsingissä ja hänen vuokrasopimuksensa päättyy nykyisessä asunnossa 30.4. Sohvi on yrittänyt etsiä kohtuullista tasoa vastaavaa asuntoa Helsingistä, mutta ei ole yrityksistä huolimatta saanut asuntoa. Sohville tarjotaan kohtuullista tasoa vastaavaa asuntoa Vantaalta. Koska välimatkat pääkaupunkiseudulla ovat lyhyet ja asumisnormi on sama sekä Helsingissä että Vantaalla, voidaan Sohvin muuttoa Vantaalle tukea perustoimeentulotuella.

Muuttoa ei yleensä pidetä perusteltuna, kun muutto
 - johtuu mukavuussyistä esimerkiksi sauna, piha, kaupunginosan vaihto
 - johtuu paikkakunnan vaihdosta, joka ei perustu työ- tai opiskelupaikan saamiseen tai muuhun perusteltuun syyhyn
 - johtuu pois muutosta vanhempien luota ilman erityisiä perusteita huomioiden hakijan ikä ja elämäntilanne
 - ei ole perusteltu muunkaan edellä kerrotun syyn perusteella

>ESIMERKKI: Lukiossa opiskeleva 18-vuotias Linda hakee tukea vuokravakuuteen ja muuttokustannuksiin, koska hän on muuttamassa vanhempiensa luota omaan asuntoon viiden kilometrin päähän vanhemmistaan. Linda kertoo muuton syyksi itsenäistymisen. Itsenäistymistä ei voida yksinään pitää riittävänä perusteena muuton tukemiselle ottaen huomioon Lindan ikä ja elämäntilanne.

>ESIMERKKI: Sähköasentajaksi pian valmistuva 19-vuotias Jaakko hakee tukea muuttoon, koska hän on muuttamassa omilleen asumaan. Sosiaalityöntekijä on toimittanut Kelaan muuttoa puoltavan lausunnon, jossa kerrotaan Jaakon perhesuhteiden kotona olevan hyvin tulehtuneet, mikä on aiheuttanut Jaakolle vakavaa psyykkistä kuormittumista ja vaikeuttanut opintojen loppuun saattamista. Muuttoa voidaan pitää perusteltuna.

Jos muutolle katsotaan olevan hyväksyttävät perusteet ja uuden asunnon asumiskulut ovat kohtuulliset, voidaan asiakkaalle myöntää sekä vuokravakuus että muuttokustannukset, jos asiakas on hakenut molempia.
Jos muuttoa ei voida pitää perustoimeentulotuen näkökulmasta perusteltuna, vuokravakuutta ja muuttokustannuksia ei voida huomioida menona. Tällöin vuokra voidaan tarvittaessa kohtuullistaa heti, jos asiakas muuttaa asuntoon.
Jos muuttoa voidaan pitää perustoimeentulotuen näkökulmasta perusteltuna, mutta asiakas on muuttanut kohtuullista tasoa kalliimpaan asuntoon, vaikka paikkakunnalla olisi ollut tarjolla kohtuuhintaisia sopivia asuntoja, vuokra kohtuullistetaan heti eikä vuokravakuuteen myönnetä toimeentulotukea. Muuttokustannukset voivat kuitenkin tulla tarpeellisilta osin huomioitavaksi menona, jos ne ovat välttämättömiä asuntoon muuttoon liittyviä kuluja.
