### 1.9.2 Hyvinvointialueelle tai kuntaan tehtävät ilmoitukset
Kelalla on velvollisuus ohjata asiakasta sosiaalipalveluihin, ottaa asiakkaan suostumuksella yhteyttä sosiaalihuoltoon sekä tehdä ilmoitus salassapitosäännösten estämättä sosiaalihuoltoon tietyissä tilanteissa:
 - Sosiaalihuoltolakiin perustuva ilmoitus hyvinvointialueelle
 - Lastensuojelulakiin perustuva lastensuojeluilmoitus hyvinvointialueelle
 - Nuorisolakiin perustuva ilmoitus kuntaan
 - Vanhuspalvelulakiin perustuva ilmoitus hyvinvointialueelle

Kelalla on myös velvollisuus toimittaa tietoja kuntaan tai hyvinvointialueelle jäljempänä käsiteltävissä tilanteissa, vaikka asiakkaalla ei olisi sosiaalityön tarvetta:
 - Ilmoitukset muissa tilanteissa, joissa Kelan tulee toimittaa tietoja kuntaan tai hyvinvointialueelle 

