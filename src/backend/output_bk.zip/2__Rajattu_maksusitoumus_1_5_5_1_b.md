##### 1.5.5.1.b 2. Rajattu maksusitoumus
Jos asiakas tarvitsee valmistetta, joka ei kuulu Maksusitoumuksella lääkekustannuksiin katettaviin valmisteisiin, asiakkaan tulee esittää hakemuksensa liitteenä
 - lääkemääräys sekä
 - lääkärin, erikoislääkärin tai muun terveydenhuollon ammattihenkilön laatima lääketieteellinen selvitys (esimerkiksi hoitosuunnitelma, käyntimerkintä) lääkkeen tai valmisteen tarpeellisuudesta.

Selvitysten perusteella tehdään yksilöllinen arvio valmisteen tarpeellisuudesta asiakkaan sairauden hoidossa ja Rajatun maksusitoumuksen myöntämisestä.
Tällaisia valmisteita ovat esimerkiksi:
 - lääkemääräyksellä määrätyt haavanhoitotuotteet esimerkiksi leikkauksen jälkitilaan tai pitkäaikaiseen palovamman tai säärihaavan hoitoon
 - lääkemääräyksellä määrätyt kliiniset ravintovalmisteet, jos asiakkaalle ei ole myönnetty korvausoikeutta kliiniseen ravintovalmisteeseen tai kliininen ravintovalmiste on ei-korvattava.
 - rajoitetusti korvattavat lääkkeet tai reseptimerkinnälliset valmisteet, jos asiakkaalle ei ole myönnetty korvausoikeutta tai reseptissä ei ole tarvittavaa reseptimerkintää
 - potilaskohtaiset erityislupavalmisteet ja siihen liittyvä erityislupamaksu
 - ei-korvattava lääkevalmiste, joka maksaa yli 200 euroa
 - apuvälineet
 - rokotteet
 - nikotiinikorvaushoitovalmisteet
 - ravintolisät esimerkiksi maitohappobakteerit, D-vitamiinivalmisteet ja monivitamiinivalmisteet, joilla ei ole VNR-numeroa

Joissain tilanteissa Maksusitoumukselta lääkekustannuksiin voidaan rajata pois lääkkeitä tai lääkeaineryhmiä. Rajaus voi tulla kyseeseen esimerkiksi, jos lääkekustannuksia ei voida pitää asiakkaan sairauden hoidon kannalta tarpeellisina tai lääkekustannus on jo huomioitu perustoimeentulotuessa. Katso tarkemmin lääkeprosessista.
