#### 1.9.2.5 Ilmoitukset muissa tilanteissa, joissa Kelan tulee toimittaa tietoja kuntaan tai hyvinvointialueelle
Vaikka asiakkaalla ei olisi muilla perusteilla sosiaalityön tarvetta, Kelalla on velvollisuus ilmoittaa kuntaan tai hyvinvointialueelle seuraavissa tilanteissa:
 - Jos asiakkaan perusosaa on päätetty alentaa. Hyvinvointialueen on laadittava asiakkaalle suunnitelma itsenäisen suoriutumisen edistämiseksi. Ilmoitus lähtee ohjelmallisesti, kun asiakkaan perusosaa on alennettu.
 - Jos alle 25-vuotiaan asiakkaan pääasiallinen toimeentulo on viimeisen neljän kuukauden aikana ollut toimeentulotuki sekä 25 vuotta täyttäneiden asiakkaiden pääasiallinen toimeentulo on viimeisen 12 kuukauden aikana ollut toimeentulotuki. Hyvinvointialueen on laadittava asiakkaalle aktivointisuunnitelma. Ilmoitus lähtee ohjelmallisesti.
 - Jos maahanmuuttaja on saanut toimeentulotukea kaksi kuukautta tai pidempään ja, hän oleskelee maassa muuta kuin matkailua tai siihen verrattavaa lyhytaikaista oleskelua varten myönnetyllä oleskeluluvalla tai hänen oleskeluoikeutensa on rekisteröity tai hänelle on myönnetty oleskelukortti.

Ilmoitus tehdään henkilön kotikuntaan ja se lähtee ohjelmallisesti.
Ilmoitusta ei tehdä maahanmuuttajasta, joka on työmarkkinoiden käytettävissä tai muutoin TE-palvelujen piirissä.
