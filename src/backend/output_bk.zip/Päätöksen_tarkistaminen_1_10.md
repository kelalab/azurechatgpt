## 1.10 Päätöksen tarkistaminen
Toimeentulotuki tarkistetaan, jos hakijan tai perheen olosuhteissa tai tuen tarpeessa tapahtuu tai on tapahtunut muutoksia päätöksen antamisen jälkeen.
Yleisiä tarkistustilanteita toimeentulotuessa ovat esimerkiksi:
 - lapsen syntyminen perheeseen
 - yhteen ja erilleen muuttaminen
 - lapsen täysi-ikäistyminen
 - tulojen saaminen toimeentulotukipäätöksen antamisen jälkeen

Menettely tarkistustilanteessa eroaa riippuen siitä, johtuuko muutostarve
 - ansiotulosta , etuustulosta tai muusta tulosta vai
 - muusta olosuhdemuutoksesta .

