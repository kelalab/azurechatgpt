##### 1.7.16.1.a Miten tunnistan moniammatillisen palvelun tarpeessa olevan asiakkaan
Moniammatillisen palvelun tarpeessa olevilla asiakkailla on yleensä useita tai isoja ongelmia
 - terveydessä
 - elämänhallinnassa
 - toimeentulossa.

Asiakkaan kyky tai voimavarat oman tilanteensa selvittämiseen ja eteenpäin viemiseen ovat usein myös puutteelliset. Asiakkaalta voi puuttua läheisten tukiverkosto kokonaan tai sieltä ei löydy apua, osaamista tai voimavaroja hänen auttamiseksi.
Asiakkaiden tilanteet ovat erilaisia toisiinsa nähden, joten tarkkoja tunnusmerkkejä moniammatillisen palvelun tarpeen tunnistamiseksi on mahdotonta antaa. Esimerkiksi asunnon menettäminen voi tarkoittaa taustasta sekä kyvyistä ja voimavaroista riippuen yhdelle asiakkaalle katastrofia, kun taas toinen kokee sen ratkaistavissa olevaksi asiaksi.
Tilanteiden tunnistaminen onnistuu parhaiten toimimalla ratkaisutyön mallin mukaan, pysähtymällä tarvittaessa asiakkaan tilanteen äärelle, keskustelemalla hänen kanssaan ja luottamalla tilanteesta syntyvään intuitioon. Saat apua huolestuttavien merkkien tunnistamiseen huoliseulasta . Muista kuitenkin, että huoliseulaan on nostettu vain tyypillisimpiä esimerkkejä, muunlaisiakin huolenaiheita voi tulla vastaan.
Jos sinulle herää huoli asiakkaan tilanteesta
 - selvitä, onko asiasta tehtävä ilmoitus hyvinvointialueen sosiaalihuoltoon .
 - mieti, hoituuko asiakkaan asia peruspalvelussa vai onko asiakkaalla tarvetta moniammatilliselle palvelulle.

