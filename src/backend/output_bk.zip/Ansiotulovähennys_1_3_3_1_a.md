##### 1.3.3.1.a Ansiotulovähennys
Ansiotulosta vähennetään aina henkilökohtainen ansiotulovähennys, joka on enintään 150 euroa kuukaudessa ja vähennys tehdään kaikista asiakkaan etuusjaksolle saamista ansiotuloista yhteensä.
