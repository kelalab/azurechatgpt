#### 1.1.8.1 Valtion 100 % vastuu perustoimeentulotuen kustannuksista kotoutumisesta annetun lain mukaiselle asiakasryhmälle
Osa ulkomaalaisten asiakkaiden perustoimeentulotukimenoista katetaan 100 % valtionkorvauksin.
Hakemusta käsiteltäessä on selvitettävä, onko asiakas kotoutumislain tarkoittama henkilö ja onko asiakkaan kotoutumisaika alkamassa, kesken vai jo kulunut loppuun. Jos asiakas ei ole kotoutumislain tarkoittama henkilö tai hänen kotoutumisaikansa on umpeutunut, perustoimeentulotuen kustannukset kohdennetaan kuten kustannusten kohdistamisesta kuntaan kohdassa todettu.
