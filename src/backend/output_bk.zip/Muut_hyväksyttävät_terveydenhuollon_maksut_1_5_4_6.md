#### 1.5.4.6 Muut hyväksyttävät terveydenhuollon maksut
Perustoimeentulotuessa hyväksyttäviä muita kuin julkisten terveydenhuoltopalveluiden maksuja ovat:
 - Kelan lakisääteisenä kuntoutuksena korvaamien psykoterapioiden omavastuuosuudet ja kohtuulliset toimistomaksut sekä terapiapalautteiden tai loppulausuntojen lausuntopalkkioiden omavastuuosuudet. Ennen psykoterapian aloittamista koskevia tutustumiskäyntejä psykoterapeutille ei hyväksytä menona.

 - Kelan harkinnanvaraisena kuntoutuksena järjestämän neuropsykologisen kuntoutuksen omavastuuosuudet ja kohtuulliset toimistomaksut sekä neuropsykologisen kuntoutuksen kuntoutuspalautteen tai loppulausunnon lausuntopalkkioiden omavastuuosuudet.
 - Silmälääkärissä käynti, jos se on optikon lausunnon perusteella välttämätön silmälasien määräämiseksi.
 - Korkeakouluopiskelijoiden opiskelijaterveydenhuollon maksu ( OTH-maksu ) Ylioppilaiden terveydenhoitosäätiö (YTHS) tuottaa terveydenhuoltopalvelut sekä yliopisto- että ammattikorkeakouluissa opiskeleville. Korkeakouluopiskelija voi maksaa samalla kertaa kevät- ja syyslukukauden terveydenhoitomaksun tai yhden maksun/lukukausi. Maksu huomioidaan eräpäivän mukaiselle kuukaudelle menoksi. Poikkeuksena tilanne, jossa asiakas on maksanut koko vuoden opiskelijaterveydenhuollon maksun kerralla. Tällöin menona huomioidaan lukukausikohtainen maksu, ei koko vuoden maksua.

>ESIMERKKI: Asiakas on maksanut tammikuussa koko vuotta koskevan opiskelijaterveydenhuollon maksun. Tammikuun perustoimeentulotuen laskelmalla huomioidaan vain kevätlukukauden osuus maksusta. Jos asiakas hakee syksyllä perustoimeentulotukea, voidaan syyslukukautta koskeva osuus huomioida menona syyskuun laskelmalla, jos asiakas on ilmoittautunut läsnä olevaksi syyslukukaudelle.

