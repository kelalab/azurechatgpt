#### 1.6.7.5 Turvapaikanhakijat
Turvapaikanhakemisen tilanteita on erilaisia ja asiakas saattaa hakea perustoimeentulotukea missä tahansa prosessin vaiheessa. Lähtökohtana kaikissa tilanteissa on vastaanottopalvelujen ensisijaisuus, jos asiakkaalla on niihin oikeus.
