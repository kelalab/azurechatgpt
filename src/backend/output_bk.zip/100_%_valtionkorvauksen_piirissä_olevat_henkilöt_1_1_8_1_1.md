##### 1.1.8.1.1 100 % valtionkorvauksen piirissä olevat henkilöt
100 % valtionkorvauksen piirissä ei koskaan ole henkilö, jolla ei vielä ole oleskelulupaa. Esimerkiksi sellainen henkilö, jolla on ensimmäinen oleskelulupahakemus vireillä, ei ole vielä 100 % valtionkorvauksen piirissä. Jos tukioikeus syntyy, kustannukset kohdennetaan kuten kustannusten kohdistamisesta kuntaan kohdassa on todettu.
100% valtionkorvauksen piirissä ovat seuraavat ulkomaalaiset:
 - henkilö, joka saa ulkomaalaislaissa tarkoitettua kansainvälistä suojelua eli kiintiöpakolainen (pakolaisasema) henkilö, joka on saanut turvapaikan (pakolaisasema) henkilö, jonka oleskeluluvan perusteena on toissijainen suojelu  1.3.2023 jälkeen henkilö, joka saa tilapäistä suojelu ja jonka kotikunta on rekisteröity väestötietojärjestelmään

 - henkilö, joka on hakenut kansainvälistä suojelua ja hänelle on myönnetty oleskelulupa ulkomaalaislain 51, 52 tai 89 §:n perusteella 51 § = maasta poistumisen estyminen (tilapäinen oleskelulupa) 52 § = yksilöllinen inhimillinen syy (jatkuva oleskelulupa) 89 § = henkilölle ei myönnetä turvapaikkaa tai oleskelulupaa, koska hän on tehnyt tai on syytä epäillä hänen tehneet muun muassa rikoksen rauhaa vastaan, sotarikoksen, törkeän muun kuin poliittisen rikoksen, YK:n periaatteiden vastaisen teon, mutta henkilöä ei voida palauttaa kotimaahan, koska häntä uhkaa vaino, kidutus, kuolemanrangaistus tms. (tilapäinen oleskelulupa)
 - henkilö, joka on otettu Suomeen erityisellä humanitaarisella syyllä tai kv-velvoitteiden täyttämiseksi ulkomaalaislain 93 §:n perusteella
 - henkilö, jolle on myönnetty jatkuva (A) oleskelulupa ulkomaalaislain 52 a §:n 2 momentin perusteella erityisen haavoittuvassa asemassa olevana ihmiskaupan uhrina.
 - henkilö, jolle on myönnetty jatkuva (A) oleskelulupa ulkomaalaislain 54 §:n 5 momentin mukaisilla seuraavilla perusteilla henkilöllä on aikaisempi tilapäinen oleskelulupa maasta poistamisen estymisen vuoksi (51 §)  henkilö on ihmiskaupan uhri, jolle on myönnetty tilapäinen oleskelulupa  henkilö on Suomessa laittomasti oleskellut ja työskennellyt kolmannen maan kansalainen, jolla on aikaisemmin myönnetty tilapäinen oleskelulupa (52 d §) 

Edellä mainituissa tilanteissa 100 % valtionkorvausten piiriin kuuluvat sekä yllä nimetyin perustein oleskeluluvan saaneet mutta myös heidän perheenjäsenensä tai muut omaisensa, joihin heillä on ollut perheside jo ennen Suomeen tuloa.
100 % valtionkorvauksen piirissä ovat myös alla tarkemmin eritellyt henkilöt, jotka ovat peräisin entisen Neuvostoliiton alueelta ja saaneet oleskeluluvan ulkomaalaislain 48 §:n tai 49 §:n 1 momentin 1 kohdan perusteella. Edellä mainituilla perusteilla oleskeluluvan saaneiden perheenjäsenet eivät kuitenkaan kuulu erityisen valtionkorvauksen piiriin.
 - Ulkomaalaislain 48 §, kuulunut Inkerin siirtoväkeen tai palvellut Suomen armeijassa 1939-1945.
 - Ulkomaalaislain 49 § 1 momentin 1 kohta, henkilö on ollut Suomen kansalainen tai ainakin toinen hänen vanhemmistaan tai yksi isovanhemmista on tai on ollut syntyperäinen Suomen kansalainen
 - Lue lisää korvausperusteen selvittämisestä. 

