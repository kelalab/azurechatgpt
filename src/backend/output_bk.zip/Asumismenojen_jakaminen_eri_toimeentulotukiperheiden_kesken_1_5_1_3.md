#### 1.5.1.3 Asumismenojen jakaminen eri toimeentulotukiperheiden kesken
Samassa asunnossa voi asua henkilöitä, jotka kuuluvat toimeentulotuen näkökulmasta eri perheisiin esimerkiksi isovanhempi ja hänen lapsensa perheineen tai kimppakämpässä asuvat kaverukset. Tällöin toimeentulotuesta tehdään jokaiselle toimeentulotukiperheelle oma päätös.
Jos jokaisella vuokralaisella on oma vuokrasopimus (esimerkiksi kaverukset ovat vuokranneet asunnosta huoneen jokainen omalla vuokrasopimuksellaan tai alivuokralainen on vuokrannut osan asunnosta), huomioidaan hakijan
 - menona vuokrasopimuksessa sovittu vuokran määrä, jos kustannukset ovat kohtuulliset,
 - tulona hakijalle myönnetty asumistuki ja
 - yhteisestä sähkölaskusta, kotivakuutuslaskusta, vesilaskusta ja muista vastaavista laskuista jokaiselle vuokralaiselle osuus pääluvun mukaan.

Jos eri toimeentulotukiperheisiin kuuluvilla henkilöillä on yhteinen vuokrasopimus, asumismenot ja yleinen asumistuki huomioidaan pääluvun mukaan.
>ESIMERKKI: Martta asuu tyttärensä Saimin ja tämän pojan Valtterin (8v.) kanssa yhteisessä vuokra-asunnossa, jonka vuokra on 600 euroa. Martta muodostaa toimeentulotuen näkökulmasta oman perheen ja Saimi ja Valtteri muodostavat talouden toisen toimeentulotukiperheen. Heillä on yhteinen vuokrasopimus ja he muodostavat yhdessä yleisen asumistuen ruokakunnan eli yleinen asumistuki on yhteinen. Martta hakee toimeentulotukea. Hänelle huomioidaan vuokrasta 1/3 eli 200 euroa. Hänen tulonaan otetaan huomioon 1/3 ruokakunnan yhteisestä yleisestä asumistuesta.

Jos hakija esittää, että asumismenot jakaantuvat muutoin kuin pääluvun mukaan, tulee asiasta esittää luotettava selvitys. Selvityksen perusteella asumismenot voidaan poikkeuksellisesti harkinnalla huomioida todellisten kustannusten mukaisesti. Asumiskustannuksia ei voi kuitenkaan huomioida yksin toimeentulotuen hakijan menoksi, jos asunnossa asuu muita henkilöitä, jotka eivät ole toimeentulotuen saajia.

