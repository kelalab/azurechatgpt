##### 1.1.8.1.2 100 % valtionkorvauksen korvausajan laskenta
100 % valtionkorvausta maksetaan siitä alkaen,
 - kun henkilölle, jonka kunnassa asumisen tai hyvinvointialueelta palvelujen saamisen perusteella korvaus maksetaan, perusteella korvaus maksetaan, on rekisteröity ensimmäisen kerran kotikunta väestötietojärjestelmään (yleensä A-lupa) tai
 - kun henkilölle on myönnetty oleskelulupa, jos hän ei voi saada kotikuntaa. Yleensä on myönnetty esimerkiksi B-lupa maasta poistumisen estymisen vuoksi tai muu vastaava tilanne. Tilapäistä suojelua saavasta (B-lupa) korvausta maksetaan kuitenkin 1.3.2023 jälkeen vasta siitä alkaen, kun hänelle on rekisteröity ensimmäisen kerran kotikunta.

100 % valtionkorvausta maksetaan enintään 3 vuotta korvausoikeuden syntymisestä lukien. Entisen Neuvostoliiton alueelta muuttaneilla 100 % valtionkorvausta maksetaan kuitenkin enintään 6 kuukautta.