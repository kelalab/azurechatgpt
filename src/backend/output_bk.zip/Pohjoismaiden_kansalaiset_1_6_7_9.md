#### 1.6.7.9 Pohjoismaiden kansalaiset
Pohjoismaiden kansalaisten toimeentulotukioikeuden osalta on otettava huomioon EU-oikeuden sääntelyn ohella pohjoismainen sosiaalipalvelusopimus.
Pohjoismaan kansalaiset rinnastetaan yleensä Suomessa vakinaisesti oleskeleviin. Näin ollen Pohjoismaan kansalaisilla on oikeus toimeentulotukilain edellytysten mukaisesti perustoimeentulotukeen kuten muilla Suomessa vakinaisesti oleskelevilla jo heti maahan saavuttaessa. Lähtömaasta mahdollisesti saatava sosiaaliturva on selvitettävä.
Sopimus myös takaa Pohjoismaan kansalaiselle oikeuden käyttää suomen ja ruotsin kielen ohella joko tanskaa, islantia tai norjaa asioidessaan. Kelan tulee tällöin huolehtia tarvittaessa asioinnista näillä kielillä.
