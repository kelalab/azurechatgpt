### 1.3.4 Muut tulot
Muut tulot otetaan tulona huomioon. Niiden määrät selviävät yleensä hakemuksesta, verotustiedoista tai tiliotteilta. Tuloina huomioidaan esimerkiksi
 - yksityishenkilön avustukset, tilillepanot ja lainat 
 - veronpalautukset 
 - pelivoitot
 - elatusapu 
 - pääomatulot 
 - vakuutuskorvaukset, vahingonkorvaukset ja rikosperusteiset korvaukset  
 - perinnöt
 - myyntitulot (esimerkiksi kirpputorimyynti) Tulot huomioidaan siltä osin kuin ne ovat myynnistä aiheutuneiden kulujen jälkeen hakijan omaan elatukseen käytettävissä.

 - apuraha tai stipendi Jos apuraha ja stipendi on kohdennettu esimerkiksi opintojen suorittamisen kannalta tarpeelliseen hankintaan, sitä ei huomioida siltä osin tulona.

 - käänteinen asuntolaina Huomioidaan tulona sen mukaisena, minkä asiakas saa lainaerästä käyttöönsä korkojen ja kulujen jälkeen.  Asiakasta ei voida edellyttää nostamaan käänteistä asuntolainaa, vaikka sellainen olisi myönnettykin, koska oman asunnon realisointia ei edellytetä.  

Jos edellä mainitut muut tulot eivät ole olleet tiedossa toimeentulotuesta päätettäessä, katso tulon jälkikäteinen huomioiminen .
