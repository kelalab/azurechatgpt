###### 1.5.1.4.6.d Vankilassaolo
Lisätietoa vankien tai vankien puolisoiden asumismenojen huomioimisesta.
