#### 1.3.3.1 Ansiotuloista tehtävät vähennykset
Ansiotulosta tehtäviä vähennyksiä ovat
 - ansiotulovähennys
 - työmatkakustannukset
 - ammattiyhdistyksen ja työttömyyskassan jäsenmaksut
 - kohtuulliset työvaate- ja työvälinemenot.

Perustoimeentulotuessa hyväksyttävät vähennykset eivät voi olla määrältään suurempia kuin samasta työstä huomioitavat ansiotulot.
