#### 1.5.2.1 Vuokravakuus
Kela voi myöntää vuokravakuuden osana myönnettyä perustoimeentulotukea.
Vuokravakuus annetaan pääsääntöisesti kirjallisena maksusitoumuksena. Ainoastaan erityisen painavista syistä vakuus voidaan myöntää poikkeuksellisesti rahana vuokranantajalle. Erityisen painavana syynä voidaan pitää esimerkiksi sitä, että asiakas on muuttamassa tuettuun asumiseen tai asiakas on ollut pitkään asunnoton eikä hän muutoin saa asuntoa. Maksusitoumuksella Kela sitoutuu mainituin ehdoin korvaamaan vahingon vuokranantajalle, jos vuokralainen ei hoida vuokrasopimuksen mukaisia velvollisuuksiaan ja aiheuttaa sillä vuokranantajalle vahinkoa. Samat maksusitoumuksen ehdot koskevat myös rahana maksettua vakuutta.
Asiakkaan itsensä maksamaa vuokravakuutta ei yleensä huomioida menona, sillä se on jo katettu toimeentulotukeen nähden ensisijaisella tavalla. Myöskään pankkilainalla tai siihen rinnastettavalla tavalla jo suoritettua vuokravakuutta ei huomioida menona. Vuokravakuutta varten nostetun lainan lyhennyksiä ei huomioida menona.
Asumisoikeusasunnossa perittävää vastikevakuutta ei huomioida menona. 
Lue lisää vuokravakuuden myöntämisestä .
