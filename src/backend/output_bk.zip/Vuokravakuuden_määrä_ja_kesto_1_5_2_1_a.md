##### 1.5.2.1.a Vuokravakuuden määrä ja kesto
Vuokravakuus vastaa yleensä 2 kuukauden vuokraa. Perustellusta syystä vakuus voidaan antaa 3 kuukaudeksi. Perusteltu syy voi olla esimerkiksi asunnottomuus tai asunnottomuuden uhka. Vuokravakuus saa olla enintään 3 kuukauden vuokraa vastaava määrä.
Vuokravakuus on asuntokohtainen ja se on voimassa vuokrasopimuksen voimassaoloajan mukaisesti.
Vuokrasuhde voi jatkua, vaikka asiakas esimerkiksi asuisi väliaikaisesti toisessa asunnossa.
>ESIMERKKI: Jaana ja Esko ovat pariskunta ja hakevat vuokravakuutta yhteiseen vuokra-asuntoon. Sittemmin Esko muuttaa pois asunnosta. Vuokrasopimus ei kuitenkaan lakkaa olemasta voimassa, vaan Jaana ja Esko vastaavat edelleen yhdessä vuokrasuhteeseen perustuvista velvoitteistaan niin kauan kuin vuokrasopimus pysyy voimassa. Vuokravakuuden voimassaolo lakkaa vasta, kun vuokrasopimuksen tilalle tehdään uusi vuokrasopimus tai vuokrasopimus irtisanotaan.

