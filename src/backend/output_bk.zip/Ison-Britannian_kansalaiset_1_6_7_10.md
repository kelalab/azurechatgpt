#### 1.6.7.10 Ison-Britannian kansalaiset

Muiden kuin taloudellisesti aktiivisten Ison-Britannian kansalaisten oikeutta toimeentulotukeen arvioidaan samoin kuin kolmannen maan kansalaisilla.
Ennen 1.1.2021 Suomeen muuttaneilla taloudellisesti aktiivisilla Ison-Britannian kansalaisilla ja heidän perheenjäsenillään ei tarvitse arvioida oleskelun luonnetta. Jos työntekijän tulot eivät riitä elatukseen, hänellä ja hänen perheellään on oikeus perustoimeentulotukeen samoilla edellytyksillä kuin Suomessa vakinaisesti oleskelevalla työntekijällä. Taloudellista aktiivisuutta arvioidaan samoilla perusteilla kuin EU-maan kansalaisilla. Sen sijaan taloudellisesti aktiivisten Ison-Britannian kansalaisten, jotka ovat muuttaneet Suomeen 1.1.2021 jälkeen, oikeutta toimeentulotukeen arvioidaan samoin kuin kolmannen maan kansalaisilla.
Koska Iso-Britannia ei ole enää EU-maa, Ison-Britannian kansalainen tarvitsee Suomessa oleskeluluvan pidempiaikaiseen oleskeluun ja asumiseen.
