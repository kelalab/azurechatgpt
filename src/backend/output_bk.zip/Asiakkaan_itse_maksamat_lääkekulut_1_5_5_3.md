#### 1.5.5.3 Asiakkaan itse maksamat lääkekulut
Asiakas voi hakea toimeentulotukea itse maksamiinsa lääkekuluihin. Lääkemenojen huomioimisesta koskevat tällöin samat periaatteet kuin myönnettäessä lääkemaksusitoumusta.
Hakemuksen liitteeksi tarvitaan selvitys lääkekustannuksista, apteekin kuitti tai lasku.
 - Jos asiakas ei ole saanut kustannuksista sairausvakuutuslain mukaista korvausta apteekissa ja kyseessä on sairausvakuutuslain mukaan korvattava lääke, liitteeksi tarvitaan lisäksi apteekin antama laskelma.

Jos kyseessä on lääke, joka ei ole sairausvakuutuslain mukaan korvattava, liitteeksi riittää kuitin tai laskun lisäksi kopio potilasohjeesta tai Omakannasta saatava kopio sähköisestä reseptistä. Lue lisää lääkeprosessista .
