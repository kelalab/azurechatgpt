###### 1.5.1.4.8.a Vesimaksujen kohtuullisuus
Kohtuullisen vesimaksun määrä on 24,00 euroa / henkilö.
Jos vesimaksu
 - ylittää vähäisesti Kelan vesinormin, hyväksytään maksu kokonaisuudessaan.
 - ylittää huomattavasti vesinormin, soitetaan asiakkaalta ja kysytään asiakkaan selvitystä normaalia suuremmasta vesimaksusta tai veden kulutuksesta ennen hakemuksen tai laskun käsittelyä.

Jos hakijalla on perusteltu syy suuremmalle vesimaksulle, voidaan vesimaksu huomioida kokonaan. Perusteltu syy voi olla esimerkiksi
 - sairaus
 - se, että hakija ei voi vaikuttaa vesimaksun suuruuteen (kunnassa yleisesti kalliit vesimaksut)

Jos hakijalla ei ole perusteltua syytä kohtuullista tasoa suuremmalle vesimaksulle, kohtuullistetaan vesimaksu. Kun kuukausittain saman suuruisen vesimaksun kohtuullisuus on kerran selvitetty, ei vesimaksun kohtuullisuutta tarvitse arvioida uudelleen, jollei sen määrä muutu.
Jos hakijan vesimaksu perustuu ennakkolaskuun, voi hänelle veden kulutuksen mukaan syntyä lisälaskua. Veden tasauslasku voidaan huomioida menona, jos veden kuukausittaiset yhteiskustannukset eivät ylitä Kelan vesinormia tai kohtuullista tasoa suuremmille vesimaksuille esitetään perusteltu syy. Jos hakija saa vesiennakosta palautusta, huomioidaan se tulona.
>ESIMERKKI: Taina toimittaa veden tasauslaskun 300,20 euroa. Tainalle on vuoden aikana korvattu vesimaksua 15 euroa/kk eli yhteensä 180 euroa. Kun lasketaan yhteen Tainalle jo korvattu vesi ja tasauslasku, Tainan vedestä aiheutuneet kustannukset ovat olleet noin 40 euroa kuukaudessa. Jos Taina ei kuulemisen yhteydessä ole esittänyt hyväksyttävää syytä kohtuullisen määrän ylittäville vesimaksuille, huomioidaan tasauslaskusta 108,00 euroa (24,00 euroa/kk x 12 – 180 euroa).

