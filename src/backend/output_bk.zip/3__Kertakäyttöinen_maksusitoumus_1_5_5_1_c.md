##### 1.5.5.1.c 3. Kertakäyttöinen maksusitoumus
Kertakäyttöinen maksusitoumus myönnetään asiakkaalle esimerkiksi seuraavissa tilanteissa:
 - kiire-tilanteessa. Lue lisää kiireprosessista.
 - toimeentulotukihakemusta ei ehditä ratkaista hakukuukauden aikana, vaan myönteinen päätös tehdään seuraavan kuukauden puolella ja asiakkaalla ei ole myönteistä toimeentulotuen päätöstä kyseessä olevalle kuukaudelle tai asiakas ei ole hakenut toimeentulotukea kyseessä olevalle kuukaudelle. maksusitoumus voi olla voimassa enintään kuluvan kuukauden 14. päivään saakka

Kertakäyttöisellä maksusitoumuksella asiakkaan tulee ostaa lääkkeet apteekista samalla kertaa.
