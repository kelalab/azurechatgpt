## 1.8 Maksaminen
Perustoimeentulotuen säännöllinen maksupäivä on kuukauden ensimmäinen pankkipäivä. Myös vuokranantajille tuet maksetaan tämän mukaisesti.
Jos asiakkaalle syntyy oikeus toimeentulotukeen, joka ei ehdi maksuun säännöllisenä maksupäivänä, maksu näkyy asiakkaan tilillä kahden pankkipäivän kuluessa päätöksen antamisesta.
Lisätietoa toimeentulotuen maksamisesta, etuuspalautuksista, väärän henkilön tilille maksetun etuuden palauttamisesta ym .
