#### 1.7.6.b Esimerkkejä tilanteista, joissa Kela ei siirrä hakemusta hyvinvointialueelle
 - ravintomenot esimerkiksi erityisruokavaliosta aiheutuvat ylimääräisen menot
 - asumismenot (sisältää myös vuokravakuudet ja kohtuullisen määrän ylittävät asumismenot)
 - vaatemenot riippumatta siitä kuuluvatko ne perusosalla katettaviin menoihin vai eivät
 - vähäiset terveydenhuoltomenot
 - henkilökohtaisesta ja kodin puhtaudesta aiheutuvat menot
 - paikallisliikenteen käytöstä aiheutuvat menot
 - sanomalehden tilauksesta aiheutuvat menot
 - puhelimen ja tietoliikenteen käytöstä aiheutuvat menot
 - harrastus- ja virkistystoiminnasta aiheutuvat menot (poislukien lapsen harrastemenot)
 - vastaavat muut henkilön ja perheen jokapäiväiseen toimeentuloon kuuluvat menot
 - viivästys-, muistutus- tai perimiskulut
 - lainan ja luottojen lyhennykset
 - perustoimeentulotukipäätös kattaa tietyn yksilöidyn menoerän, esimerkiksi laskun vain osittain tai kohtuullisen määrän ylittävät asumismenot
 - asiakas hakee rahaa, eikä lisäselvitys tuo selvyyttä siihen, mihin menoihin rahaa tarvitaan (esimerkiksi vain viittaus henkilön olosuhteisiin ja erityisiin perusteisiin).

Jos asiakkaalla on esimerkiksi vuokrarästejä, ollaan yhteydessä asiakkaan tilanteesta hyvinvointialueelle hänen suostumuksellaan, vaikka hakemuksen siirtoa hyvinvointialueelle ei tehtäisi. Lapsiperheiden osalta tulee harkita, täyttyvätkö edellytykset olla yhteydessä hyvinvointialueelle ilman asiakkaan suostumusta. Katso tarkemmin lastensuojeluilmoitus .
Kela voi asiakkaan pyynnöstä siirtää hakemuksen hyvinvointialueelle, jos jää tulkinnanvaraiseksi, onko menoerä perusosaan kuuluva tai muuna perusmenona huomioitava vai ei.
Jos Kela ei siirrä hakemusta hyvinvointialueelle, asiakkaalla on aina mahdollisuus hakea täydentävää ja ehkäisevää toimeentulotukea hyvinvointialueelta. Asiakkaalle kerrotaan päätöksellä mahdollisuudesta hakea täydentävää ja ehkäisevää toimeentulotukea.
