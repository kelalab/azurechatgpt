#### 1.3.5.c Muut tulot
Tuloina jätetään huomioimatta myös
 - vähäiseksi katsottava määrä, yksin asuvalta 50 euroa ja perheeltä 100 euroa, seuraavista tuloista avustukset veronpalautukset vahingonkorvaukset vakuutuskorvaus rikosperusteiset korvaukset
 - eri yleishyödyllisistä säätiöistä myönnettävät avustukset, jotka on myönnetty hakijan vaikean taloudellisen tilanteen perusteella. Avustukset voidaan myöntää rahana tai lahjakortteina. Arviossa hyödynnetään Kelaan toimitettua sosiaalitoimen selvitystä.

 - alle 200 euron stipendit alle 30-vuotiaille nuorille, jotka on tarkoitettu kannustimena aktivoimaan nuoria osallistumaan esimerkiksi kesätyötoimintaan. Toiminta voi olla järjestetty esimerkiksi lastensuojelun, etsivän nuorisotyön tai sosiaalitoimen kautta
 - diakoniatyön kautta saatu tulo, joka on myönnetty saajan vaikean taloudellisen tilanteen perusteella
 - alle 18-vuotiaan muut kuin vähäiset tulot, jotka ylittävät hänen perusosansa ja toimeentulotuessa huomioon otettavat menot
 - alle 18-vuotiaan kesätöistä tai muista alle 3 kk kestävistä töistä saadut ansiotulot
 - sijoitetun lapsen vanhemmalle maksettava ruokaraha kun lapsi on sijoitettu kodin ulkopuolelle ja lapsi tulee lomilla oman vanhemman luo, vanhemmalle maksetaan loma-ajalta ruokarahaa

 - vaaliavustus siltä osin kuin hakija käyttää avustuksen vaalityöstä aiheutuneisiin menoihin
 - perhehoitajien kustannusten korvaukset
 - perhepäivähoitajien saamat kustannusten korvaukset
 - äidinmaidon luovutuksesta saatava tulo
 - ateriakorvaus tai -tuki, joka maksetaan opiskelijalle työssäoppimisen tai työharjoittelun aikana
 - sellaista tuloa, joka saadaan korvauksena tai tulona toimeentulotuessa huomioitavien menojen kattamiseen
 - kehitysvammaisen työosuusrahaa, joka maksetaan erityishuollosta annetun lain mukaisesti osana erityishuoltoa järjestettävää työtoimintaa
 - lastensuojelulain 35 § ja 76 a §:n nojalla hyvinvointialueen myöntämää asumiseen ja toimeentuloon liittyvää taloudellista tukea
 - lastensuojelulain 36 § nojalla hyvinvointialueen myöntämää taloudellista tukea koulunkäyntiin, ammatin ja asunnon hankintaan, työhön sijoittumiseen, harrastuksiin, läheisten ihmissuhteiden ylläpitoon sekä muihin henkilökohtaisiin tarpeisiin liittyen
 - lastensuojelun keräämiä itsenäistymisvaroja, kunnes jälkihuolto päättyy

