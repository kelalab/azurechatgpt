#### 1.3.8.b Pelivoittojen arvioiminen
Yleensä pelivoittoja ei arvioida tulevalle ajalle. Laskelmalla huomioitavan pelivoiton määrä voidaan arvioida, jos
 - asiakkaalla on kuukausittain säännöllisesti ammattimaisesti pelaamalla hankittuja pelivoittoja
 - pelivoittojen määrä vaihtelee kuukausittain vähäistä enemmän
 - eikä riittävää selvitystä etuusjakson aikana tosiasiallisesti maksettavista pelivoitoista vielä päätöstä tehtäessä ole käytettävissä.

Ammattimaisesti pelaamalla hankittujen pelivoittojen arvioimisessa tulee käyttää tapauskohtaista harkintaa.
Asiakkaan kanssa keskustellaan tarvittaessa pelaamiseen liittyvistä ongelmista sekä sosiaalihuollon tarpeen ilmoituksesta .
 
Jos asiakkaalla on satunnaisia tai määrältään vähäisiä pelivoittoja, ne huomioidaan niiden maksukuukaudelle tuloksi. Jos Kela ei ole tiennyt pelivoitoista päätöstä tehtäessä, pelivoitot voidaan huomioida jälkikäteen kahden seuraavan kuukauden laskelmalla. Lue lisää tulo ei ole ollut tiedossa toimeentulotuesta päätettäessä .
