###### 1.5.1.1.6.d Saunamaksu
Saunamaksu voidaan huomioida laskelmalla.
Lue lisää saunamaksun kohtuullisuuden arvioimisesta .
