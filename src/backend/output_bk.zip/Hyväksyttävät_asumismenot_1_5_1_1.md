#### 1.5.1.1 Hyväksyttävät asumismenot
Asumismenoina voidaan huomioida kohtuullisilta osin:
 - vuokra-asunnossa: vuokra

 - omistusasunnossa: hoitovastike, ylimääräinen vastike ja tontin vuokravastike pääoma- tai rahoitusvastikkeen se osuus, jolla katetaan yhtiölainaosuuden korkomenoja

 - omakotitalon välttämättömät hoitomenot esimerkiksi jätemaksu ja kiinteistövero

Lisäksi kaikissa asumismuodoissa voidaan huomioida erikseen maksettavat kohtuulliset:
 - vesimaksut
 - lämmityskulut
 - taloussähkömenot
 - kotivakuutusmaksut
 - saunamaksut
 - välttämättömät asuntoon muuttoon liittyvät menot: vuokravakuus muuttokustannukset.

Hyväksyttävistä asumismenoista on esitettävä luotettava selvitys.
