### 1.13.5 Oikaisuvaatimuksen ja valituksen peruminen
Oikaisuvaatimuksen tai valituksen peruminen tehdään kirjallisesti.
