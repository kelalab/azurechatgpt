#### 1.12.2.4 Elatusvelvollisuuden laiminlyönti
Kela voi toimeentulotukea myönnettäessä määrätä, että perustoimeentulotuki tai osa siitä peritään takaisin tuensaajan elatusvelvolliselta, jos hän on tahallaan laiminlyönyt elatusvelvollisuutensa. Takaisinperintä voi kohdistua ainoastaan sellaiseen henkilöön, jolla on lakiin perustuva elatusvelvollisuus tuensaajaa kohtaan. Vanhemmat ovat elatusvelvollisia alle 18-vuotiaista lapsistaan ja aviopuolisoilla on elatusvelvollisuus toisiinsa nähden avioeron tuomitsemispäivään asti. Myös rekisteröidyn parisuhteen osapuolilla on elatusvelvollisuus toisiinsa nähden rekisteröidyn parisuhteen purkamiseen asti.
Takaisinperintä edellyttää, että elatusvelvollisuuden laiminlyönti on ollut tahallista. Tahallisuutta arvioitaessa tulee kiinnittää huomiota elatusvelvollisen tosiasialliseen kykyyn suoriutua elatusvelvollisuudestaan, eli on selvitettävä, onko hänellä riittävä elatuskyky. Jos elatusvelvollinen on itse esimerkiksi tuloton tai hänellä on hyvin pienet tulot eikä hänellä ole varallisuutta, ei tahallisuuden tunnusmerkistö yleensä täyty. Riittävää elatuskykyä ei yleensä ole henkilöllä, joka saa esimerkiksi perustoimeentulotukea. Kysymys on aina tapauskohtaisesta kokonaisharkinnasta, jossa otetaan huomioon esimerkiksi elatusvelvollisen
 - tulot ja varat,
 - kiinteät menot, kuten asumiskulut sekä
 - elatusvelvollisuus muihin henkilöihin.

Vaikka vanhemmat vastaavat tietyissä tilanteissa täysi-ikäisen opiskelevan lapsensa koulutuksesta aiheutuvista kustannuksista, ei täysi-ikäiselle myönnettyä toimeentulotukea voida periä takaisin hänen vanhemmiltaan. Tosiasiallisesti saatu vähäistä suurempi avustus voidaan kuitenkin huomioida tulona.
Lue lisää takaisinperinnän edellytyksistä kohdasta Elatusvelvollisuus .
