#### 1.3.7.1 Vyöryttäminen
Tulo voidaan jakaa huomioon otettavaksi seuraaville kuukausille vyöryttämällä laskelmalle muodostunutta tuloylijäämää. Ylijäämä syntyy, kun perustoimeentulotuessa huomioitavat tulot tai käytettävissä oleva varallisuus ylittävät perustoimeentulotuessa huomioitavien menojen määrän. Jos asiakkaalla on huomattava tuloylijäämä, hakijan tulee varautua tuleviin menoihinsa siten, ettei toimeentulotuen tarvetta lähikuukausina synny, jos taloudellisessa tilanteessa ei tapahdu muita muutoksia.
Tuloylijäämää ei vyörytetä seuraaville kuukausille, jos ylijäämä muodostuu säännöllisestä kuukausittaisesta tulosta. Säännöllinen tulo on kuukausittain maksussa oleva tulo, kuten työttömyysetuus tai ansiotulo. Sen sijaan takautuvalta ajalta maksetusta etuustulosta muodostunutta ylijäämää voidaan vyöryttää seuraaville kuukausille, jos se ei muodosta kohtuutonta tilannetta.
Edelliseltä kuukaudelta syntynyt tuloylijäämä voidaan huomioida kokonaan tai osittain seuraavina kuukausina käytettävissä olevana tulona, ellei se ole kohtuutonta. Ylijäämä huomioidaan vähäisen määrän, yksin asuvalta 50 euroa ja perheeltä 100 euroa, ylittäviltä osin.
Kohtuullisuutta arvioidaan aina tapauskohtaisesti. Vyöryttämisen harkinnassa on otettava huomioon seuraavia asioita:
 - hakijan ja perheen kuukausittaisten menojen määrä
 - muut käytettävissä olevat tulot ja varat
 - milloin tulo on tosiasiallisesti hakijalle maksettu sekä
 - miten pitkälle ajalle tulo riittäisi kattamaan hakijan menoja.

>ESIMERKKI: Ilkka hakee elokuussa toimeentulotuen jatkoa elo- ja syyskuulle. Ilkan ansiotulot ovat säännölliset ja hänelle maksetaan kuukausittain 1 080 euroa palkkaa. Elokuun laskelmalla syntyy tuloylijäämää 158 euroa. Koska kyse on joka kuukausi saatavasta säännöllisestä tulosta, ei ylijäämää huomioida tuloksi syyskuulle. Myös syyskuulle syntyy tuloylijäämä 158 euroa.

>ESIMERKKI: Aune on saanut perintönä 900 euroa syyskuussa. Aikaisemmin Aunelle on maksettu laskelman perusteella perustoimeentulotukea noin 300 euroa kuukausittain. Syyskuussa Aunen toimeentulotukilaskelma jää saadun perinnön vuoksi ylijäämäiseksi 600 euroa. Asiassa saatu selvitys huomioiden tuloylijäämän vyöryttämistä ei voida pitää kohtuuttomana ja ylijäämä vyörytetään lokakuun laskelmalle vähäisen määrän ylittävältä osin.

Lue lisää vyöryttämisestä .
