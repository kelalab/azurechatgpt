#### 1.7.1.c Hakemus suullisesti
Toimeentulotuen hakemus voi tulla vireille myös asiakkaan suullisen hakemuksen tai ilmoituksen perusteella. Suullisesti saadut tiedot on aina dokumentoitava.
Kelan työntekijä täyttää suullisen hakemuksen OmaKelassa niiden tietojen perusteella, jotka asiakas puhelimessa tai asiakaspalvelussa antaa.
Lue suullisesta hakemisesta .
