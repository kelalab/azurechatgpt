##### 1.6.1.1.a Vuoroasuminen muun huoltajan luona
Jos lapsi vuoroasuu vanhempansa ja muun huoltajansa luona, on vuoroasumisesta oltava: 
 - kunnan tai hyvinvointialueen toimielimen vahvistama sopimus tai 
 - tuomioistuimen päätös. 

Lapsi muodostaa oman toimeentulotukiperheensä siltä osin, kuin hän asuu muulla huoltajallaan. Jos lapsi vuoroasuu, jaetaan lapsen perusosa vanhemman ja lapsen oman laskelman kesken. Lapsen tulot ja varat huomioidaan pääsääntöisesti puoliksi vanhemman ja lapsen oman laskelman kesken. Lapsen menoja voidaan huomioida sekä vanhemman että lapsen omalla laskelmalla, ei kuitenkaan päällekkäisiä menoja.
Myös silloin, jos lapsi asuu muulla huoltajallaan ja tapaa erillään asuvaa vanhempaansa kunnan tai hyvinvointialueen toimielimen vahvistaman sopimuksen tai tuomioistuimen päätöksen mukaan vähintään 40 % ajasta, on kyseessä lapsen toimeentulotuentarpeen kannalta yleensä vuoroasuminen. Tällöin lapsi kuuluu kahteen toimeentulotukiperheeseen eikä tapaamiskustannuksia huomioida menona.
Vaikka lapsi tapaisi muuta huoltajaansa vähintään 40 % ajasta, ei tapaamista kuitenkaan tulkita vuoroasumiseksi ja lapsi kuuluu vain yhteen toimeentulotukiperheeseen.
