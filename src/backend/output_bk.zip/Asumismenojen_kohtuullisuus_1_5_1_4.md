#### 1.5.1.4 Asumismenojen kohtuullisuus
Asumismenot huomioidaan todellisen suuruisina, jos kustannukset eivät ole kohtuuttomat. Jos hakijan asumismenot ovat paikkakunnan kohtuullista tasoa suuremmat, eikä niitä voida pitää tarpeellisina, huomioitavaa asumismenojen määrää joudutaan kohtuullistamaan vastaamaan paikkakunnan kohtuullisena pidettävää tasoa.
Kohtuullisuusharkinnassa tarkastellaan asumismenojen kohtuullisuutta ja tarpeellisuutta. Kohtuullisten asumiskustannusten arvioimiseksi Kelassa on määritelty kuntakohtaiset asumisnormit, jotka määräytyvät toimeentulotukiperheen koon tai asunnossa asuvien henkilöiden mukaan. Asumisnormeja käytetään sekä vuokra-asuntojen että omistusasuntojen asumismenojen kohtuullisuuden arvioinnissa.
Kohtuullisuusarvioinnissa otetaan huomioon seuraavat menot:


Asumisnormiin kuuluvien kustannusten lisäksi voidaan huomioida erikseen maksettavat vesi-, taloussähkö-, kotivakuutus- ja saunamaksut, jos niitä ei pidetä kohtuuttomina. Vesimaksulle, taloussähkölle, kotivakuutuksella ja saunamaksulle on määritelty Kelassa raja-arvot käsittelyn tueksi ja näiden kohtuullisuus arvioidaan menolajikohtaisesti erillään asumisnormista.
 
Katso energian hintojen nousun vaikutukset asumismenojen huomioimiseen . 
Lue lisää vesi-, taloussähkö-, kotivakuutus ja saunamaksujen kohtuullisuuden arvioimisesta .
Asumismenojen kohtuullisuus arvioidaan aina ensimmäisen hakemuksen tai muuton yhteydessä. Jos hakijan elämäntilanne muuttuu, tarkastellaan asumismenoja uudelleen.
Kohtuullisuusharkinta ei saa johtaa siihen, että toimeentulotuen hakija jää ilman asuntoa tai joutuu muuttamaan asuntoon, joka ei täytä yleisesti hyväksyttävää asumistasoa tai ei vastaa henkilön tai perheen erityisiä tarpeita.
