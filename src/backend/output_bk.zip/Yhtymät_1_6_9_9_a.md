##### 1.6.9.9.a Yhtymät
Yhtymä ei ole varsinainen yritysmuoto, vaan kyseessä on yhteisomistussuhde. Yhtymiä kutsutaan niiden toiminnan luonteen mukaan maatalous-, kiinteistö- tai metsäyhtymiksi. Yhtymä ei ole erillinen verovelvollinen, vaan osuudet yhtymästä (esimerkiksi tulos, palkat ja varat) luetaan yhtymän osakkaiden omiin tuloihin ja varoihin. Yhtymä ei ole yleensä kirjanpitovelvollinen, mutta yhtymän osakas on velvollinen pitämään muistiinpanoja omalta osaltaan yhtymän tuloista ja kuluista sekä ilmoittamaan tiedot veroilmoituksessaan. Jokainen kiinteistön omistaja maksaa kiinteistöveron omasta osuudestaan.
Asiakasta, joka on yhtymän osakkaana, ei pidetä välttämättä toimeentulotuen näkökulmasta yrittäjänä, koska pelkkä yhtymän osakkuus ei estä ensisijaisia toimeentuloa turvaavia etuuksia. Yhtymästä saadut tulot huomioidaan kuitenkin asiakkaan tuloina. Jos asiakasta ei pidetä toimeentulotuen näkökulmasta yrittäjänä yhtymän osakkuuden perusteella, tulee selvittää yhtymän omistuksen arvo sekä mahdollisuudet realisoida omistus tai tarvittaessa määrätä takaisinperinnästä. Lue lisää takaisinperinnästä .
Jos asiakkaalla on estävä työvoimapoliittinen lausunto yhtymässä harjoitetun yritystoiminnan vuoksi, pidetään asiakasta yleensä yrittäjänä myös toimeentulotuessa. Samoin jos asiakkaalla ei ole työvoimapoliittista lausuntoa, mutta hän on osakkaana yhtymässä, joka on arvonlisäverovelvollinen, pidetään asiakasta yleensä yrittäjänä toimeentulotuessa. Tällöin tutkitaan mitä tuloja asiakas saa tai voisi saada yhtymästä sekä onko toiminta kannattamatonta toimeentulotuen näkökulmasta. Jos on epäselvää estääkö asiakkaan osakkuus ensisijaiset toimeentuloa turvaavat etuudet, tulee asiakasta ohjata työ-ja elinkeinopalveluihin selvittämään asiaa.
Yhtymä ei ole osakkaistaan erillinen oikeushenkilö, eikä se voi omistaa varallisuutta. Yhtymästä voidaan kuitenkin maksaa esimerkiksi palkkaa yhtymässä työskenteleville osakkaille. Yhtymä voi lisäksi maksaa osakkaalleen kilometrikorvauksia, jos osakas käyttää autoaan yhtymän ajoihin. Yhtymän hallintaan luovutettu varallisuus kuuluu osakkaille heidän omistuksiensa mukaisesti. Yhtymän toiminnasta saadut varat voidaan menojen vähentämisen jälkeen jakaa osakkaiden kesken yksityisottoina osakkaiden sopimalla tavalla. Jos yhtymällä on rahavaroja, voidaan varat yleensä huomioida laskelmalla osakkaalle osuuksien mukaisessa suhteessa. Tällöin on kuitenkin ensin vähennettävä varoihin kohdistuvat menot sekä otettava huomioon niihin mahdollisesti kohdistuvat hankinnat.
Kaikki yhtymän rahavaroista omaan elatukseen nostetut varat tai yrityksen rahavaroista maksatetut oman yksityistalouden kulut huomioidaan asiakkaan tulona.
Yhtymän osakkaan tuloa voi siten esimerkiksi olla
 - palkat ja palkkiot
 - yksityisotot
 - luontoisedut kuten asunto-, auto-, puhelin- tai ateriaetu
 - varat jotka olisi mahdollista nostaa kyseisenä kuukautena yksityisottoina
 - yritystilin yksityiskäyttö
 - tavaroiden yksityiskäyttö
 - kohtuuttoman suuret kilometrikorvaukset ja päivärahat

Yhtymän osakkaana yritystoimintaa harjoittavalta voidaan pyytää esimerkiksi seuraavat selvitykset tulojen ja varojen selvittämiseksi
 - TO4-lomake
 - yritystoiminnan esitäytetty veroilmoitus
 - yrittäjän ja yhtymän tiliotteet
 - yhtymäsopimus
 - kuukausikohtainen kirjanpito
 - kassavirtalaskelma käteisvaroista tai muu selvitys käteisvarojen määrästä ja käytöstä
 - kirjanpitäjän selvitys yrityksestä saaduista tuloista edelliseltä kuukaudelta, esimerkiksi palkat, luontoisedut
 - kirjanpitäjän selvitys siitä, olisiko varoja voitu jakaa yrityksestä.

Jos yrityksellä ei ole kirjanpitäjää, pyydetään asiakkaan oma selvitys vastaavista tiedoista.
