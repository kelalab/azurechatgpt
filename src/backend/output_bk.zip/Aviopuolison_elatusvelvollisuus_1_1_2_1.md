#### 1.1.2.1 Aviopuolison elatusvelvollisuus
Aviopuolisoiden tulee osallistua toistensa elatukseen. Myös rekisteröidyn parisuhteen osapuolilla on vastaava elatusvelvollisuus toisiaan kohtaan. Alla aviopuolisoista todettu koskee myös rekisteröidyn parisuhteen osapuolia.
Elatusvelvollisuus säilyy, kunnes avioero astuu voimaan. Elatusvelvollisuus jatkuu avioliiton kestoajan riippumatta siitä, asuvatko puolisot yhdessä vai erillään tai onko avioerohakemus vireillä.
Jos asiakas on avioliitossa, mutta hän ei asu yhteistaloudessa aviopuolisonsa kanssa, tulee selvittää laiminlyökö aviopuoliso elatusvelvollisuutensa asiakasta kohtaan:
 - Ennen ensimmäisen päätöksen antamista selvitetään asiakkaalta, osallistuuko aviopuoliso asiakkaan elatukseen ja jos osallistuu, niin millä summalla. Aviopuolison tosiasiallisesti maksaman elatuksen määrä huomioidaan asiakkaan laskelmalla tulona. Lue myös elatuksen määrän arvioimisesta .
 - Tämän jälkeen kuullaan tarvittaessa myös elatusvelvollista aviopuolisoa siitä, osallistuuko hän asiakkaan elatukseen ja minkä verran hänellä on elatuskykyä.

Jos aviopuoliso pystyisi osallistumaan asiakkaan elatukseen ja hän on tahallisesti laiminlyönyt elatusvelvollisuutensa kokonaan tai osittain, toimeentulotukipäätöksessä määrätään asiakkaalle myönnetty toimeentulotuki takaisinperittäväksi aviopuolisolta.
Lue lisää takaisinperinnän perusteista , takaisinperintäprosessista ja elatusvelvollisuuden selvittämisestä.
