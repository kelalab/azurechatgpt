#### 1.1.4.2 Yhteistaloudessa asuvan 18 vuotta täyttäneen perusosa
Jos yhteistaloudessa asuvat henkilöt eivät kuulu samaan perheeseen, jokainen heistä hakee tukea omalla hakemuksellaan ja heille annetaan omat päätökset. Henkilöille huomioidaan yhteistaloudessa asuvan täysi-ikäisen perusosa, koska yhteistaloudessa elinkustannukset ovat henkeä kohden pienemmät. Perusosan suuruus on yhteistaloudesta johtuen 85 % yksin asuvan henkilön perusosan määrästä.
Yhteistaloudessa asuvia henkilöitä ovat
 - samassa huoneistossa asuvat avio- ja avoparit,
 - rekisteröidyssä parisuhteessa asuvat,
 - yhdessä asuvat sisarukset tai kaverukset,
 - kaikki ne, joiden elinkustannukset tosiasiallisten olosuhteiden perusteella ovat alhaisemmat kuin yksin asuvalla henkilöllä,
 - yleensä perhekodissa, ryhmäkodissa tai kimppakämpissä asuvat. Poikkeustilanteessa henkilölle voidaan huomioida yksinasuvan perusosa. Jos esimerkiksi sosiaalialan ammattilaisen selvityksessä todetaan, että henkilö ei hyödy yhteisasumisesta esimerkiksi tukiasumisyksiköissä, eikä henkilö ole voinut vaikuttaa siihen, keiden kanssa hän asuu.

Erilaisissa tilanteissa joudutaan arvioimaan, onko tosiasiallisesti kysymyksessä yhteistalous. Arvioinnissa tulee ottaa huomioon esimerkiksi seuraavia seikkoja:
 - onko henkilöillä yhteinen ruokatalous
 - onko henkilöillä yhteiset talouden käyttötavarat, kuten TV ja kodinkoneet
 - onko henkilöillä yhteinen vuokrasopimus ja muita vastaavia sopimuksia
 - mahdollistaako huoneisto kahden erillisen talouden ylläpidon.

Katso myös taulukko perusosien ja asumismenojen huomioimisesta .

