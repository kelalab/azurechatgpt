##### 1.7.3.1.a Takautuva hakemus
Yli viikon myöhässä hakemiskuukauden päättymisestä saapuvaa hakemusta pidetään takautuvana hakemuksena. Toimeentulotukea ei yleensä myönnetä takautuvasti. Poikkeustilanteissa tukea voidaan kuitenkin myöntää erityisestä syystä takautuvasti, esimerkiksi jos kyseessä on:
 - häätöuhka,
 - asunnottomaksi joutuminen,
 - perheen hajoaminen tai
 - sairaalassaolo.

Jos takautuvan perustoimeentulotuen myöntämiselle ei ole erityisiä perusteita, takautuvaa aikaa koskeva hakemus hylätään.
Edellä mainitussa poikkeuksellisessa tilanteessa takautuvan tuen myöntäminen edellyttää myös, että
 - asiakas olisi ollut kyseisenä takautuvana aikana oikeutettu toimeentulotukeen, mutta ei ole sitä hakenut ja
 - asiakkaan tuen tarpeen pitää yleensä jatkua edelleen tukea haettaessa.

Perustoimeentulotuessa poikkeuksellisesti huomioon otettavia takautuvia menoja voivat olla esimerkiksi vuokra-, terveydenhuolto- ja sähkölaskurästit sekä hyvin harvoin myös perusosa. Yli kuukauden myöhässä olevan hakemuksen perusteella voidaan huomioida vain lähinnä asumiseen ja terveydenhuoltoon liittyviä menoja. Takautuvalta ajalta tuleva tuki maksetaan yleensä suoraan vuokranantajalle tai muulle laskuttajalle. Poikkeuksellisesti voidaan ottaa huomioon takautuvia maksettuja menoja.
Oikeus toimeentulotukeen arvioidaan haetulle takautuvalle ajalle tehtävien laskelmien perusteella.
