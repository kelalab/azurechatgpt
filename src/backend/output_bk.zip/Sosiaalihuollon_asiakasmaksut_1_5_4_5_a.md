##### 1.5.4.5.a Sosiaalihuollon asiakasmaksut
Maksu voidaan määrätä sosiaalihuollon avopalveluista, joita ovat esimerkiksi 
 - kotiin annettavat palvelut 
 - yhteisöllinen asuminen 
 - ympärivuorokautinen palveluasuminen 

Maksu voidaan määrätä sosiaalihuollon laitospalveluista, joita ovat esimerkiksi
 - päihdekuntoutus

Lue lisää kohdasta Hyvinvointialueen järjestämät sosiaali- ja terveydenhuollon avo- ja laitospalvelut .
