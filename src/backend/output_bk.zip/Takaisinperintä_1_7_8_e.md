#### 1.7.8.e Takaisinperintä
Toimeentulotuessa hallinto-oikeus tekee päätöksen etuuden takaisinperinnästä .
