### 1.2.b Ehkäisevä toimeentulotuki
Hyvinvointialue myöntää päättämiensä perusteiden mukaan ehkäisevää toimeentulotukea. Ehkäisevän toimeentulotuen tarkoituksena on edistää henkilön ja perheen sosiaalista turvallisuutta ja omatoimista suoriutumista sekä ehkäistä syrjäytymistä ja pitkäaikaista riippuvuutta toimeentulotuesta.
Ehkäisevää toimeentulotukea voidaan myöntää esimerkiksi
 - tuensaajan aktivointia tukeviin toimenpiteisiin,
 - asumisen turvaamiseksi,
 - ylivelkaantumisesta tai taloudellisen tilanteen äkillisestä heikentymisestä aiheutuvien vaikeuksien lieventämiseksi sekä
 - muihin tuensaajan omatoimista suoriutumista edistäviin tarkoituksiin.

