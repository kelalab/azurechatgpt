##### 1.6.6.1.a Opintotuen peruminen
Jos opiskelija on itse perunut opintotuen esimerkiksi tulorajojen ylittymisen tai opintotukikuukausien säästämisen vuoksi, vaikka hänellä olisi siihen edelleen oikeus, toimitaan seuraavasti:
 - opintolaina huomioidaan edelleen tulona
 - opintorahaa ei huomioida tulona, koska opintotukea ei myönnetä takautuvasti
 - ohjataan asiakasta hakemaan opintotuki uudelleen maksuun ja tehdään opintorahaan saatavasuunnitelma

toimeentulotuki ratkaistaan kuukaudeksi kerrallaan siihen asti, että opintotuki on ratkaistu uudelleen.
