##### 1.5.2.1.5 Uuden vuokravakuuden myöntäminen, kun edellinen vakuus on realisoitunut
Jos Kelan myöntämä vuokravakuus on jouduttu maksamaan vuokranantajalle, uuden vakuuden myöntämistä harkitaan kyseisen hakijan kohdalla tiukemmin sekä tehdään tarvittaessa yhteistyötä sosiaalitoimen kanssa.
Hakijaa tiedotetaan asiasta edellisen vuokavakuuden realisoinnin yhteydessä. Jos hakijalla on elämänhallinnassa haasteita, ei Kelasta myönnetä uutta vakuutta ennen kuin asiakkaan tilannetta on selvitetty sosiaalitoimen kanssa. Asiakas voi tarvita esimerkiksi tuettuja asumispalveluita.
Jos aiempi vuokravakuus on realisoitunut maksamattomien vuokrien takia ja asiakkaalle myönnetään uusi vuokravakuus, maksetaan perustoimeentulotuen vuokraosuus jatkossa Kelasta suoraan vuokranantajalle.
