## 1.11 Päätöksen korjaaminen
Päätös voi olla jo sen antamishetkellä virheellinen siinä olevan asia- tai kirjoitusvirheen vuoksi. Päätöksessä olevan virheen korjaamisessa noudatetaan pääsääntöisesti hallintolain säännöksiä. Tähän poikkeuksen muodostavat kuitenkin asiakkaan vilpillisestä menettelystä johtuvat virhetilanteet. Lue lisää ilmoitusvelvollisuuden laiminlyönnistä .
Päätös voidaan korjata esimerkiksi, jos
 - hakija asuu yhteistaloudessa eikä Kela ole huomioinut puolisoa päätöksessä, vaikka hakija on ilmoittanut olosuhdemuutoksesta,
 - kun ratkaisussa on jäänyt huomioimatta hakijan ilmoittama tulo, jota on maksettu jo päätöksentekoajankohtana tai
 - hakija tai perheenjäsen oleskelee pidempiaikaisesti ulkomailla ja sitä ei ole ilmoituksesta huolimatta huomioitu Kelassa.

Asiavirheen korjaaminen tulee erottaa päätöksen tarkistamisesta , josta säädetään toimeentulotukilaissa.
Päätöksessä olevan virheen korjaaminen tulee erottaa myös oikaisuvaatimusmenettelystä. Virheen korjaamisen tulisi olla ensisijaista muutoksenhakuun nähden. Päätöksessä oleva virhe voidaan korjata, vaikka asiakas olisi jo valittanut päätöksestä . Korjaamisasian käsiteltäväksi ottamisesta ja päätöksen korjaamisesta tulee ilmoittaa muutoksenhakuviranomaiselle.
