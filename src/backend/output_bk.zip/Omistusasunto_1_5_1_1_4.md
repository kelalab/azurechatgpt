##### 1.5.1.1.4 Omistusasunto
Kyseessä on omistusasunto, jos toimeentulotuen hakija tai perheenjäsen omistaa asunnosta 50 % tai enemmän tai hakija ja perheenjäsen yhdessä omistavat asunnosta 50 % tai enemmän. Katso yrittäjäasiakkaan asumismenojen huomioimisesta.
Asuntolainan ottaja ja käyttötarkoitus osoitetaan pankin selvityksellä. Asuntolainan tulee olla valtion, kunnan, seurakunnan tai julkisen valvonnan alaisen luottotoimintaa harjoittavan laitoksen myöntämä. Asuntolainan tulee kohdistua hakijan tai perheen omistamaan asuntoon ja sen tulee olla hakijan tai perheenjäsenen nimissä.
