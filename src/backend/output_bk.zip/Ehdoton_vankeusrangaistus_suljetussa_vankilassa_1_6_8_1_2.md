##### 1.6.8.1.2 Ehdoton vankeusrangaistus suljetussa vankilassa
Ehdotonta vankeusrangaistusta suljetussa vankilassa suorittava vanki saa yleensä verotonta käyttörahaa ja toimintarahaa. Toimintarahaa maksetaan suljetussa vankilassa joko 3,01 euroa tai 4,62 euroa toimintapäivää kohti. Käyttö- ja toimintarahan määrä on yleensä yhteensä keskimäärin joko 111 euroa tai 145 euroa kuukaudessa.
