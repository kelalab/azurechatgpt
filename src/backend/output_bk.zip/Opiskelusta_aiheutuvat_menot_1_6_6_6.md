#### 1.6.6.6 Opiskelusta aiheutuvat menot
Korkeakouluopiskelijoiden opiskelijaterveydenhuollon maksu huomioidaan menona laskelmalla. Lisäksi menona huomioidaan opiskelijaterveydenhuollon palveluiden käytöstä aiheutuvat maksut, sillä ne ovat julkista terveydenhoitoa.
Hyvinvointialueen myöntämästä täydentävästä toimeentulotuesta voi olla mahdollista kattaa toisen asteen ensimmäisestä tutkinnosta aiheutuvia erityisiä menoja sekä opiskelukustannuksia (kuten lukukausimaksut, pääsykoe- ja ylioppilaskirjoitusmaksut sekä opiskeluvälineet). Katso myös hakemuksen siirtäminen hyvinvointialueelle .
