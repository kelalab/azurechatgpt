###### 1.5.1.1.1.a Vuokralla omakotitalossa
Omakotitalon asumismenoina voidaan huomioida vain ne menot, jotka on mainittu vuokrasopimuksessa. Katso omakotitalossa huomioitavat menot kohdasta Omistusasunto, Omakotitalon menot .
Katso kohdasta Asumismenot, joita ei huomioida , mitä menoja omakotitalossa ei voida huomioida.
