#### 1.7.10.3 Kiireellinen hakemus
Kun asiakkaan toimeentulotuen tarve on kiireellinen, hakemus on ratkaistava hakemuksen saapumispäivänä tai sitä seuraavana arkipäivänä. Asiakkaan on tällöin asioitava joko puhelimitse tai palvelupisteessä ja kerrottava tarve kiireelliselle toimeentulotuelle ja esitettävä perusteet kiireellisyydelle. Hakemuksessa kiireelliseksi ilmoitettu meno ei aina vaadi kiireellistä päätöksentekoa. Kela ratkaisee asian kiireellisyyden tapauskohtaisesti. Asiakasta ohjataan toimimaan niin, että hakemuksen käsittely kiireellisenä voidaan välttää. Asiakkaalle kerrotaan esimerkiksi Kelan käsittelyajoista ja hyvinvointialueen sosiaalihuollon palveluista.
Kiireellinen hakemus on kysymyksessä esimerkiksi elämäntilanteen muutoksessa, jota seuraa yllättävä rahattomuus. Tällöin asiakkaan tai perheen asuminen, terveys tai eläminen on välittömässä vaarassa. Yleisimmät kiireellisyyden syyt ovat:
 - Asumisen turvaaminen Häätö tai häätöuhka Sähkön ja lämmön saannin vaarantuminen

 - Terveys Kiireellinen lääke Sairaalasta kotiutuminen

Kiireellinen tarve ravintomenoihin
Edellä on esitetty yleisimpiä kiireellisiä tilanteita. Kiireellisyys arvioidaan aina tapauskohtaisesti ja sen arvioinnissa tulee käyttää harkintaa. Lue lisää kiireellisyyden arvioinnista.
Tarvittaessa kiireellinen hakemus ratkaistaan käytettävissä olevien tietojen perusteella, jolloin tuki voidaan myöntää vain lyhyeksi ajaksi kerrallaan. Tällöin tuki myönnetään vain joidenkin päivien tai viikon ajaksi esimerkiksi maksusitoumuksena ravinto- tai reseptilääkemenoihin. Tulot ja varat otetaan huomioon vain siltä osin kuin ne ovat asiakkaan tai hänen perheensä käytettävissä hakemusta ratkaistaessa. Tämän vuoksi hakemus on yleensä tarpeen ratkaista muilta osin myöhemmin ja kiireellisenä myönnetty tuki huomioidaan tulona, kun asiassa annetaan tarkistuspäätös. Kiireellistä tukea koskevassa päätöksessä asiakkaalle kerrotaan, että asia ratkaistaan kokonaisuudessaan, kun puuttuvat selvitykset on saatu. Jos kaikki tiedot kuitenkin ovat käytettävissä, voidaan kiireellinen hakemus ratkaista samalla koko kuukauden etuusjakson ajalta.
Kiireellisessä tuen tarpeessa voidaan menoina huomioida esimerkiksi
 - perusosan ravintomenojen osuus ravintomenoihin
 - reseptilääkkeet, jotka on arvioitu tarvittaviksi kiireellisesti

>ESIMERKKI: Maija kotiutuu sairaalasta torstaina. Hänen saa eläkkeensä vasta viikon kuluttua. Maija on täysin rahaton eikä pysty ostamaan hänelle määrättyjä lääkkeitä. Maijalle voidaan myöntää kiireellisenä perustoimeentulotukena eläkkeen maksuun saakka maksusitoumus perusosan ravinto-osuuteen sekä maksusitoumus reseptilääkkeisiin.

Kun kiireellisestä perustoimeentulotuesta tehdään Kelassa päätös, arvioidaan, onko hakemuksessa menoja, jotka voitaisiin huomioida täydentävässä tai ehkäisevässä toimeentulotuessa hyvinvointialueella. Tarvittaessa tehdään hyvinvointialueen kanssa yhteistyötä kiireellisyysarvioinnissa. Jos tarve on kiireellinen, hakemus siirretään kiireellisenä hyvinvointialueelle. Siirto edellyttää, että asiakas on tätä pyytänyt ja kyse on menosta, joka voidaan siirtää.
>ESIMERKKI: Eskon omistusasunnon jääkaappi on mennyt rikki kesähelteillä. Hänellä on perhettä ja ruokahuolto on haastavaa hoitaa ilman jääkaappia. Hän hakee perustoimeentulotukea ja pyytää siirtämään hakemuksen tarvittaessa kuntaan. Hakemus käsitellään perustoimeentulotuen osalta kiireellisesti ja siirretään kiireellisenä kuntaan.

Kiireellisen väliaikaismajoituksen järjestäminen kuuluu kunnalle. Jos asiakkaalla on kiireellinen majoitustarve, ollaan Kelasta yhteydessä asiakkaan luvalla kunnan yhteyshenkilöön majoitusasian vireille tulon varmistamiseksi. Jos asiakas ei anna lupaa yhteydenottoon, hänelle kerrotaan, miten hän voi saada asian vireille kunnassa. Lapsiperheiden osalta arvioidaan aina lastensuojeluilmoituksen tarve.
Asiakas ohjataan hyvinvointialueelle myös, jos hänen arvioidaan tarvitsevan myös sosiaalihuollon palveluita . Jos asiakas on ilmeisen kyvytön huolehtimaan itsestään tai kriteerit lastensuojeluilmoituksen tekemiselle täyttyvät, hyvinvointialueelle voidaan olla yhteydessä ilman asiakkaan suostumusta. 
Katso lisää kiireellisen toimeentulotuen myöntämisestä elintarvikkeisiin .
Lue lisää kiireellisen toimeentulotuen prosessista .

