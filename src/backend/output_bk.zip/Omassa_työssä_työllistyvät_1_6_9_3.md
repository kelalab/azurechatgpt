#### 1.6.9.3 Omassa työssä työllistyvät
Asiakas voi työllistää itse itsensä siten, että hän on saanut TE-palveluilta estävän työvoimapoliittisen lausunnon omassa työssä työllistymisen vuoksi. Tällaisia omassa työssä työllistyviä henkilöitä voivat olla esimerkiksi urheilijat, taiteilijat, freelancerit ja erilaiset sosiaalisen median vaikuttajat. Henkilöllä tulee olla ansaintatarkoitus toiminnalleen, eli esimerkiksi omaishoitajiin ei sovelleta seuraavaa ohjetta.
Toimeentulotukilain mukaan jokaisella on velvollisuus pitää huolta omasta elatuksestaan. Jos asiakas työllistää itsensä siten, että ensisijaiset toimeentuloa turvaavat etuudet estyvät eikä asiakkaalle voida tarjota työtä tai työvoimapoliittisia toimenpiteitä eikä hän lisäksi pidempiaikaisesti saa riittävää toimeentuloa omasta työstään, voidaan asiakkaalle antaa 3-6 kuukauden järjestelyaika järjestellä toimintansa kannattavaksi tai lopettaa se. Jos järjestelyajan päätyttyä asiakas jatkaa toimintaansa siten, että ensisijaiset etuudet estyvät tämän toiminnan vuoksi, eikä hän saa toiminnastaan riittävää toimeentuloa, voidaan hänen katsoa laiminlyöneen velvollisuutensa pitää huolta omasta elatuksestaan. Tällainen menettely voidaan rinnastaa siihen, että henkilön toimeentulotuen tarve aiheutuu siitä, että hän on omalla laiminlyönnillään aiheuttanut sen, ettei työtä tai julkista työvoimapalvelua ole voitu tarjota. Perusosan alentamista harkittaessa asiakasta kuullaan ja hänelle annetaan järjestelyaika kuten kannattamattoman yritystoiminnan perusteella annetun järjestelyajan yhteydessä. Lue lisää perusosan alentamisesta .
Omassa työssä työllistyvälle huomioidaan tuloksi kaikki käytettävissä olevat tulot. Toiminnasta saadut tulot voidaan vyöryttää ja jaksottaa. Omassa työssä työllistyvän tuloa voi esimerkiksi olla:
 - taideapuraha
 - tekijänoikeuskorvaukset
 - palkinto- ja sponsorirahat
 - urheiluseuran maksamat korvaukset
 - mainostulot
 - erilaiset palkkiot ja palkat
 - veronalaisten hyödykkeiden edelleen luovutuksesta saadut tulot

Asiakkaan saamasta tulosta voidaan vähentää kyseisen työsuorituksen teosta aiheutuneita kustannuksia samoin edellytyksin kuin yrittäjillä. Asiakkaan tulee esittää selvitystä aiheutuneiden kulujen kohdentamisesta sekä määrästä, esimerkiksi kuitit tehdyistä ostoista. Saadusta tulosta voidaan vähentää vain juuri kyseiseen työsuoritukseen liittyviä menoja.
>ESIMERKKI: Jaanalla on TE-palveluiden lausunto siitä, että hän työskentelee taitelijana eikä hän tämän vuoksi ole oikeutettu työttömyysetuuteen. Jaana on saanut taulun myynnistä tuloa 500 euroa. Jaana ilmoittaa ostaneensa kyseisen taulun tekoa varten materiaaleja 100 eurolla ja toimittaa ostoista kuitit. Jaanalle huomioidaan ansiotulona 400 euroa taulun myynnistä, josta tehdään lisäksi 150 euron ansiotulovähennys. 

