#### 1.5.4.4 Terveydenhuoltoon liittyvät yöpymiskustannukset
Terveydenhuollon menona voidaan huomioida syntyneet yöpymiskulut esimerkiksi potilas- tai sairaalahotellissa, joista on saatu sv-lain mukainen korvaus. Matkan tulee olla suuntautunut julkiseen hoito- tai tutkimuslaitokseen. Yöpymisen syy tulee olla esimerkiksi
 - lähiomaisen, yleensä lapsen, välttämätön hoitoon osallistuminen menot kirjataan sen henkilön menoiksi, kenen hoidosta on kysymys

 - tutkimus, hoito tai kuntoutus alkaa niin, ettei kotipaikkakunnalta ole mahdollista matkustaa samana päivänä

toistuvien päivittäisten matkojen välttäminen tutkimus- tai hoitojakson aikana kodin ja hoitopaikkakunnan välillä. Lue lisää toimeentulotukeen kuuluvista terveydenhuollon matkoista.
