###### 1.5.4.2.2.b Maksusitoumus hammasteknisen ja kliinisen työn kustannuksiin
Jos hyvinvointialue ohjaa kokoproteesihoitoa tarvitsevan asiakkaan suoraan yksityiselle erikoishammasteknikolle, jonka kanssa hyvinvointialueella ei ole sopimusta, voidaan erikoishammasteknikolle hoitoon ohjatulle asiakkaalle antaa maksusitoumus hyvinvointialueen hammaslääkärin tekemän hoitosuunnitelman ja kustannusarvion pohjalta. Kustannusarviossa tulee olla
 - eriteltynä kliinisen ja hammasteknisen työn kustannukset sekä
 - tieto hammasteknisen työn palveluntuottajasta tai palveluntuottajista

Kun asiakas tarvitsee kokoproteesin tai kokoproteesit, erikoishammasteknikko tekee sekä kliinisen että teknisen työn. Maksusitoumus erikoishammasteknikolle voidaan antaa hyvinvointialueen hammaslääkärin tekemän kustannusarvion pohjalta teknisen ja kliinisen työn kustannuksiin.
Hyvinvointialue voi myös ohjata kokoproteesihoitoa tarvitsevan asiakkaansa suoraan yksityiselle erikoishammasteknikolle, jonka kanssa hyvinvointialueella on sopimus. Tilanteessa, jossa hyvinvointialue on ohjannut asiakkaan hoitoon hyvinvointialueen sopimuserikoishammasteknikolle ei tarvita maksusitoumusta, vaan kustannukset huomioidaan edellytysten täyttyessä laskun mukaan.
Lue lisää tarvittavista selvityksistä ja menettelystä prosessikuvauksesta .
