###### 1.5.1.4.7.a Muutto omakotitaloon
Kun hakija on muuttamassa vuokralle omakotitaloon, hakijan tulee selvittää, mitä kustannuksia hänellä on vuokran lisäksi esimerkiksi lämmitys ja jätehuolto.
Jos vuokrasopimuksesta ei käy riittävällä tasolla ilmi kuukausittaiset asumiskustannukset, tulee hakijalta pyytää vuokranantajan arvio kuukausittaisista kustannuksista, erityisesti lämmitysmenoista. Tällaisen arvion saa yleensä vuokranantajalta.
Jos hakijalta ei saada arviota asumisen kokonaiskustannuksista, ei muuttoa voida tukea perustoimeentulotuella, koska asumismenojen kohtuullisuusarviointia ei voida tehdä.
