##### 1.5.2.1.3 Vuokravakuuden myöntäminen
Vuokravakuus voidaan pääsääntöisesti myöntää, jos
 - hakijalla on oikeus perustoimeentulotukeen vuokravakuuden erääntymiskuukaudelle,
 - muutto on perusteltu,
 - asunto on Kelan asumisnormin mukainen tai hakijalla on erityiset perusteet kohtuullista tasoa kalliimmalle asunnolle ja
 - asunto on asuinkäyttöön sopiva .

