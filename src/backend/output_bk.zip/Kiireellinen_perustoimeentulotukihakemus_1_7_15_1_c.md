##### 1.7.15.1.c Kiireellinen perustoimeentulotukihakemus
Jos asiakkaan tilanne edellyttää kiireellisen perustoimeentulotuen myöntämistä, eikä kaikkia tietoja ole käytettävissä, käsitellään hakemus käytettävissä olevilla tiedoilla. Tällöin toimeentulotuki myönnetään yleensä muutamalle päivälle. Lue lisää kiireellisen hakemuksen käsittelystä .
