###### 1.5.1.1.5.e Asunnoton
Hakija tulkitaan asunnottomaksi, kun hän on ilman vakinaista asuinpaikkaa esimerkiksi:
 - asuu ulkona
 - tilapäisesti kavereiden tai sukulaisten luona
 - yömajassa, tilapäissuojassa tai hätämajoituksessa
 - yli 25-vuotias aikuinen lapsi, joka asuu vanhempiensa luona tilapäisesti, eikä maksa vuokraa

