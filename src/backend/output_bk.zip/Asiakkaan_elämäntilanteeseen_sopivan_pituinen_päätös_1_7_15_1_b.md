##### 1.7.15.1.b Asiakkaan elämäntilanteeseen sopivan pituinen päätös
Toimeentulotuessa on mahdollista antaa asiakkaan elämäntilanteeseen sopivan pituinen päätös esimerkiksi 3-6 kuukaudelle, kun asiakkaan tulot ja menot (vuokra) ovat säännölliset kuukausittain. Päätöstä tehtäessä on arvioitava kaikkien perheenjäsenten osalta tulojen pysyvyyttä.
Perustoimeentulotuen jatkopäätös voidaan tehdä enintään 12 kuukaudeksi, jos hakijan ja perheen tilanne ei todennäköisesti muutu siten, että perustoimeentulotukea joudutaan tarkistamaan pian päätöksen antamisen jälkeen. Päätös voidaan tehdä enintään asiakkaan hakemuksen mukaisesti.
On huomioitava, että heinä-joulukuussa maksettavat veronpalautukset sekä kesä- tai heinäkuussa maksettavat lomarahat aiheuttavat usein tarpeen tarkistaa päätökset.
Tulottomille asiakkaille on mahdollista tietyissä tilanteissa antaa elämäntilanteeseen sopivan pituinen päätös .
