#### 1.1.4.3 Vanhempansa luona tai kanssa asuvan 18 vuotta täyttäneen perusosa
Jos 18 vuotta täyttänyt henkilö asuu vanhempansa luona, hän tekee oman toimeentulotukihakemuksen. Hänelle tehdään oma päätös sekä toimeentulotukilaskelma, jossa otetaan huomioon hänen toimeentulotuessa huomioitavat tulot ja menot. Yläikärajaa ei ole säädetty. Vanhempiensa tai vanhempansa luona asuvan yli 18-vuotiaan perusosa on 73 % yksin asuvan henkilön perusosan määrästä.
Jos vanhempi asuu täysi-ikäisen lapsensa luona, täysi-ikäiselle lapselle huomioidaan yhteistaloudessa asuvan perusosa.
Lue lisää perusosien ja asumismenojen huomioimisesta .

