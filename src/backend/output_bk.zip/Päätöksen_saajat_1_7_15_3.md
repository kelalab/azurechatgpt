#### 1.7.15.3 Päätöksen saajat
Täysi-ikäiselle tehdystä ratkaisusta lähetetään aina päätös hakijalle itselleen. Kun hakijalla on edunvalvoja tai edunvalvontavaltuutettu, päätös lähetetään myös heille.
Jos päätös sisältää maksusitoumuksen, myös maksusitoumus lähetetään hakijalle. Maksusitoumusta ei lähetetä kahteen kertaan. Jos hakijalla on esimerkiksi edunvalvoja, edunvalvojalle menevässä päätöksessä kerrotaan tieto maksusitoumuksen myöntämisestä.
Määrätyn edunvalvojan tai edunvalvontavaltuutetun pyynnöstä maksusitoumus voidaan toimittaa hakijan sijasta edunvalvojalle tai edunvalvontavaltuutetulle.
Jos hakijalla on turvakieltomääräys, noudata turvakielto-ohjeiden kohtaa etuuksien ratkaiseminen .
