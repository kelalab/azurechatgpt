### 1.3.6 Tulo ei ole ollut tiedossa toimeentulotuesta päätettäessä 
 
