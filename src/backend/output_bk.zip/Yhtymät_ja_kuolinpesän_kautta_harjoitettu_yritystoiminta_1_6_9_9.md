#### 1.6.9.9 Yhtymät ja kuolinpesän kautta harjoitettu yritystoiminta
Muita taloudellista toimintaa harjoittavia yhteisöjä voivat olla esimerkiksi yhtymä tai elinkeinotoimintaa harjoittava kuolinpesä.
