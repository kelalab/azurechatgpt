### 1.9.1 Sosiaalityön tarpeen arviointi
Kelan on tarvittaessa ohjattava ja neuvottava asiakasta Kelan etuuksista ja palveluista. Tarvittaessa asiakasta on lisäksi ohjattava hakeutumaan hyvinvointialueen sosiaalihuoltoon tai muihin palveluihin. Huomioon tulee ottaa aina asiakkaan tai perheen kokonaistilanne. Ensin on selvitettävä, kuinka asiakkaan tilannetta voidaan auttaa Kelan omin palveluin. Kun huoli asiakkaan tilanteesta syntyy, otetaan asiakkaaseen yhteyttä ja asia otetaan hänen kanssaan puheeksi. Jos selkeästi ilmenee, että asiakas tarvitsisi Kelan omia ohjaus- ja neuvontapalveluita, tehdään asiakkaalle ajanvaraus. Asiakas voi esimerkiksi tarvita apua ensisijaisten Kelan etuuksien hakemisessa.
Perustoimeentulotuen käsittelyn yhteydessä voi tulla esille myös tarve sosiaalityöhön esimerkiksi seuraavissa tilanteissa:
 - Asiakkaalle on kertynyt vuokra- tai sähkörästejä useammalta kuukaudelta, erityisesti lapsiperheiden kohdalla.
 - Asiakkaalle annettu vuokravakuus realisoituu toistuvasti.
 - Asiakas ei suostu hakemaan ensisijaisia etuuksiaan esimerkiksi kykenemättömyyden vuoksi.
 - Asiakkaan opinnot pitkittyvät, eikä hänelle enää myönnetä opintotukea.
 - Asiakkaalla on rahankäyttövaikeuksia, ja perustoimeentulotuki joudutaan maksamaan osissa tai välitystilin käyttö tulisi välttämättömäksi.
 - Asiakkaan elämäntilanteessa tulee esiin muun muassa pelaamiseen tai päihteiden käyttöön liittyviä jatkuvia ongelmia.
 - Asiakas on pitkäaikaisesti laitoshoidossa eli yli 6 kuukauden ajan, ja arvioidaan, ettei asiakas esimerkiksi ikänsä tai terveydentilansa vuoksi pysty huolehtimaan mahdollisesta muutosta tai muuten asioidensa hoidosta. Asiakkaalla ei myöskään ole taloudellisiin asioihin määrättyä edunvalvojaa, jonka puoleen kääntyä.

Kun Kelassa havaitaan, että asumiskulut ovat kohtuullista suuremmat ja asiakasta kehotetaan hankkimaan edullisempi asunto, asiakas tulee ohjata kunnan asumispalveluihin asuntoasian selvittämistä varten.
Jos Kelan omat ohjaus- ja neuvontapalvelut eivät ole riittäviä asiakkaalle ja käsittelijä arvioi, että asiakkaalla on sosiaalityön tarve, asiasta keskustellaan asiakkaan kanssa. Yhteydenotto sosiaalipalveluihin voi yleensä tapahtua asiakkaan suostumuksella ja hänen toivomuksestaan se on aina tehtävä. Ensisijaisesti asiakkaalta pyydetään aina suostumus ilmoittamiseen tai yhteydenottoon sosiaalipalveluihin. Tietyissä jäljempänä käsiteltävissä tilanteissa Kelan on kuitenkin tehtävä ilmoitus hyvinvointialueelle salassapitosäännösten estämättä. Näissä tilanteissa konsultoidaan ennen ilmoituksen tekemistä esimerkiksi esimiestä tai osaamiskeskusta.
Lue lisää ilmoituksen tekemisestä .
