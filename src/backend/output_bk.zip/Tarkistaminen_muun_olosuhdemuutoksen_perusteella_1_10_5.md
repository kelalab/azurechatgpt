### 1.10.5 Tarkistaminen muun olosuhdemuutoksen perusteella
Kun olosuhteet muuttuvat muutoin kuin tulojen osalta, perustoimeentulotuki tarkistetaan muutosajankohdasta lukien.
Tyypillisiä tilanteita ovat perhekoon muutokset syntymän, kuoleman ja yhteen tai erilleen muuton vuoksi. Asiakasta ei tarvitse kuulla syntymän tai kuoleman yhteydessä, koska Kela saa tarvittavat tiedot väestötietojärjestelmästä.
>ESIMERKKI: Hakijalle ja puolisolle on tehty toimeentulotukipäätös tammikuulle. Perheeseen on syntynyt lapsi 17.1., joten tarkistus tehdään 17.1. alkaen. Tarkistuksessa huomioidaan lapsen perusosa ajalle 17.–31.1. Lapsilisä huomioidaan tulona maksupäivän mukaisesti. Päätös tarkistetaan näissä tilanteissa asiakkaan eduksi, joten kuuleminen on tarpeetonta.
