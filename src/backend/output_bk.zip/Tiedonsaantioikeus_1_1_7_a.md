#### 1.1.7.a Tiedonsaantioikeus
Kelalla on oikeus saada pyynnöstä toimeentulotuen käsittelyn kannalta välttämättömiä tietoja esimerkiksi seuraavilta tahoilta:
 - valtion viranomainen
 - kunnan tai kuntayhtymän viranomainen
 - hyvinvointialueen viranomainen 
 - muu julkisoikeudellinen yhteisö
 - Eläketurvakeskus
 - eläkesäätiö
 - muu eläkelaitos
 - vakuutuslaitos
 - koulutuksen järjestäjä
 - sosiaalipalvelun tuottaja
 - terveyden- ja sairaudenhoitotoimintaa harjoittava yhteisö tai toimintayksikkö
 - terveydenhuollon ammattihenkilö
 - tietyin edellytyksin rahalaitos

Kelalla on lisäksi oikeus pyynnöstä saada toimeentulotuen käsittelyn kannalta välttämättömät vuokrasuhteeseen ja asumiseen liittyvät tiedot vuokranantajalta ja asunto-osake- tai kiinteistöosakeyhtiöiltä. Kelalla on myös oikeus saada apteekilta ja lääkkeellisen hapen toimittajalta tiedot muina perusmenoina katettavista lääkemääräyksellä tehdyistä lääkeostoista tai muista lääkemääräyksellä tehdyistä ostoista sekä lääkkeelliseen happeen liittyvistä kustannuksista.
