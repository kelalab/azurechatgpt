###### 1.5.1.4.8.b Taloussähkömenojen kohtuullisuus
Katso kohtuulliset taloussähkömenot täältä .
Jos taloussähkömenot
 - ylittävät vähäisesti Kelan normin, hyväksytään lasku kokonaisuudessaan.
 - ylittävät huomattavasti Kelan normin, soitetaan asiakkaalle ja kysytään asiakkaan selvitystä suuresta sähkönkulutuksesta ennen hakemuksen tai laskun käsittelyä.

Jos menoa ei selvitysten perusteella voida hyväksyä kokonaisuudessaan tai selvitystä suuresta sähkönkulutuksesta ei saada, sähkömenot kohtuullistetaan Kelan normin mukaisiksi. Kohtuullisuusarvioinnissa on aina huomioitava, että hakija ei voi vaikuttaa sähkönsiirto- tai perusmaksuihin. Kun asiakkaalta on kerran selvitetty, että perusteita korkeammille taloussähkömenoille ei ole ja sähkölaskut edelleen pysyvät kohtuuttoman suurina, jatketaan sähkömenojen kohtuullistamista. 
Katso energian hintojen nousun vaikutukset asumismenojen huomioimiseen . 

