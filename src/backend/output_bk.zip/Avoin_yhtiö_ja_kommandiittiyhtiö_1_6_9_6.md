#### 1.6.9.6 Avoin yhtiö ja kommandiittiyhtiö
Avoin yhtiö on kahden tai useamman henkilön yhdessä muodostama yritys. Yhtiömiehet vastaavat yrityksen veloista ja sitoumuksista myös kaikella henkilökohtaisella omaisuudellaan. Kommandiittiyhtiö on kahden tai useamman henkilön muodostama yritys, jossa on vähintään yksi vastuunalainen yhtiömies ja vähintään yksi äänetön yhtiömies. Avoin yhtiö ja kommandiittiyhtiö ovat kirjanpitovelvollisia.
Kommandiittiyhtiön vastuunalainen yhtiömies toimii varsinaisesti yhtiön nimissä samoin kuin avoimen yhtiön yhtiömies. Äänetön yhtiömies ainoastaan sijoittaa rahaa tai muuta omaisuutta yhtiöön. Äänettömän yhtiömiehen vastuu yrityksen sitoumuksista rajoittuu hänen yritykseen sijoittamansa omaisuuden määrään eikä hänellä ole oikeutta edustaa yhtiötä eikä nostaa yhtiön varoja. Yhtiösopimukseen merkitään äänettömän yhtiömiehen yritykseen sijoittama summa, jolle hän saa jatkossa tuottoa. Äänettömänä yhtiömiehenä yrityksessä olevaa asiakasta ei yleensä pidetä toimeentulotuessa yrittäjänä, vaikka hän työskentelisi yrityksessä. Äänettömän yhtiömiehen kohdalla tulee asiakasta ohjata selvittämään mahdollisuutensa luovuttaa osuutensa yhtiöstä edelleen ja käyttämään luovutuksesta saadut tulot oman elatuksensa turvaamiseen. Äänettömälle yhtiömiehelle huomioidaan tulona yrityksestä maksetut korot ja voitto-osuudet.
Avoimen yhtiön yhtiömiehen ja kommandiittiyhtiön vastuunalaisen yhtiömiehen tuloa voi esimerkiksi olla
 - starttiraha
 - palkat ja palkkiot
 - yksityisotot
 - yritystilin yksityiskäyttö
 - varat jotka olisi mahdollista nostaa kyseisenä kuukautena yksityisottoina
 - tavaroiden yksityiskäyttö
 - voitto-osuudet
 - luontoisedut (kuten asunto-, auto-, puhelin-, ateriaetu)
 - kohtuuttoman suuret kilometrikorvaukset ja päivärahat
 - lainat

Arvioitaessa yhtiömiehen mahdollisuuksia saada tuloja yrityksestään, tulee aina huomioida, ovatko tulot tai varat tosiasiallisesti yrittäjän omaan elatukseen käytettävissä. Yrityksestä saatavissa olevat tulot ja varat ovat asiakkaan käytettävissä esimerkiksi silloin, kun hän
 - on saanut tuloja yrityksestä käyttöönsä,
 - on käyttänyt yritystiliä omiin henkilökohtaisiin menoihinsa tai
 - itse tai yhdessä toimeentulotukiperheensä kanssa voisi päättää yrityksen varojen jakamisesta.

Jos yhtiön omistus on hajautunut ja asiasta saadun selvityksen perusteella voidaan arvioida, että yhtiön olisi pitänyt pystyä juoksevien kulujen ja investointien jälkeen maksamaan yhtiömiehille palkkaa, mutta palkkaa ei ole maksettu, pyydetään asiakkaalta kirjanpitäjän selvitys siitä, olisiko varoja voitu jakaa yrityksestä.
Avoimen yhtiön yhtiömieheltä tai kommandiittiyhtiön vastuunalaiselta yhtiömieheltä voidaan pyytää esimerkiksi seuraavat selvitykset tulojen ja varojen selvittämiseksi:
 - TO4-lomake
 - yritystoiminnan esitäytetty veroilmoitus
 - yrittäjän ja yrityksen tiliotteet
 - kuukausikohtainen kirjanpito
 - tilinpäätös
 - yrityksen perustamissopimus ja yhtiösopimus
 - kassavirtalaskelma käteisvaroista tai muu selvitys käteisvarojen määrästä ja käytöstä
 - kirjanpitäjän selvitys yrityksestä saaduista tuloista edelliseltä kuukaudelta, esimerkiksi palkat, luontoisedut
 - kirjanpitäjän selvitys siitä, olisiko varoja voitu jakaa yrityksestä.

Jos yrityksellä ei ole kirjanpitäjää, pyydetään asiakkaan oma selvitys vastaavista tiedoista.
