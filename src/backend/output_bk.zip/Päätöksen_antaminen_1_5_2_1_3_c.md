###### 1.5.2.1.3.c Päätöksen antaminen
Kela antaa vuokravakuutta koskevan päätöksen tiedoksi vain hakijalle. Hakijan pyynnöstä maksusitoumus voidaan lähettää Kelasta suoraan vuokranantajalle. Vuokravakuusmeno kohdistetaan siihen kuntaan, jonka alueella hakija oleskelee, kun vakuus myönnetään. Lue lisää kustannusten kohdentamisesta kuntaan .
Jos vuokravakuus on myönnetty asuntotarjouksen perusteella, tulee hakijan toimittaa Kelaan vuokrasopimus 3 kuukauden kuluessa vuokravakuuden myöntämisestä.
