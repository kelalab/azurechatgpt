#### 1.3.4.1 Yksityishenkilön avustukset, tilillepanot ja lainat
Sukulaisen tai muun yksityishenkilön tekemät tilillepanot otetaan tulona huomioon. Rahan tulolähteellä tai sillä, että suoritukset on annettu lainaksi, ei yleensä ole merkitystä.
Yksityishenkilöiden avustuksista otetaan tulona huomioon yksin asuvalta 50 euron ja toimeentulotukiperheeltä 100 euron yli menevä osuus.
Avustukset ja tilillepanot huomioidaan niiden maksukuukaudelle tuloksi ja tulo voidaan jaksottaa tai vyöryttää .
Yksityishenkilöltä saatua lainaa ei kuitenkaan huomioida tulona siltä osin, kun se on etuusjakson aikana maksettu takaisin tai hakija on luotettavasti selvittänyt käyttäneensä sen toimeentulotuessa hyväksyttävään tarkoitukseen, kuten vuokravakuuteen.
>ESIMERKKI: Anni saa syntymäpäivälahjaksi elokuussa veljeltään 40 euroa. Koska Annin saama tulo 40 euroa on määrältään vähäinen, alle 50 euroa, ei sitä huomioida hänen tulonaan. Veljeltä saamansa 40 euron avustuksen lisäksi myös Annin äiti on päättänyt lahjoittaa Annille elokuussa 40 euroa. Elokuussa saatujen yhteenlaskettujen avustusten määrä on 80 euroa, joka ylittää vähäiseksi katsottavan määrän, 50 euroa. Näin ollen kyseiset tulot yhteensä 80 euroa huomioidaan Annin laskelmalla tulona siltä osin kuin ne ylittävät 50 euroa eli hänen tulokseen huomioidaan 30 euroa.

Lue lisää Yksityiset tilillepanot, avustukset ja lainat .
