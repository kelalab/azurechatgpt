##### 1.6.8.1.4 Ruokaraha
Jos vankila ei tarjoa vangeille kaikkia päivittäisiä aterioita, eikä hanki asuinosastolla valmistettavien aterioiden raaka-aineita, vangille maksetaan ruokarahaa. Jos vangin mukana vankilan perhe-osastolla on lapsi, häntä varten annetaan lisäksi puolet vangille annettavasta ruokarahasta. Ruokarahaa ei huomioida laskelmassa tulona vangin eikä vangin lapsen osalta.
