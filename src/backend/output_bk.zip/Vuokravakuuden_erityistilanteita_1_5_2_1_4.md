##### 1.5.2.1.4 Vuokravakuuden erityistilanteita
