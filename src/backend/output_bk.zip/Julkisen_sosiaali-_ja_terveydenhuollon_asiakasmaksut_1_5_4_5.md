#### 1.5.4.5 Julkisen sosiaali- ja terveydenhuollon asiakasmaksut
Toimeentulotuessa huomioidaan yleensä vain Suomessa julkisten sosiaali- ja terveydenhuoltopalvelujen käytöstä aiheutuneet menot.
Sosiaali- ja terveydenhuollon asiakasmaksut voivat olla joko tasasuuruisia tai tulosidonnaisia. Tasasuuruisten asiakasmaksujen suuruuteen asiakkaan taloudellisella tilanteella ei ole vaikutusta. Tulosidonnainen maksu määrätään asiakkaan tulojen perusteella.
