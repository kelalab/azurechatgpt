###### 1.5.1.1.5.h Oppilaitosten asuntolat
Oppilaitosten asuntoloiden vuokra- tai asumismaksu huomioidaan asumismenona, jos asumisen osuus on eritelty maksusta. Ruoan, siivouksen ja muiden vastaavien menoerien osuutta ei huomioida menona.
