#### 1.3.6.2 Tulon tarkistaminen maksukuukaudelle 
Jos toimeentulotuki tarkistetaan päätöksenteon jälkeen tulon maksukuukaudelta, tulon todellinen määrä tarkistetaan sen maksukuukaudelle. Tulo voidaan jakaa osiin useammalle etuusjaksolle, jos sitä ei voida pitää kohtuuttomana. Katso myös Tulojen jakaminen osiin . 
 
>ESIMERKKI: Tiialle ja hänen puolisolleen on annettu tammikuulle toimeentulotuen päätös. Tiia ilmoittaa helmikuussa, että heille on syntynyt lapsi tammikuussa. Toimeentulotuki tarkistetaan tammikuun osalta. Samalla huomataan, että Tiian puolisolle on maksettu tammikuussa sairauspäivärahaa 500 euroa, jota ei ole huomioitu tulona. Sairauspäiväraha huomioidaan tarkistuksen yhteydessä tammikuun laskelmalla tulona.  

