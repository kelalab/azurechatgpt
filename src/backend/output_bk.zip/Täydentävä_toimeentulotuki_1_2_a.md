### 1.2.a Täydentävä toimeentulotuki
Hyvinvointialue ottaa täydentävää toimeentulotukea myönnettäessä huomioon tarpeellisen suuruisina henkilön tai perheen erityisistä tarpeista tai olosuhteista johtuvat, toimeentulon turvaamiseksi tai itsenäisen suoriutumisen edistämiseksi tarpeelliseksi harkitut menot.
Henkilön tai perheen erityisenä tarpeena tai olosuhteena voidaan pitää esimerkiksi
 - pitkäaikaista toimeentulotuen saamista,
 - pitkäaikaista tai vaikeaa sairautta sekä
 - lasten harrastustoimintaan liittyviä erityisiä tarpeita.

Täydentävää toimeentulotukea myönnettäessä voidaan ottaa huomioon myös sellaisia menoja, jotka kuuluvat yleensä perustoimeentulotuella katettaviin menoihin, mutta jotka ovat henkilön tai perheen erityisen tilanteen vuoksi niin suuria, ettei perustoimeentulotuki riitä kattamaan niitä. Lue lisää hakemuksen siirtämisestä hyvinvointialueelle .
