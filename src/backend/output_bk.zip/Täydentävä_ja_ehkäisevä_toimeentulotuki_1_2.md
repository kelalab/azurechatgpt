## 1.2 Täydentävä ja ehkäisevä toimeentulotuki
Toimeentulotuki koostuu perustoimeentulotuen lisäksi täydentävästä ja ehkäisevästä toimeentulotuesta. Hyvinvointialue myöntää tarveharkinnan perusteella täydentävää ja ehkäisevää toimeentulotukea. Jos täydentävän tai ehkäisevän toimeentulotuen hakemus saapuu Kelaan, se siirretään hyvinvointialueelle .
