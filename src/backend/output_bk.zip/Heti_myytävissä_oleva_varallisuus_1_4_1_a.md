#### 1.4.1.a Heti myytävissä oleva varallisuus
Heti myytävissä oleva varallisuus on ensisijaisesti käytettävä oman ja perheen elatuksen turvaamiseen jo hakemiskuukauden aikana. Heti myytävissä oleva varallisuus on sellaista omaisuutta, joka on realisoitavissa samana kuukautena. Heti myytävissä olevan varallisuuden arvo huomioidaan toimeentulotuen laskelmalla heti varoina. Tällaista varallisuutta ovat esimerkiksi
 - virtuaalivaluutta,
 - sijoitusrahasto-osuudet,
 - henkilöstörahasto-osuudet,
 - osakkeet,
 - säästövakuutuskertymät ja
 - arvopaperit

Osakkeiden tai sijoitusrahasto-osuuksien, virtuaalivaluutan tai muun vastaavan omaisuuden arvo huomioidaan päätöksenantopäivän arvon mukaisena, jollei muuta ole esitetty. Heti myytävissä olevan varallisuuden arvo voidaan määrittää myös asiakkaan antaman ilmoituksen ja saatujen selvitysten perusteella. Asiakkaan antamia tietoja voidaan verrata esimerkiksi asiakkaan verotustietoihin. Jos omaisuuden arvo ei ole tiedossa, se selvitetään asiakkaalta ennen ratkaisun antamista. Asiakas voi selvittää esimerkiksi osakkeiden ja rahasto-osuuksien määrän ja arvon toimittamalla esimerkiksi verkkopankista tulostetun todistuksen tai sijoitussalkun raportin.
Heti myytävissä oleva varallisuus huomioidaan varoina niin kauan kuin se on asiakkaan ja hänen perheensä käytettävissä. Varallisuudesta voidaan vähentää myynnistä aiheutuneet myyntihetkellä maksettavaksi tulevat kulut, joista asiakkaan tulee esittää selvitys esimerkiksi pankin tosite myyntikuluista.
Lue lisää heti myytävissä olevasta varallisuudesta .
