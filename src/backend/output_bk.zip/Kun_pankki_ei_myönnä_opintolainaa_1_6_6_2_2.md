##### 1.6.6.2.2 Kun pankki ei myönnä opintolainaa
Jos asiakas on saanut valtiontakauksen opintolainaan, mutta hänelle ei myönnetä lainaa pankista, tulee asiakkaan toimittaa toimeentulotukihakemuksen liitteeksi pankin todistus siitä, ettei opintolainaa ole voitu myöntää.
 - Todistus pyydetään siitä pankista, joka on asiakkaan pääasiallinen pankki. Asiakkaalla voi olla tilejä useammissa pankeissa. Opintolaina myönnetään kuitenkin todennäköisimmin siitä pankista, johon asiakkaan tulot tulevat ja mistä päivittäiset raha-asiat hoidetaan.

 - Todistus on vapaamuotoinen ja se voidaan antaa myös sähköisesti.
 - Todistuksessa ei tarvitse olla syytä opintolainan myöntämättä jättämiselle.

Jos opiskelija ei saa opintolainaa pankista, sitä ei huomioida tulona. Mahdollisuudet saada opintolainaa pankista tulee selvittää vuosittain. Jos opiskelijalle on myönnetty valtiontakaus opintolainaan, eikä hän esitä pankin todistusta siitä, ettei opintolainaa ole voitu myöntää, huomioidaan opintolaina laskelmalla tulona.
