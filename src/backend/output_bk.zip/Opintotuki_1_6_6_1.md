#### 1.6.6.1 Opintotuki
Opintotukea voi saada esimerkiksi korkeakouluopintoihin, lukio-opintoihin, ammatilliseen koulutukseen sekä aikuisten perusopetukseen. Jos opiskelija hakee toimeentulotukea, häntä tulee ohjata hakemaan myös opintotukea sekä yleistä asumistukea.
Opintotukeen kuuluvat:
 - opintoraha, mukaan lukien opintorahan huoltajakorotus ja oppimateriaalilisä

 - opintolaina ja
 - asumislisä, jota maksetaan: ulkomailla tai Ahvenanmaalla opiskelevilla ja asuvilla sekä kansanopiston tai urheiluopiston maksullisilla linjoilla opiskelevilla, jotka asuvat opiston asuntolassa

Opintotuen myöntämisen yleisiä edellytyksiä ovat:
 - oppilaitokseen hyväksyminen,
 - päätoiminen opiskelu,
 - opinnoissa edistyminen ja
 - taloudellisen tuen tarve.

Opintotuen myöntämisehdot vaihtelevat suoritettavien opintojen mukaan. Katso tarkemmat myöntämisehdot opintotuen ohjeesta .
Ennen ensimmäisen toimeentulotukipäätöksen antamista tulee tarkistaa seuraavat asiat:
 - onko opintotukea haettu jos opintotukea ei ole myönnetty, tulee opintotukipäätöksestä katsoa opintotuen hylkäämisen tai päättymisen syy sekä miten asiakas voi saada opintotuen takaisin maksuun jos asiakas ei ole hakenut opintotukea, ohjataan häntä hakemaan opintotukea

 - kuinka paljon opintotukikuukausia on jäljellä jos opintotukikuukausia on vain muutama jäljellä, asiakkaalta selvitetään ehtiikö hän suorittaa opintonsa loppuun niiden aikana

 - onko opintolainan valtiontakaus myönnetty korkeakouluopiskelijoille takaus myönnetään automaattisesti

 - onko opintolaina nostettu
 - opintorahan maksukuukaudet

Jos opiskelija palauttaa hänelle jo maksetun opintotuen, on opintotuki kuitenkin ollut hänen käytettävissään sen maksukuukautena eikä maksukuukauden laskelmaa tästä syystä tarkisteta.
