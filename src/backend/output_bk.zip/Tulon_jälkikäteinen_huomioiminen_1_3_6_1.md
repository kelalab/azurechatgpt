#### 1.3.6.1 Tulon jälkikäteinen huomioiminen 
Jos tulo ei ole ollut tiedossa kokonaan tai osittain toimeentulotuesta päätettäessä, se voidaan ottaa jälkikäteen tulona huomioon, jos toimeentulotukea haetaan päätöstä seuraavien kahden ensimmäisen kalenterikuukauden aikana. Hakijalle kerrotaan tästä mahdollisuudesta toimeentulotuen päätöksessä. Tulo voidaan huomioida jälkikäteen tulona, jollei sitä voida pitää kohtuuttomana. Samalla arvioidaan myös tulon käytettävyyttä. Tarkoitus ei kuitenkaan ole mahdollistaa sitä, että hakija voisi tarkoituksellisesti kuluttaa mahdolliset tulonsa haluamallaan tavalla. 
 
Jos hakija luotettavasti esittää käyttäneensä tulon osittain tai kokonaan toimeentulotuessa hyväksyttäviin tarkoituksiin, ei tuloa siltä osin huomioida toimeentulotuen tulona. 
Kun harkitaan tulon huomioimista jälkikäteen, otetaan huomioon esimerkiksi seuraavia asioita: 
 - Milloin tulo on maksettu?  
 - Mikä on tulon määrä? 
 - Onko hakija käyttänyt tai aikooko hän käyttää kohtuullisessa ajassa tulon toimeentulotuessa hyväksyttäviin tarkoituksiin? 
 - Millaiset ovat hakijan tai perheen yksilölliset olosuhteet? 
 - Vaikuttaako hakijan tai perheen sosiaaliseen tilanteeseen muita tekijöitä? 

 
>ESIMERKKI: Kaijalla on säännöllinen palkka 800 euroa kuukaudessa. Kaijalle on tehty maalis- ja huhtikuulle toimeentulotukipäätökset ja laskelmalla on huomioitu 800 euroa ansiotuloa kuukausittain. Kaijan hakiessa toimeentulotukea toukokuulle huomataan, että ylitöiden vuoksi hänen palkkansa olikin maaliskuussa 1 000 euroa. Koska muita tarkistamisperusteita maaliskuun päätöksen osalta ei ole, toukokuun laskelmassa huomioidaan muiden tulojen lisäksi ansiotuloja jälkikäteen maaliskuulta 200 euroa. Kaija ei ole esittänyt käyttäneensä ansiotuloa toimeentulotuessa hyväksyttävään tarkoitukseen eikä ole käynyt ilmi muitakaan seikkoja, joiden perusteella ansiotulon huomioon ottamista voitaisiin pitää kohtuuttomana.  

Jälkikäteen huomioitava tulo on mahdollista vyöryttää tai jaksottaa useammalle etuusjaksolle, jos sitä ei voida pitää kohtuuttomana. Lue lisää Tulojen jakaminen osiin . 
Jos toimeentulotuki tarkistetaan tulon maksukuukaudelta, huomioidaan tarkistamisen yhteydessä tulo sen maksukuukaudelle. Lue lisää tulon tarkistaminen maksukuukaudelle . 
Jos hakija ei ole hakenut toimeentulotukea tulon maksukuukautena, ei tuloa voida ottaa jälkikäteen huomioon seuraavien kuukausien toimeentulotukioikeutta laskettaessa. Tällaisesta tulosta kertyneet käytettävissä olevat varat huomioidaan kuitenkin varallisuutena. 
Lue lisää asiakkaan varautumisvelvollisuudesta . 
