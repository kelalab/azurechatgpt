##### 1.5.5.1.d 4. Paperinen maksusitoumus
Joissain tilanteissa lääkemaksusitoumus annetaan asiakkaalle paperisena.
Esimerkiksi
 - lääkkeellistä happea varten. Lue lisää lääkkeellisen hapen prosessista .
 - asiakkaille, joilla ei ole suomalaista henkilötunnusta. Lue lisää tilapäisesti oleskeleva henkilö –prosessista .

