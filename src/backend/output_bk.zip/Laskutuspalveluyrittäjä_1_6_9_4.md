#### 1.6.9.4 Laskutuspalveluyrittäjä
Laskutuspalveluyrittäjällä tarkoitetaan henkilöä, joka toimii laskutuspalvelun kautta työllistäen itse itsensä ilman, että on perustanut yrityksen. Laskutuspalveluyrittäjä käyttää yritystoiminnassaan laskutuspalvelua, joka lähettää laskun asiakkaalle ja maksaa laskutuspalveluyrittäjälle tämän tulon palkkana. Laskutuspalveluyrittäjyys ei ole virallinen yritysmuoto, mutta laskutuspalveluyrittäjää pidetään toimeentulotuen näkökulmasta yrittäjänä. Laskutuspalveluyrittäjä voi itse valita nostaako hän palkkaa laskutuspalvelusta vai kerryttääkö tuloa laskutuspalveluun. Laskutuspalveluyrittäjän nostamasta palkasta pidätetään verot, laskutuspalvelun palkkio sekä erilaisia maksuja. Laskutuspalveluyrittäjä ei ole toiminnastaan kirjanpitovelvollinen.
Laskutuspalveluyrittäjän yritystoiminnastaan saamat tulot verotetaan hänen henkilökohtaisena ansiotulonaan. Laskutuspalvelusta nostetut palkat näkyvät yleensä myös tulorekisterissä. Laskutuspalveluyrittäjän on kuitenkin toimitettava hakemuksensa liitteeksi myös kuukausittainen laskutuspalvelun maksulaskelma, jotta nähdään hänen kaikki yritystoiminnastaan saatavissa olevat tulot. Tuloksi huomioidaan nostettujen palkkojen lisäksi laskutuspalvelussa olevat rahat, jotka hän voisi nostaa palkkana. Näistä tuloista on kuitenkin vähennettävä ensin niihin kohdistuvat menot, esimerkiksi verokortin mukainen ennakonpidätys, työnantajamaksuja, sairausvakuutusmaksuja sekä laskutuspalvelun oma palkkio-osuus. Jos riittävää tietoa vähennyksien tekemiseen ei saada, viedään koko laskutuspalvelussa oleva rahamäärä tuloksi laskelmalle.
Laskutuspalveluyrittäjän tuloa voi esimerkiksi olla:
 - starttiraha
 - palkat
 - työkorvaukset
 - laskutuspalvelusta nostettavissa olevat tulot

Laskutuspalvelusta voi nostaa tuloa palkan lisäksi kulukorvauksena. Kulukorvaus on esimerkiksi korvaus laskutuspalveluyrittäjän työsuoritusta varten tekemistä materiaalihankinnoista. Kulukorvausta ei huomioida asiakkaan tulona siltä osin, kuin hänellä on esittää korvausta vastaavien menojen kuitit.
Laskutuspalveluyrittäjä katsotaan työttömyysturvan osalta yrittäjäksi, eli hänen oikeutensa työttömyysturvaan arvioidaan samoin kuin muidenkin yrittäjien kohdalla. Laskutuspalveluyrittäjä voi siis saada ensisijaiset etuudet estävän työvoimapoliittisen lausunnon yritystoimintansa perusteella ja siten hänen yritystoimintansa kannattavuus arvioidaan samoin kuin muidenkin yrittäjien kohdalla.
Laskutuspalveluyrittäjältä voidaan pyytää esimerkiksi seuraavat selvitykset tulojen ja varojen selvittämiseksi:
 - TO4-lomake
 - yrittäjän tiliotteet
 - tositteet laskutuspalvelusta nostamattomista tuloista
 - laskutuspalvelun maksulaskelma palkoista ja muista tuloista

