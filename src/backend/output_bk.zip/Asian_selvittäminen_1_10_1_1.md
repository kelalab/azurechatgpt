#### 1.10.1.1 Asian selvittäminen
Asiakkaalta on tarvittaessa pyydettävä lisäselvityksiä esimerkiksi seuraavissa tilanteissa:
 - erilleen tai yhteen muutto,
 - epäselvyys siitä, onko kyse avoliitosta tai yhteistaloudesta,
 - kun hakijan ilmoittamat tulot/varat poikkeavat olennaisesti Kelan tiedossa olevista,
 - kun tiliotteelta ilmenevien tulojen peruste on epäselvä tai
 - aina kun hakijan olosuhteet eivät ole tarkistushakemusta tehtäessä riittävän hyvin selvillä.

