### 1.8.4 Maksaminen muille maksunsaajille
Yleensä perustoimeentulotuki maksetaan hakijan osoittamalle tilille. Perustoimeentulotuki voidaan tietyissä tilanteissa maksaa myös muille maksunsaajille.
