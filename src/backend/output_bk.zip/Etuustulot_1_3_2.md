### 1.3.2 Etuustulot
Etuustulot ovat toimeentulotuessa huomioitavia tuloja. Laskelmalla huomioidaan yksi saman etuuden maksuerä kuukaudessa maksupäivästä riippumatta, jos etuus on säännöllinen kuukausittain maksettava etuus esimerkiksi työttömyysetuus tai sairauspäiväraha.
Etuustuloiksi huomioidaan muun muassa
 - työmarkkinatuki ja peruspäiväraha
 - ansiosidonnainen työttömyyspäiväraha
 - yleinen asumistuki
 - eläkkeensaajan asumistuki
 - opintoraha, asumislisä ja opintolaina
 - vanhempainpäivärahat
 - lapsilisä
 - lasten kotihoidontuki
 - elatustuki
 - sairausvakuutuslain ja muiden lakien mukainen päiväraha
 - Kelan maksamat eläkkeet
 - eläketuki
 - työeläkkeet
 - ulkomaan eläkkeet
 - vuorotteluvapaakorvaus
 - liikkuvuusavustus siltä osin kuin sitä ei hakijan selvityksen mukaan ole käytetty työssäkäynnin matkustuskustannuksiin tai muuttokustannuksiin
 - työpaikkakassojen maksamat etuudet
 - aikuiskoulutustuki 
 - väliaikainen sähkötuki

 
Jos kyseessä on alkava etuus, katso myös osakuukauden ratkaisu . 
 
Jos etuustulo ei ole ollut tiedossa toimeentulotuesta päätettäessä, katso tulon jälkikäteinen huomioiminen .
