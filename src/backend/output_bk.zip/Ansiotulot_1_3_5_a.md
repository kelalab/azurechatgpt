#### 1.3.5.a Ansiotulot
Ansiotulosta jätetään huomioimatta
 - henkilökohtainen ansiotulovähennys, joka on enintään 150 euroa kuukaudessa
 - kohtuulliset kilometrikorvaukset tai päivärahat, työkalukorvaukset tai muut vastaavat tulot.

