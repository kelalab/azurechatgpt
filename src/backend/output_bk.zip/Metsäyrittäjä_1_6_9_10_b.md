##### 1.6.9.10.b Metsäyrittäjä
Metsätaloutta voidaan harjoittaa eri yritysmuodoissa eikä pelkkä metsän omistaminen tee asiakkaasta yrittäjää toimeentulotuen näkökulmasta. Jos asiakasta ei voida pitää päätoimisena yrittäjänä, mutta hän omistaa metsää, tulee metsän arvo ja realisointi sekä takaisinperinnän edellytykset selvittää. Lue lisää takaisinperinnästä .
Jos asiakas omistaa metsää ja hänellä on MYEL-vakuutus tämän toiminnan vuoksi, pidetään asiakasta yleensä yrittäjänä toimeentulotuen näkökulmasta. Lisäksi kyseessä on yrittäjä, jos asiakkaalla on estävä työvoimapoliittinen lausunto metsätoiminnan vuoksi. Jos asiakkaalla ei ole työvoimapoliittista lausuntoa eikä MYEL-vakuutusta, on selvitettävä, työskenteleekö asiakas metsätilalla vai ei. Jos on epäselvää, estääkö asiakkaan metsätoiminta ensisijaiset toimeentuloa turvaavat etuudet, tulee asiakasta ohjata työ-ja elinkeinopalveluihin selvittämään asiaa.
Yksityinen elinkeinonharjoittaja tai metsäyhtymä ei ole metsätaloustoiminnasta kirjanpitovelvollinen. Heidän on kuitenkin pidettävä toiminnastaan muistiinpanoja. Metsäyhtymän toiminnasta on tehtävä yksi yhteinen metsätalouden veroilmoitus ja arvonlisäveroilmoitus. Metsäyhtymä ei ole itsenäinen verovelvollinen, vaan sen tulos verotetaan osakkaiden henkilökohtaisessa verotuksessa. Lue lisää yhtymistä ja yksityisestä elinkeinonharjoittajasta.
Metsätaloustoiminnan tuloa voi olla esimerkiksi:
 - puunmyyntitulot,
 - maa-ainestulot,
 - korvaukset metsälle aiheutuneista vahingoista sekä
 - valtion tuet erilaisiin metsänhoitotöihin, metsäteihin ja metsäluonnonhoitoon.

Yrittäjältä tulee selvittää, paljonko hän saa yritykselle tuloa erilaisista tuista ja milloin tuet maksetaan. Harkittaessa miltä osin tuet sekä muut metsätoiminnasta saadut tulot ovat käytettävissä yrittäjän omaan elatukseen, tulee selvittää mitä yritystoiminnan menoja niillä on katettu tai aiotaan kattaa.
