### 1.4.1 Heti käytettävissä oleva varallisuus
Ennen kuin asiakas tai hänen perheensä turvautuu toimeentulotukeen, hänen tai heidän on ensisijaisesti turvattava toimeentulonsa käytettävissä olevilla varoillaan ja näin ollen käytettävä säästöjään elinkustannustensa kattamiseen. Tällaisia säästöjä ovat esimerkiksi
 - käteinen raha,
 - pankkitileillä olevat talletukset ja säästöt,
 - arvo-osuustilien säästöt,
 - pelitilillä olevat varat sekä
 - asuntosäästöpalkkiotilillä (ASP-tilillä) olevat säästöt.

Säästöt huomioidaan laskelmalla varoina niin kauan kuin säästöt ovat asiakkaan ja hänen perheensä käytettävissä. Tileillä olevan varallisuuden määrä selvitetään toimitetuista tiliotteista. Jos on perusteltua syytä epäillä, että saadut tiedot eivät ole luotettavia, voidaan tehdä rahalaitostiedustelu pankkiin. Lue lisää rahalaitostiedustelusta .
Pääsääntönä on, että tulot muuttuvat käytettävissä olevaksi varallisuudeksi tulon maksukuukauden jälkeen. Sillä seikalla, mistä tuloista varat ovat kertyneet, ei ole yleensä merkitystä. Poikkeuksen tästä muodostaa tietyissä tilanteissa etuoikeutetusta tulosta kertynyt säästö:
 - Etuoikeutettua tuloa ovat tulot, joita ei huomioida toimeentulotuen laskelmalla niiden maksukuukautena. Myös etuoikeutetusta tulosta säästetyt varat voidaan huomioida niiden maksua seuraavina kuukausina laskelmalla varoina, ellei asiakas osoita niiden olevan säästetty etuoikeutetusta tulosta tiettyä etuoikeutetun tulon maksuperusteena olevaa tarkoitusta varten. Tarvittaessa asiakkaalta pyydetään tarkempi selvitys säästetystä varallisuudesta ja sen aiotusta käyttökohteesta. Katso myös Tulot joita ei huomioida .

>ESIMERKKI: Millalle on maksettu 16 vuotta täyttäneen vammaistuki maaliskuussa. Vammaistukea ei huomioida tulona maaliskuun laskelmassa. Huhtikuussa Millan tilille on kuitenkin jäänyt säästöön edellisten kuukausien vammaistuista 1500 euroa, joka voidaan huomioida huhtikuun laskelmalla varoina.

Tilivarat ovat omaan elatukseen käytettävissä olevaa omaisuutta ja ne huomioidaan laskelmalla varoina. Yleensä kuitenkaan vähäistä, tavanomaiseen elämään tarvittavaa, käyttötilillä olevaa tilivaraa ei huomioida käytettävissä olevana varallisuutena. Tiliotteilla näkyvistä tilivaroista harkitaan aina tapauskohtaisesti varoina huomioitava osuus. Harkinnassa otetaan huomioon esimerkiksi seuraavia seikkoja:
 - hakemuksen saapumisajankohta,
 - tilitietojen ajantasaisuus, Esimerkiksi 30.11. tilin saldoa ei voida huomioida suoraan tammikuun laskelmalla varoina, vaan tulee arvioida, onko asiakkaalla varoja käytettävissä vielä tammikuussa. Sen sijaan 31.12. tilin saldo on yleensä huomioitavissa kokonaisuudessaan tammikuun laskelmalla varoina. Jos asiakkaalle huomioidaan laskelmalla viimeisenä pankkipäivänä maksettu tulo, ei samaa tuloa voi huomioida myös varoina samana kuukautena.
 - asiakkaalle maksettavat tulot ja niiden maksuajankohta,
 - asiakkaan itsensä vastattavaksi jäävät muut perusmenot,
 - perhekoko ja
 - muut tapauskohtaisesti arvioitavat seikat

Jos asiakas maksaa itse vuokransa ja muut perusmenonsa, tilillä saattaa olla varoja esimerkiksi vuokranmaksun tai muun perustoimeentulotuessa huomioitavan menon vuoksi. Jos taloudellinen tilanne pysyy kuukausittain suurin piirtein samana, eikä asiakkaalle kerry hyväksyttävien menojen jälkeen vähäistä tavanomaiseen elämään tarvittavaa säästöä suurempaa tilivaraa, ei tilivaraa huomioida varoina käsiteltävän kuukauden laskelmassa.
Lue lisää heti käytettävissä olevasta varallisuudesta .
