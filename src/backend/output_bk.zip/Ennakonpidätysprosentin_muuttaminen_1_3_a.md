### 1.3.a Ennakonpidätysprosentin muuttaminen
Jos hakijan tulot alenevat pitkäaikaisesti tai hakijan etuustulosta pidätetään yli 25 % veroa, ohjataan hakijaa tarkistamaan ennakonpidätysprosentti Verohallinnolta. Tuloja vastaava ennakonpidätys varmistaa sen, että toimeentulotuki maksetaan oikeansuuruisena. Ennakonpidätys on syytä tarkistaa esimerkiksi silloin, kun hakija jää työttömäksi ja tulot muuttuvat olennaisesti.

