#### 1.7.1.d Puutteellinen hakemus
Asia tulee vireille myös puutteellisella hakemuksella. Puutteellista hakemusta ei palauteta asiakkaalle vaan asiakasta pyydetään täydentämään sitä määräajassa. Hakemuksen täydentämistä pyydetään puhelimitse, OmaKelan viestillä tai kirjeellä.
Asiakasta neuvotaan, miten asiakirjaa on täydennettävä. Tarvittaessa asiakkaalle selvitetään myös suullisesti, miten asiakirjaa on täydennettävä. Asiakas voi myös omasta aloitteestaan täydentää hakemustaan tai muita asiakirjoja.
Kun toimeentulotukea haetaan esimerkiksi paperisella hakemuksella ilman allekirjoitusta esimerkiksi postitse, siihen ei tarvitse pyytää allekirjoitusta, ellei ole syytä epäillä hakemuksen alkuperäisyyttä tai eheyttä eikä esimerkiksi sitä, että hakemus olisi asiakkaan tahdon vastainen.
Usein puutteellisen hakemuksen yhteydessä on tarpeen pyytää asiakasta toimittamaan myös lisäselvityksiä. Asiakasta pyydetään täydentämään hakemusta ja toimittamaan tarvittavat lisätiedot mahdollisuuksien mukaan samalla kertaa. Perustoimeentulotuen osalta on lakiin perustuvat ehdottomat määräajat lisäselvityksen pyytämiselle ja ratkaisemiselle.
Lue lisää käsittelyajasta ja lisäselvityksistä .
