##### 1.5.2.1.1 Mitä vuokravakuus kattaa
Vuokralainen vastaa vuokranmaksusta itse vuokrasuhteen voimassaoloaikana. Vuokravakuutta ei voi käyttää vuokran maksamiseen, kun vuokrasuhde on voimassa. Vuokralainen ei voi sopia vuokranantajan kanssa, että Kelan vakuutta käytettäisiin viimeisen vuokran maksuun.
Vuokravakuudesta voidaan korvata
 - maksamattomat vuokrat
 - maksamattomat vesi-, autopaikka- ja saunamaksut, jos maksut on mainittu vuokrasopimuksessa
 - sopimussakko, jos vuokralainen on irtisanonut määräaikaisen vuokrasopimuksen ennen määräaikaa tai irtisanonut toistaiseksi voimassa olevan vuokrasopimuksen ennen vuokrasopimuksessa sovittua ensimmäistä mahdollista irtisanomisajankohtaa
 - vahingonkorvaus, joka maksetaan vuokrasopimuksen purkamisen vuoksi
 - vahingot, jotka vuokralainen tai huoneistossa vuokralaisen luvalla oleskellut henkilö on tahallaan tai huolimattomuudellaan aiheuttanut huoneistolle, pois lukien huoneiston tavanomainen kuluminen
 - ylimääräiset loppusiivouskulut, jos vuokralainen on olennaisesti laiminlyönyt huoneiston siivouksen tai ei ole vienyt tavaroitaan pois
 - lukkojen sarjoitus, jos vuokralainen ei palauta kaikkia hänelle vuokrasuhteen aikana luovutettuja avaimia
 - häädöstä aiheutuvat viranomaiskulut kuten oikeudenkäyntimaksu, häädön täytäntöönpanomaksu ulosotossa

Vuokravakuudesta ei korvata
 - vuokranantajan välillisiä kuluja, kuten matkakuluja
 - asuntoirtaimistolle aiheutuneita vahinkoja
 - tupakoinnista aiheutuneita haittoja, jos tupakointia ei ole vuokrasopimuksessa erikseen kielletty
 - taloyhtiölle tai muulle kolmannelle osapuolelle aiheutuneita vahinkoja

