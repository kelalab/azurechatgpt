#### 1.3.3.2 Kilometrikorvaukset, päivärahat ja kulukorvaukset
Kohtuullisia kilometrikorvauksia ja päivärahoja, työkalukorvauksia tai muita vastaavia kulukorvauksia ei huomioida yleensä tuloina. Jos työnantaja maksaa syntyneistä kustannuksista korvauksia, ei kustannuksia myöskään vähennetä huomioitavasta ansiotulosta. Korvausten kohtuullisuutta arvioidaan suhteessa ansiotulon määrään.
>ESIMERKKI: Arto on saanut palkkaa 600 euroa, kilometrikorvauksia 40 euroa ja työkalukorvausta 15,50 euroa. Laskelmalla huomioidaan 600 euron palkka ansiotulona, mutta kilometrikorvausta ja työkalukorvausta ei huomioida tuloina.

>ESIMERKKI: Kalle on saanut palkkaa 450 euroa ja kilometrikorvauksia 40 euroa. Hän ilmoittaa menoinaan työmatkakustannuksia 30 euroa samoista matkoista, joilta hänelle on maksettu kilometrikorvausta. Laskelmalla huomioidaan saatu palkka 450 euroa tulona, mutta kilometrikorvausta ei huomioida tulona eikä työmatkakustannuksia menona. 

Lue lisää kilometrikorvauksista ja päivärahoista .
