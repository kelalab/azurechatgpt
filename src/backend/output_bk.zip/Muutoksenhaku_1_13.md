## 1.13 Muutoksenhaku
Asiakas voi hakea muutosta perustoimeentulotukipäätökseen tekemällä oikaisuvaatimuksen. Toimeentulotuen oikaisuvaatimukset käsitellään Kelan toimeentulotuen oikaisuvaatimuskeskuksessa.
Lisäksi oikaisuvaatimuskeskus:
 - antaa lausunnot hallinto-oikeuksille Oikaisuvaatimuskeskuksen ratkaisuja koskevista valituksista
 - panee täytäntöön hallinto-oikeuksien perustoimeentulotukea koskevat päätökset
 - hoitaa yhteydenpidon hallinto-oikeuksiin muutoksenhaun alaisissa asioissa

Oikaisuvaatimuskeskuksen antamasta päätöksestä voi valittaa hallinto-oikeuteen. Hallinto-oikeuden antamasta päätöksestä voi edelleen valittaa korkeimpaan hallinto-oikeuteen, jos korkein hallinto-oikeus antaa siihen valitusluvan.
Hyvinvointialueen tekemään täydentävän tai ehkäisevän toimeentulotuen päätökseen voi vaatia oikaisua hyvinvointialueelta. Lautakunnan päätöksestä voi valittaa edelleen hallinto-oikeuteen ja joissain tapauksissa korkeimpaan hallinto-oikeuteen.
