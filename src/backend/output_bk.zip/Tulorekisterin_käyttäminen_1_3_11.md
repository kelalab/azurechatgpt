### 1.3.11 Tulorekisterin käyttäminen
Tulorekisterissä on tiedot Suomessa maksetuista ansiotuloista sekä laitosten maksamista etuus- ja muista tuloista.
Tulotiedot katsotaan tulorekisteristä aina, kun hakijalle annetaan päätös ja hakijalla tai hänen perheenjäsenellään on palkkatuloja ja/tai etuustuloja. Tulorekisteristä saadaan tieto muiden laitosten maksamista etuustuloista.
Käsittelyjärjestelmä antaa impulssin mennä tulorekisteriin tarkistamaan tiedot, jos
 - hakijalla tai hänen perheenjäsenellään on palkkatietoja tai muun laitoksen maksamia etuustuloja ratkaistavalla ajalla tai ratkaistavaa aikaa edeltäviltä 3 kuukaudelta.

Tulorekisteritietoa käytetään, kuten palkkalaskelmaa tai etuuden maksuilmoitusta.
Asiakkaalta pyydetään selvityksiä palkka- tai etuustuloihin liittyen vain, jos
 - tietoja ei saada tulorekisteristä,
 - tulorekisteristä saatavia tietoja tulee tarkentaa,
 - tiedot olennaisesti poikkeavat asiakkaan ilmoittamasta tai
 - epäillään rekisteritietoa virheelliseksi.

Asiakkaalle on kerrottu hakemuksessa ja Kela.fi:ssä, että Kela hyödyntää tulorekisteristä saatavia palkka- ja etuustulotietoja.
