##### 1.1.2.2.c Ohjaus hakea elatustukea
Asiakasta ohjataan hakemaan elatustukea lapselle, jos:
 - vahvistetun elatussopimuksen tai tuomioistuimen päätöksen mukaan vanhemmalla ei ole elatuskykyä lainkaan,
 - elatussopimuksessa vahvistetun tai tuomioistuimen päätöksessä määrätyn elatusavun määrä on elatusvelvollisen puutteellisen elatuskyvyn vuoksi pienempi kuin Kelan maksaman elatustuen määrä (186,97 e/kk vuonna 2023),
 - elatusvelvollinen vanhempi laiminlyö vahvistetun elatusavun maksamisen tai
 - lapsella on vain yksi vanhempi.

