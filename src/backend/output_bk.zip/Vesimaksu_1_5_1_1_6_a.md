###### 1.5.1.1.6.a Vesimaksu
Vesimaksu voidaan huomioida menona. Vesimaksu voidaan laskuttaa joko ennakkoon tai tasauslaskulla.
Lue lisää vesimaksun kohtuullisuuden arvioimisesta .
