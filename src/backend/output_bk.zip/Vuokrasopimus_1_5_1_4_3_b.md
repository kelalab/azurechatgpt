###### 1.5.1.4.3.b Vuokrasopimus
Ennen kuin hakijaa ohjataan hakemaan edullisempaa asuntoa, tarkistetaan nykyisen asunnon vuokrasopimus.
Vuokrasopimuksen määräaikaisuus ja ensimmäinen mahdollinen irtisanomisaika on otettava huomioon, kun harkitaan muuttokehotuksen antamista. Jos vuokrasopimus irtisanotaan ennen ensimmäistä mahdollista irtisanomisaikaa asiakas voi joutua maksamaan sopimussakon tai vahingonkorvausta vuokranantajalle.
Harkinnassa on otettava huomioon:
 - asiakkaalle aiheutuvat kustannukset,
 - ylityksen suuruus ja
 - jäljellä oleva vuokra-aika.

Jos asiakas tekee jatkosopimuksen kohtuullisen tason ylittävään asuntoon ja hänelle on annettu kehotus hakeutua halvempaan asuntoon, kohtuullistetaan vuokra jatkosopimuksen alkaessa.
