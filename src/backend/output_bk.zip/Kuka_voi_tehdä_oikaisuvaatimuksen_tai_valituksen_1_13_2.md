### 1.13.2 Kuka voi tehdä oikaisuvaatimuksen tai valituksen?
Päätöksestä voi valittaa asianosainen. Asianosaisia ovat etuuden hakija ja muut, joihin päätös kohdistuu. Toimeentulotuki on perhekohtainen etuus. Perheen puolesta oikaisuvaatimuksen ja valituksen voi tehdä kuka hyvänsä perheen täysivaltaisista jäsenistä. Lue lisää perhekäsitteestä .
Myös edunvalvoja, edunvalvontavaltuutettu tai muu laillinen edustaja voi hakea muutosta asiakkaan puolesta. Jos oikaisuvaatimuksen laatijana on hakijan asiamies, on mukana oltava valtakirja. Lue lisää asianosaisasemasta ja puhevallasta .
