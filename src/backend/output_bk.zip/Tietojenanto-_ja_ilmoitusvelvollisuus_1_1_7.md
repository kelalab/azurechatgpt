### 1.1.7 Tietojenanto- ja ilmoitusvelvollisuus
Asiakkaalla on toimeentulotuen myöntämiseksi velvollisuus antaa Kelalle kaikki tiedossaan olevat toimeentulotukeen vaikuttavat välttämättömät tiedot. Lisäksi asiakas on velvollinen välittömästi ilmoittamaan Kelalle edellä mainituissa tiedoissa tapahtuneista muutoksista.
Tietojenanto- ja ilmoitusvelvollisuus on asiakkaan lisäksi:
 - asiakkaan perheenjäsenellä
 - asiakkaan ja hänen perheenjäsenensä elatusvelvollisella
 - tarvittaessa asiakkaan ja hänen perheenjäsenensä huoltajalla ja edunvalvojalla

Ilmoitusvelvollisuuden piiriin kuuluvat esimerkiksi seuraavat tiedot:
 - perheeseen kuuluvat henkilöt
 - asiakkaan ja perheenjäsenen elatusvelvolliset
 - asiakkaan ja perheenjäsenen käytettävissä olevat tulot
 - asiakkaan ja perheenjäsenen käytettävissä olevat varat
 - asiakkaan ja perheenjäsenen menot
 - asiakkaan ja perheenjäsenen vireillä olevat etuudet
 - asumiseen liittyvät tiedot
 - 17–64 -vuotiaan asiakkaan ja perheenjäsenen työnhakijana olo
 - avioliiton solmiminen tai avioero
 - avoliittoon muuttaminen ja avoliiton päättyminen
 - ulkomailla oleskelu
 - vankilassa olo
 - asevelvollisuuden suorittaminen
 - laitoshoito ja avohuollon asumispalvelu

Asiakkaan voidaan myös edellyttää asioivan henkilökohtaisesti Kelassa, jos se on asian selvittämiseksi ja toimeentulotuen määräämiseksi välttämätöntä.
Jos toimeentulotukihakemuksessa ei ole annettu välttämättömiä tietoja hakemuksen ratkaisemiseksi, pyydetään asiakasta ensin toimittamaan puuttuvat tiedot hakemuksen liitteeksi. Jos tietoja ei pyynnöstä huolimatta toimiteta, voidaan hakemus hylätä puutteellisten tietojen vuoksi.
Jos toimeentulotukea on jo myönnetty ja on perusteltu syy epäillä asiakkaan tai muun ilmoitusvelvollisen henkilön antamien tietojen riittävyyttä tai luotettavuutta, pyydetään asiakkaalta lisäselvitystä tietojen riittämättömyyden tai saatujen tietojen ristiriitaisuuden vuoksi. Asiakasta voidaan samalla kuulla tarvittaessa myös rahalaitostiedustelun tekemisestä. Toimeentulotuen päätöksiä voidaan tarkistaa ilmoitusvelvollisen antamien virheellisten tai puutteellisten tietojen perusteella. Lue lisää tarkistamisesta .
Jos ilmoitusvelvollinen tahallaan antaa erehdyttäviä tietoja tai tahallaan laiminlyö ilmoitusvelvollisuutensa, voidaan tästä syystä liikaa maksettu toimeentulotuki periä takaisin . Jos kyseessä on väärinkäytös, peritään aiheettomasti maksettu tuki yleensä takaisin vahingonkorvauksena rikosprosessin yhteydessä. Jos rikosprosessiin ei kuitenkaan ryhdytä tai liikaa maksettua tukea ei muusta syystä saada vahingonkorvauksena takaisin, voidaan takaisinperintää hakea hallinto-oikeudelta. Lue lisää väärinkäytösepäilyn selvittämisen prosessista.
