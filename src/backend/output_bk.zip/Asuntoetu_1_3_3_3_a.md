##### 1.3.3.3.a Asuntoetu
Asuntoetu huomioidaan ansiotulona. Kun asuntoetu huomioidaan tuloksi, viedään menoksi asunnon kokonaisvuokra. Jos kokonaisvuokra ylittää Kelan määrittelemät kohtuulliset asumismenot, katso kohdasta asumismenot ylittävät Kelan asumisnormin , miten toimitaan. Jos asumismenot kohtuullistetaan, menona huomioidaan paikkakunnan kohtuullista tasoa vastaava vuokran määrä ja tulona huomioidaan edelleen asuntoetu.
Hakijaa voidaan ohjata selvittämään työnantajalta mahdollisuutta vaihtaa asuntoetu rahapalkkaan.
>ESIMERKKI: Millan asuntoedun arvo on 500 e ja asunnon vuokra 500 e. Milla ei siis maksa itse asumisestaan lainkaan, vaan työnantaja maksaa palkkana koko asunnon vuokran. Asunnon vuokra on Kelan kohtuullisen tason mukainen. Toimeentulotuen laskelmalle viedään ansiotuloksi asuntoetu 500 e ja menoksi vuokra 500 e.

>ESIMERKKI: Railin asuntoedun arvo on 130 e. Asunnon kokonaisvuokra on 930 e, josta Raili maksaa itse 800 e. Kelan asumisnormi paikkakunnalla on 600 e. Railin laskelmalle viedään ansiotuloksi 130 e ja vuokramenoksi 930 e. Railille annetaan määräaika etsiä edullisempi asunto. Määräajan jälkeen perustoimeentulotuessa hyväksyttävä vuokra voidaan kohtuullistaa 600 euroon, jos Raili ei ole hakenut edullisempaa asuntoa tai esittänyt erityisiä perusteita korkeammille asumiskustannuksille.

