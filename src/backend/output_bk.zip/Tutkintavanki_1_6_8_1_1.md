##### 1.6.8.1.1 Tutkintavanki
Tutkintavangilla ei ole velvollisuutta tehdä työtä tai osallistua toimintaan. Käyttörahaa maksetaan myös tutkintavangeille. Jos tutkintavanki tekee työtä tai osallistuu toimintaan, hänelle maksetaan toimintarahaa kuten vankeusvangeille.
