#### 1.11.1.1 Päätöksen korjaaminen asiakkaan eduksi
Päätöksen korjaaminen asiakkaan eduksi tehdään ilman asiakkaan kuulemista tai suostumusta heti, kun virhe huomataan. Asiakkaan päätöksessä ollut virhe korjataan vastaamaan todellista tilannetta ja päätöksen perusteluissa kerrotaan, miksi asia on käsitelty uudelleen.
