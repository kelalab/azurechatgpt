#### 1.7.2.6 Kuolinpesä
Yksinäisen henkilön kuolinpesän puolesta hakemuksen voi tehdä
 - kuolinpesän hoitaja
 - tai sosiaalitoimen työntekijä
 - pesänselvittäjä
 - Yhteishallinnossa pesän osakas muiden valtuuttamana.

Aviopuolisonsa kanssa yhdessä asuneen tai avoliitossa olleen henkilön kuolinpesän puolesta hakemuksen voi tehdä edellä mainittujen lisäksi myös vainajan puoliso. Jos asiakas on tehnyt hakemuksen ennen kuolemaansa, Kela ratkaisee oikeuden toimeentulotukeen kuolinpäivään asti ja toimittaa päätöksen kuolinpesälle. Lue lisää kuolleen henkilön toimeentulotuen käsittelystä .
