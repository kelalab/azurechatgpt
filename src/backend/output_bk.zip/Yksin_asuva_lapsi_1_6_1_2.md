#### 1.6.1.2 Yksin asuva lapsi
Yksin asuva lapsi muodostaa oman toimeentulotukiperheensä ja hänelle tehdään oma laskelma. Laskelmalla huomioidaan:
 - lapsen tosiasiallisesti saamat tulot, esimerkiksi tosiasiallisesti maksettu elatusapu tai lapsen tilille maksettu lapsilisä,
 - lapsen käytettävissä olevat varat,
 - yksin asuvan henkilön perusosa sekä
 - lapsen muut perusmenot.

Yksin asuvan lapsen vanhempien elatuskyky tulee aina selvittää. Hakemusta ei kuitenkaan voida hylätä sillä perusteella, että vanhempi laiminlyö elatusvelvollisuutensa. Tällaisessa tilanteessa tulee selvittää mahdollisuus periä myönnetty toimeentulotuki takaisin vanhemmalta. Lisäksi tulee arvioida, onko tarvetta tehdä lastensuojeluilmoitus. Katso myös vanhemman elatusvelvollisuus ja lastensuojeluilmoituksen tekeminen .
>ESIMERKKI: Elli on 16-vuotias ja muuttanut asumaan yksin omaan asuntoon. Ellin osalta on maksussa lapsilisä sekä elatustuki hänen äidilleen. Ennen päätöksen antamista Elliä kuullaan vanhemmilta saadusta elatuksesta ja Elli kertoo, ettei hän saa mitään rahaa vanhemmiltaan. Ellille tehdään oma laskelma, jossa ei huomioida lapsilisää eikä elatustukea tulona, koska Elli ei ole saanut niitä käyttöönsä. Elliä ohjataan hakemaan tuet itselleen maksuun ja päätöksellä määrätään Ellille maksettu toimeentulotuki takaisinperittäväksi hänen vanhemmiltaan, jos vanhemmat ovat tahallisesti laiminlyöneet elatusvelvollisuutensa.

Jos alaikäinen asuu esimerkiksi ystävän kanssa, huomioidaan hänelle yhteistaloudessa asuvan perusosa. Muilta osin laskelma tehdään kuten yksin asuvan lapsen kohdalla.
