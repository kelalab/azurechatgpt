###### 1.5.1.1.5.f Avo- ja laitospalvelut
Katso kohdasta Kunnan järjestämät sosiaali- ja terveydenhuollon avo- ja laitospalvelut ohjeet asumismenojen huomioimiseen avo- tai laitosasumisessa.
