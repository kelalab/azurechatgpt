#### 1.7.14.1 Milloin asiakasta on kuultava?
