###### 1.5.1.1.5.c Kuolinpesän omistama asunto
Omistusasunnoksi katsotaan myös yhteisomistusasunto sekä asunto, jonka asumiskustannuksista hakija tai perheenjäsen vastaa kuten omistusasunnossa, esimerkiksi kuolinpesän osakkuuden, lesken hallintaoikeuden tai ositussopimuksen perusteella hallittu asunto. Tällöin voidaan huomioida hakijan tosiasiallisesti maksamat kohtuulliset asumismenot. Menojen maksaminen tulee osoittaa esimerkiksi tiliotteella.
>ESIMERKKI: Olli asuu asunnossa, jonka omistaa kuolinpesä. Hän on itse yhtenä osakkaana kuolinpesässä. Olli ei ole tehnyt vuokrasopimusta kuolinpesän kanssa ja hän hakee perustoimeentulotukea asunnon lämmityskustannuksiin ja kiinteistöveroon. Jos Olli tosiasiallisesti maksaa menot, ne voidaan huomioida kohtuullisilta osin menona.

Jos kuolinpesä vuokraa omistamansa asunnon yhdelle kuolinpesän osakkaalle, vuokrasta vähennetään vuokraajan oma osuus omistusosuuden mukaisesti.
>ESIMERKKI: Emma on vuokrannut asunnon kuolinpesältä, jossa on itse osakkaana. Vuokra on 600e/kk. Emmalta tarkistetaan puhelimessa kuolinpesän osakkaiden määrä. Emma kertoo, että kuolinpesässä on 3 osakasta. Emmalle voidaan huomioida vuokrasta 2/3 eli 400e.

