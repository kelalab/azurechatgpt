### 1.1.4 Perusosan määrä
Perusosien määrää arvioitaessa lähtökohtana on asiakkaan tosiasiasiallisen asumisen luonne.
Perustoimeentulotuen laskennassa käytetään lähtökohtana yksin asuvan perusosaa, jonka euromäärä vahvistetaan lailla. Muiden kuin yksin asuvien perusosat määritellään prosentteina yksin asuvan perusosasta.
Määriä tarkistetaan vuosittain kansaneläkeindeksistä annetun lain mukaisesti. 
 - Yksin asuvan henkilön perusosan määrä on 1.1.2023 alkaen 555,11 euroa. 1.8.2022 – 31.12.2022 yksin asuvan perusosan määrä on 532,97 euroa.  1.1.2022 – 31.7.2022 yksin asuvan perusosan määrä on 514,82 euroa.  

 - Muiden kuin yksin asuvien eli yhteistaloudessa asuvan, 18 vuotta täyttäneiden henkilöiden perusosa on 85 % yksin asuvan henkilön perusosan määrästä. 
 - Yksinhuoltajan perusosa on yksin asuvan perusosa, joka on korotettu 14 %:lla. 
 - Vanhempiensa tai vanhempansa luona asuvan yli 18-vuotiaan perusosa on 73 % yksin asuvan henkilön perusosan määrästä. 

 - 10-17 - vuotiaan lapsen perusosa on 70 % yksin asuvan henkilön perusosan määrästä. Perusosaa korotetaan 10 %:lla vuoden 2023 ajaksi.  
 - Alle 10 -vuotiaan perusosa on 63 % yksin asuvan henkilön perusosan määrästä. Perusosaa korotetaan 10 %:lla vuoden 2023 ajaksi.  

Jos perheeseen kuuluu useampia 10-17-vuotiaita tai alle 10-vuotiaita lapsia, perusosa toisesta lapsesta on 5 % ja kolmannesta ja sitä useammasta lapsesta 10 % alempi kuin iän mukainen prosenttiosuus.
Perusosa sisältää laskennallisia menoja seuraavassa suhteessa:
 - ravintomenot 49 %
 - vaate- ja jalkinemenot 9 %
 - informaatiomenot (puhelin, internet, lehdet) 20 %
 - vähäiset terveydenhuoltomenot 3 %
 - muut menot 19 %

Edellä mainitut osuudet ovat laskennallisia. Niitä voidaan käyttää esimerkiksi laitoshoitotilanteessa ravintomenojen osalta.
Jos perustoimeentulotukea myönnetään lyhyemmäksi ajaksi kuin kuukaudeksi, perustoimeentulotuen perusosan määrä lasketaan jakamalla kuukausittaisen perusosan määrä 30 päivällä ja kertomalla käsiteltyjen päivien lukumäärällä. Alla olevat päiväkohtaiset määrät ovat pyöristettyjä lukuja. Useamman päivän kohdalla pyöristys tehdään vasta loppusummasta.


 

