##### 1.3.8.1.a Arvioitu tulo on liian suuri 
Jos tulot on arvioitu liian suureksi, tarkistetaan arvioitu määrä vastaamaan tosiasiallisesti käytettävissä olleita tuloja, kun kaikki kyseisen kuukauden todelliset tulot ovat tiedossa. 
 
>ESIMERKKI: Piialle on arvioitu huhtikuun laskelmalle ansiotuloksi 700 euroa. Kun Piia hakee toukokuulle toimeentulotukea, ja huhtikuun kaikki ansiotulot ovat jo tiedossa huomataan, että hänelle on maksettu ansiotuloja huhtikuussa 400 euroa. Huhtikuun ansiotuloksi tarkistetaan tosiasiallisesti maksettu 400 euroa.  

 
Lue lisää arvioidun ansiotulon tarkistamisesta. 
 
