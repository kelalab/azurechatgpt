##### 1.6.8.3.3 Silmälasit
Vankien silmälasien hankintaan sovelletaan samoja periaatteita kuin muidenkin perustoimeentulotuen hakijoiden kohdalla. Yleensä silmälasit myönnetään maksusitoumuksena Kelan sopimuskumppaneille. Hakemuksessa on esitettävä vankilan selvitys (esimerkiksi sosiaalityöntekijän tai -ohjaajan ilmoitus hakemuksen liitteenä), jos asiointi vankilan ulkopuolella ei ole mahdollista.
Katso tarkemmin silmälasien myöntämisestä ja optikkopalvelut -prosessista .
