### 1.11.1 Asia- ja menettelyvirheen korjaaminen
Asia- tai menettelyvirhe on kysymyksessä seuraavissa tilanteissa:
 1. Päätös perustuu selvästi virheelliseen tai puutteelliseen selvitykseen. Virheellisestä selvityksestä on kysymys esimerkiksi silloin, kun päätöksessä ei ole huomioitu tuloja, jotka ovat olleet olemassa hakemusta ratkaistaessa.
 2. Päätös perustuu ilmeisen väärään lain soveltamiseen. Ilmeisen väärä lain soveltaminen on kysymyksessä esimerkiksi silloin, kun tulona on huomioitu sellaisia etuuksia, joita ei toimeentulotukilain perusteella huomioida tulona.
 3. Päätöstä tehtäessä on tapahtunut menettelyvirhe. Menettelyvirhe on kysymyksessä esimerkiksi silloin, kun hakijan perusosaa on alennettu eikä hänelle ole varattu tilaisuutta tulla kuulluksi asiassa
 4. Asiaan on tullut sellaista uutta selvitystä, joka voi olennaisesti vaikuttaa päätökseen.

Päätöksessä on asiavirhe, jos päätös on jo sitä annettaessa ollut virheellinen, esimerkiksi virheellisesti huomioidun vuokran määrän vuoksi. Virhe on voinut syntyä joko Kelan tai asiakkaan menettelyn vuoksi. Jos virhe on syntynyt asiakkaan menettelyn vuoksi, sovelletaan kuitenkin päätöksen tarkistamista koskevia ohjeita. Lue lisää ilmoitusvelvollisuuden laiminlyönnistä .
