#### 1.5.4.3 Terveydenhuoltoon liittyvät matkakustannukset
Perustoimeentulotuessa huomioidaan yleensä menoina vain julkisessa terveydenhuollossa käynnistä syntyneet matkakustannukset, joista Kela maksaa yleensä sairausvakuutuslain mukaisen korvauksen (sv-korvaus). 
Paikallisliikenteen matkoina tehtävät terveydenhuollon matkat kuuluvat perusosaan. Paikallisliikenteen matkat voidaan kuitenkin poikkeuksellisesti huomioida perustoimeentulotuessa, jos kyseessä on 
 - pidempi matka ja osa matkasta on paikallisliikennettä tai 
 - sarjahoito, esimerkiksi asiakas käy korvaushoidossa sovittuina päivinä usean kerran viikossa. Asiakkaalta voidaan pyytää käyntien toteutumisesta luotettavaa selvitystä. 

Perustoimeentulotuessa huomioidaan yleensä matkakustannuksista sv-korvauksen jälkeinen osuus eli asiakkaan omavastuuosuus. Matka huomioidaan lähimpään mahdolliseen tutkimus- ja hoitopaikkaan. Matka voidaan tehdä julkisella liikenteellä, omalla autolla, taksilla tai ambulanssilla. Matkakustannukset huomioidaan halvimman matkustustavan mukaan asiakkaan sairaus ja terveydentila sekä liikenneolosuhteet huomioiden. Matkakustannuksen huomioimiseen tarvitaan yleensä sairaalan kutsu tai vastaava selvitys käynnistä esimerkiksi kuntoutuspäätös.
Menoina huomioidaan matkat yksityisen palveluntuottajan luo, jos kyseessä on:
 - Kelan tai hyvinvointialueen maksama avo- tai laitoskuntoutus. Laitoskuntoutuksen aikana tehtäviä kotilomamatkoja ei yleensä tueta.
 - Kelan korvaama psykoterapia
 - Kelan harkinnanvaraisena kuntoutuksena järjestämä neuropsykologinen kuntoutus
 - terveydenhuollon käynti, johon hyvinvointialue on antanut maksusitoumuksen ja palvelusta peritään vain asiakasmaksulain suuruinen maksu
 - käynti YTHS:n lähimmässä toimipisteessä, josta opiskelijan tarvitsema hoito on saatavilla.

Jos yksityisen terveydenhuollon kulu (ei Kelan tai hyvinvointialueen järjestämä) on asiakkaan kohdalla hyväksytty menoksi perustoimeentulotuessa, hyväksytään myös yksityisessä terveydenhuollossa käymisestä syntyneiden matkakulujen omavastuut toimeentulotuessa menona. Lue lisää yksityisen terveydenhuollon kustannuksista .
Matkat proteettiseen hammashoitoon huomioidaan perustoimeentulotuessa, jos proteettinen hoito on toimeentulotuessa huomioitavaa. Vain rintamaveteraanit saavat sv-korvauksen matkakustannuksista proteettiseen hammashoitoon. Lue lisää proteettisen hoidon huomioimisesta .
Matkat julkisen terveydenhuollon järjestämiin syöpäseulontoihin voidaan huomioida menona laskelmalla halvimman matkustustavan mukaan. Nämä matkat eivät ole sv-korvattavia.
