#### 1.8.4.4 Välitystilille tai Virho-tilille
 
Osassa hyvinvointialueista on käytössä välitystilit ja osa on ottanut käyttöön Virho –järjestelmän, joiden kautta asiakkaiden taloudellisia asioita hoidetaan. Asiakkaalla ei ole näihin tileihin käyttöoikeutta. Jos asiakas hakemuksessaan ilmoittaa, että tuki maksetaan hyvinvointialueen sosiaalipalveluille, Kela on yhteydessä edellä mainittuihin palveluihin ja tarkistaa, onko kysymyksessä välitystili tai Virho-tili ja pyytää maksuosoitteen.
Hyvinvointialueen sosiaalitoimelta tulee olla erillinen asiakirja, josta välitystiliasiakkuus tai Virho- tili selviää ja lisäksi asiakkaalta tulee olla suostumus tai valtakirja näille tileille maksamiseen.
Jos asiakas haluaa siirtää tuen maksun takaisin omalle tililleen, asiakkaaseen tulee olla yhteydessä ja tiedustella, voisiko toimeentulotuen maksamista välitystilille tai Virho-tilille jatkaa. Näissä tilanteissa tarkistetaan myös, onko asiakkaalla maksamattomia vuokria, joiden perusteella vuokranmaksu voidaan tarvittaessa siirtää suoraan vuokranantajalle asumisen turvaamiseksi.
Jos asiakas edelleen haluaa maksun omalle tililleen:
 - keskustellaan huoli-ilmoituksen tekemisestä asiakkaan kanssa ja tehdään ilmoitus tarvittaessa
 - maksetaan perustoimeentulotuki asiakkaan omalle tilille.

