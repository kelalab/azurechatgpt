## 1.5 Menojen huomioiminen
Perustoimeentulotuki muodostuu perusosasta ja muista perusmenoista. Muihin perusmenoihin kuuluvat menot otetaan huomioon tarpeellisen suuruisina. Menot otetaan huomioon todellisen suuruisina, jos ne eivät ole kohtuuttomia. Asiakkaan tulee tarvittaessa esittää niihin liittyvät selvitykset eli yleensä laskut.
Laskut otetaan huomioon menoina alkuperäisen eräpäivän mukaisesti ja niiden on kohdistuttava perustoimeentulotuen ajalle. Jos maksetusta menoerästä ei ole erillistä laskua, maksukuitti riittää (esimerkiksi bussilippu lapsen tapaamisen matkakuluista). Jos kyseessä on koko vuotta koskeva määrältään suuri muu perusmeno (esimerkiksi öljylasku), selvitetään tarkemmin, onko asiakkaan mahdollista maksaa lasku erissä.
Laskutuslisiä ei huomioida muina perusmenoina. Laskutuslisät kuuluvat perusosaan ja asiakkaan tulee maksaa nämä kustannukset itse.
Muihin perusmenoihin kuuluvien laskujen viivästyskulut huomioidaan menona vain, jos kulu on aiheutunut Kelan menettelystä.
 - Viivästyskulua voidaan pitää Kelan menettelystä johtuvana, jos Kela ei ole ratkaissut viivästyskulun aiheuttaneeseen laskuun liittyvää hakemusta 7 arkipäivän kuluessa siitä, kun asian ratkaisemiseksi tarvittavat selvitykset on saatu ja viivästyskulu on aiheutunut tästä Kelan menettelystä siten, että asiakas ei ole voinut kohtuudella suoriutua laskun maksamisesta ajoissa.

