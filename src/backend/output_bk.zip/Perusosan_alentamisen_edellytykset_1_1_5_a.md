#### 1.1.5.a Perusosan alentamisen edellytykset 
Perusosan alentamisen edellytyksenä on, että kaikki alla olevat kriteerit täyttyvät: 
1. Kyseessä on laissa mainittu tilanne ( Perusosan alentaminen enintään 20 % tai Perusosan alentaminen enintään 40 % ) tai oikeuskäytännön perusteella niihin rinnastuva tilanne . 
2. Asiakasta on kuultu perusosan alentamisesta. 
3. Perusosan alentaminen ei vaaranna ihmisarvoisen elämän edellyttämän turvan mukaista välttämätöntä toimeentuloa eikä alentaminen johda kohtuuttomaan tilanteeseen. 
 - Harkintaa tehtäessä on huomioitava asiakkaan pyrkimys ja käytettävissä olevat keinot korjata kieltäytyminen tai laiminlyönti. Katso myös perusosan alentamisen kohtuullisuusharkinta . 
 - Harkinnassa huomioidaan mahdollinen sosiaalihuollon lausunto . 

4. Alentaminen voi olla kestoltaan enintään kaksi kuukautta kerrallaan viimeisimmästä kieltäytymisestä tai laiminlyönnistä. 
 
Lue lisää perusosan alentamisen prosessista . 
