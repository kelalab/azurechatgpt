##### 1.5.5.1.a 1. Maksusitoumus lääkekustannuksiin
Maksusitoumuksella lääkekustannuksiin asiakas voi saada sairauden hoidon kannalta tarpeelliset myyntiluvalliset lääkkeet ja valmisteet, jotka on määrätty lääkemääräyksellä sairauden hoitoon ja joilla on valmistekohtainen tuotenumero (Vnr-numero). Tällaisia lääkkeitä tai valmisteita ovat esimerkiksi
 - sairausvakuutuslain mukaan korvattavat lääkevalmisteet, jotka ovat asiakkaalle korvattavia
 - ei-korvattavat lääkevalmisteet, jos lääkevalmisteen hinta ei ylitä 200 euroa/lääkepakkaus
 - itsehoitolääkkeet ja –valmisteet, jos valmisteella on tuotenumero.

Maksusitoumus lääkekustannuksiin kattaa myös
 - lääkemääräyksellä määrätyt ehkäisyvalmisteet esimerkiksi e-pillerit, kuparikierukka, hormonikierukka, vaikka lääkemääräyksessä ei ole merkintää sairauden hoidosta,
 - perusvoiteet, jos niille on vahvistettu korvattavuus, vaikka valmisteilla ei ole VNR-numeroa,
 - apteekissa valmistetut, sairauden hoitoon tarkoitetut lääkeseokset, vaikka valmisteilla ei ole VNR-numeroa (ex tempore),
 - asiakkaan alkuomavastuun,
 - lääkekohtaisen omavastuun, kun vuosiomavastuu ylittyy tai on ylittynyt,
 - annosjakeluasiakkaan ja apteekkisopimusasiakkaan maksettavaksi jäävät annos-jakelupalkkioiden kohtuulliset kustannukset,
 - apteekkisopimusasiakkaille koituvat kohtuulliset pakkausmateriaalikustannukset,
 - lääkkeen annosteluun liittyvä välttämätön tarvike esimerkiksi mittamuki, ruisku sekä lääkemääräyksellä määrätty Babyhaler tai muovidosetti.

Lue lisää maksusitoumuksen myöntämisestä .
