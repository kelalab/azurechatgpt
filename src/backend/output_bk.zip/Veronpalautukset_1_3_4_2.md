#### 1.3.4.2 Veronpalautukset
Veronpalautukset huomioidaan yleensä tuloina veronpalautuksen maksukuukaudelle, ellei niitä voida pitää vähäisinä. Vähäisinä veronpalautuksina pidetään alle 50 euron veronpalautusta henkilöä kohti tai alle 100 euron veronpalautusta perhettä kohti. Veronpalautuksista huomioidaan vain vähäisen määrän yli menevä osa. Esimerkiksi yksin asuvan saamasta 65 euron veronpalautuksesta huomioidaan tulona 15 euroa.
Jos veronpalautus ulosmitataan tai käytetään verovelan kuittaukseen, ei ulosmitattua osuutta veronpalautuksesta oteta tulona huomioon.
Lisäverot rinnastetaan velkaan eikä niitä huomioida menoina.
Lue lisää Veronpalautusten huomioimisesta toimeentulotuessa .
