## 1.6 Erityistilanteet
Tietyissä tilanteissa toimeentulotukioikeuden määrittämiseen saattaa liittyä erityispiirteitä koskien tulojen ja menojen huomioimista. Nämä tilanteet ovat
 - alaikäinen
 - asevelvollinen
 - avo- ja laitospalveluissa oleva asiakas
 - hakijan tai perheenjäsenen kuolema
 - jälkihuolto
 - opiskelija
 - ulkomaalainen
 - vanki
 - yrittäjä 

