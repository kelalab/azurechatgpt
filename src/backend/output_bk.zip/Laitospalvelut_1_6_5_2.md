#### 1.6.5.2 Laitospalvelut
Laitoshoidolla tai sitä vastaavalla hoidolla tarkoitetaan ylläpidon, hoidon ja huolenpidon sisältävää toimintaa. Se järjestetään sairaalan vuodeosastolla, terveyskeskuksen vuodeosastolla tai vastaavassa sosiaalihuollon laitoksessa, kuten vanhainkodissa, kehitysvammaisten erityishuollon keskuslaitoksessa tai päihdehuoltolaitoksessa.
Laitospalveluita järjestetään lyhyt- tai pitkäaikaisena hoitona, josta peritään laitoshoidon asiakasmaksu.
 - Lyhytaikaisesta laitoshoidosta peritään terveydenhuoltolain tai sosiaalihuoltolain mukainen tasasuuruinen asiakasmaksu.
 - Pitkäaikaisesta laitoshoidosta peritään hyvinvointialueen asiakasmaksupäätöksen mukainen tulosidonnainen asiakasmaksu.

