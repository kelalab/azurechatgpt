##### 1.5.1.4.1 Kohtuullisen tason määrittäminen
Asumismenojen kohtuullisuusharkinnassa otetaan huomioon seuraavat asiat:
 - hakijan tai perheen asunnon erityistarpeet ja elämäntilanne,
 - Kelan asumisnormi,
 - asumisen menojen kokonaiskustannukset ja
 - asunnossa asuvien henkilöiden lukumäärä.

Pääsääntö on, että asumisnormi määräytyy asunnossa asuvien henkilöiden lukumäärän mukaisesti.
>ESIMERKKI: Virtaset asuvat Lohjalla. Perheeseen kuuluu vanhemmat ja kaksi lasta, eli yhteensä 4 henkilöä. Virtasille hyväksytään yleensä Lohjalla 4 henkilölle määritelty asumisnormi eli 897 euroa.

Katso kuntakohtaisesti määritellyt, vuosittain tarkistettavat Kelan asumisnormit .
Jos samassa asunnossa asuu eri toimeentulotukiperheisiin kuuluvia henkilöitä, katsotaan, että kyse on kimppa-asumisesta. Kimppa-asunnossa asumismenojen kohtuullisuusarvioinnissa käytetään asunnossa asuvien henkilöiden lukumäärän mukaan määräytyvää asumisnormia, jota on korotettu yhdellä henkilöllä.
>ESIMERKKI: Petra asuu kimppa-kämpässä. Asunnossa asuu yhteensä 4 henkilöä. Petran vuokraa verrataan kimppa-asujalle muodostettuun normiin 229 euroon eli paikkakunnan viiden henkilön normi (916 euroa) jaettuna asunnossa asuvien henkilöiden lukumäärällä (4 hlö).

Jos kimppa-asunnossa asuvan hakijan asumismenot ylittävät asumisnormin, arvioidaan asumismenojen kohtuullisuutta. Kohtuullisuusharkinnassa on otettava huomioon seuraavia asioita:
 - millainen asunto on kyseessä (esimerkiksi asunnon koko)
 - keitä asunnossa asuu (kuinka paljon aikuisia ja lapsia)
 - kuinka monta toimeentulotukiperhettä muodostuu
 - paljonko eri toimeentulotukiperheet maksavat vuokraa
 - kuinka paljon asuntoon maksetaan asumistukea
 - onko realistista, että hakija löytää kimppakämppää edullisemman asunnon
 - vastaavatko asunnon menot yleistä hintatasoa paikkakunnalla. Asunto ei ole esimerkiksi huomattavasti kalliimpi, kuin tarjolla olevat samankokoiset asunnot kyseisellä paikkakunnalla.

Jos yhden henkilön kimppa-asunnon menot ovat huomattavasti paikkakunnan yhden hengen asumisnormia pienemmät ja asunnon kokonaiskustannuksia voidaan pitää paikkakunnan hintatasoon nähden kohtuullisina, voidaan kustannukset hyväksyä kokonaisuudessaan.
>ESIMERKKI: Essi muuttaa opiskelupaikkakunnalle ja saa huoneen 4 henkilön kimppakämpästä. Vuokra on asunnossa yhteensä 1450 euroa. Vuokra jakaantuu kämppiksille tasan ja Essin osuus on 362,50 euroa. Paikkakunnan asumisnormi 5 hengelle (4 asukasta +1) on 1175 euroa eli asumisnormin perusteella Essille voitaisiin hyväksyä asumismenoja 293,75 euroa. Jos Essi asuisi paikkakunnalla yksiössä, hänelle voitaisiin hyväksyä asumismenoja 694,00 euroa. Essin asumismenot ylittävät laskennallisen asumisnormin määrän, mutta ovat huomattavan edulliset verrattuna yksinasuvan asumisnormiin. Lisäksi asuntoa voidaan pitää kohtuuhintaisena 4 henkilölle. Harkinnalla Essille voidaan hyväksyä Essin esittämät todelliset asumismenot, eikä muuttokehotusta anneta.

>ESIMERKKI: Emmi asuu vuokralla kahden lapsensa kanssa omakotitalossa, jossa asuu myös toinen äiti lapsen kanssa sekä yksi nainen, jolla ei ole lapsia. Asunnon vuokra on 1350 euroa kuukaudessa, josta asunnossa asuvat aikuiset vastaavat jokainen yhtä suurella osuudella. Emmi hakee toimeentulotukea. Seitsemän henkilön normi paikkakunnalla on 1411 e eli henkilömäärän näkökulmasta tarkasteltuna asumisnormi ylittyy. Emmi maksaa asunnosta vuokraa 450 e/kk, joten ei ole kohtuullista antaa Emmille kehotusta muuttaa halvempaan asuntoon, koska Emmin maksama vuokra jää reilusti alle paikkakunnan kolmen henkilön kohtuullisen vuokratason, joka on 914 euroa.

Jos yhden henkilön kimppa-asunnon menot ovat huomattavasti kimppa-asujalle laskettua asumisnormia suuremmat ja asunnon kokonaiskustannukset ovat paikkakunnan kohtuullista tasoa suuremmat, selvitetään, onko hakijalla perusteita kohtuullista tasoa korkeammille kustannuksille. Katso asumismenot ylittävät Kelan asumisnormin . 
Jos perheessä on vuoroasuva lapsi, niin asumismenojen kohtuullisuusarvioinnissa vuoroasuva lapsi korottaa vuoroasuvan lapsen molempien perheiden asumisnormia. 
>ESIMERKKI: Leo on 5 –vuotias lapsi ja hän vuoroasuu vanhemmillaan Nooralla ja Samilla. Noora hakee toimeentulotukea itselleen ja Leolle. Nooralle huomioidaan 2 henkilön asumisnormin mukaiset asumismenot. Sami hakee toimeentulotukea itselleen, uudelle puolisolleen Lauralle sekä Leolle. Samille huomioidaan 3 henkilön asumisnormin mukaiset asumismenot.  


