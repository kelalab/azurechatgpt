#### 1.1.5.1 Velvollisuus ilmoittautua TE-palveluihin
Perustoimeentulotukea hakeva 17–64-vuotias henkilö on velvollinen ilmoittautumaan työttömäksi työnhakijaksi TE-palveluihin, ellei hän:
1. ole työssä palkansaajana tai yrittäjänä
2. opiskele päätoimisesti
3. ole työttömyysturvalain mukaisesti määriteltynä työkyvytön siten, että
 - henkilö saa sairausvakuutuslain mukaista sairauspäivärahaa tai osasairauspäivärahaa
 - henkilö saa kansaneläkelain mukaista työkyvyttömyyseläkettä tai kuntoutustukea
 - henkilö saa täyden työkyvyttömyyden perusteella maksettavaa etuutta jonkin muun lain nojalla
 - henkilö on todettu sairausvakuutuslain tai kansaneläkelain mukaisesti työkyvyttömäksi, vaikka etuutta ei ole hänelle myönnetty. Esimerkkejä tilanteista, joissa sairauspäivärahahakemus on hylätty, vaikka asiakasta pidetään työkyvyttömänä, ovat enimmäisajan täyttyminen, sairausvakuutuksen puuttuminen, asiakkaan nuori ikä tai estävä etuus.

4. kuulu seuraavaan ryhmään:
 - saa kansaneläkelain tai työeläkelakien mukaista vanhuuseläkettä tai varhennettua vanhuuseläkettä
 - on oikeus saada sairausvakuutuslain mukaista raskausrahaa tai joka saa erityisraskausrahaa, vanhempainrahaa tai erityishoitorahaa taikka jolle on myönnetty vapaata raskauden ja synnytyksen tai lapsen hoidon vuoksi
 - saa maatalousyrittäjien luopumistuesta annetun lain tai maatalouden harjoittamisesta luopumisen tukemisesta annetun lain (612/2006) mukaista luopumistukea
 - saa Kansaneläkelaitoksen kuntoutusetuuksista ja kuntoutusrahaetuuksista annetun lain mukaista kuntoutusrahaa tai
 - saa alla olevien lakien mukaista kuntoutusrahaa: työntekijän eläkelaki  merimieseläkelaki  yrittäjän eläkelaki  julkisten alojen eläkelaki  maatalousyrittäjän eläkelaki  julkisten alojen eläkelaki  ortodoksisesta kirkosta annettu laki  eräiden valtakunnassa voimassa olevien valtion eläkkeitä koskevien säännösten soveltamisesta Ahvenanmaan maakunnassa annettu maakuntalaki (ÅFS 54/2007) taikka 

 - saa ansionmenetyskorvausta tapaturmavakuutuksen, liikennevakuutuksen tai sotilasvammalain kuntoutusta koskevien säännösten perusteella
 - saa työeläkelakien mukaista työuraeläkettä

5. ole laitoshoidon tai lääkärin toteaman sairauden vuoksi esteellinen vastaanottamaan työtä.
6. ole muun edellä mainittuihin verrattavan hyväksyttävän syyn vuoksi esteellinen vastaanottamaan työtä. Hyväksyttävä syy on esimerkiksi se, että hakija
 - toimii perhehoitajalain mukaisena perhehoitajana vähintään neljä tuntia päivässä
 - toimii vanhuksen, vammaisen tai sairaan omaishoidon tuesta annetun lain mukaisena omaishoitajana vähintään neljä tuntia päivässä
 - suorittaa varusmies- tai siviilipalvelusta
 - on oikeutettu lasten kotihoidon tukeen
 - hoitaa alle kouluikäistä lasta kotona

Jos hakija, jolla on velvollisuus olla työttömänä työnhakijana, ei ilmoittaudu TE-palveluihin työttömäksi työnhakijaksi, perustoimeentulotuen perusosaa on mahdollista alentaa, jos kaikki alentamiselle asetetut edellytykset täyttyvät. 
Lue lisää työkyvyn vaikutuksesta velvollisuuteen ilmoittautua TE-palveluihin.
