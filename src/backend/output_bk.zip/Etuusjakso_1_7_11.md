### 1.7.11 Etuusjakso
Perustoimeentulotuki määrätään yleensä kalenterikuukaudelta. Tästä ajanjaksosta käytetään nimitystä etuusjakso. Hakemus ratkaistaan koko hakemusta koskevalta ajalta. Jos oikeutta perustoimeentulotukeen ei voida ratkaista koko haetulle ajalle, asia perustellaan päätöksessä ja hakijalle kerrotaan mahdollisuudesta hakea toimeentulotukea myöhemmälle ajalle uudelleen.
Perustoimeentulotukea voidaan tarpeen mukaan myöntää kuukautta pidemmältä tai lyhyemmältä ajalta . Tukea ei kuitenkaan voida hylätä tulevalta ajanjaksolta kuukautta pidemmältä ajalta.
>ESIMERKKI: Petran toimeentulotukihakemus touko-, kesä- ja heinäkuulle ratkaistaan toukokuussa. Toimeentulotukioikeutta toukokuulle ja kesäkuulle ei muodostu, koska tulot ylittävät menot, joten hylkäävä ratkaisu tehdään vain touko- ja kesäkuulle. Päätöksellä kerrotaan, että toimeentulotukioikeutta ei ole voitu ratkaista kesäkuuta pidemmälle ajalle, koska perustoimeentulotukea ei voida hylätä kuukautta pidemmältä tulevalta ajalta.

>ESIMERKKI: Roopen toimeentulotukihakemus touko-, kesä ja heinäkuulle ratkaistaan 3.6. Toimeentulotukioikeutta touko-, kesä ja heinäkuulle ei muodostu, koska tulot ylittävät menot. Ratkaisu voidaan tehdä koko haetulle ajalle, koska perustoimeentulotuki voidaan hylätä takautuvasti, kuluvalta kuukaudelta sekä yhdeltä tulevalta kuukaudelta.

