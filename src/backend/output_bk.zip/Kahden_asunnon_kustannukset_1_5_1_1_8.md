##### 1.5.1.1.8 Kahden asunnon kustannukset
Tietyissä poikkeustilanteissa voidaan harkita, huomioidaanko perustoimeentulotuessa menona kahden asunnon asumismenot.
Harkinnassa on otettava huomioon seuraavia asioita:
 - Onko muutto perusteltu?
 - Olisiko hakija voinut välttää päällekkäiset asumismenot?
 - Kuinka pitkän aikaa asiakkaalla on kahden asunnon menoja?
 - Onko hakijan elämäntilanteessa sellaisia asioita, jotka tulisi huomioida harkintaa tehtäessä, esimerkiksi toimintakyky tai terveydentila?
 - Onko sosiaalitoimesta toimitettu lausunto hakijan tilanteesta?

