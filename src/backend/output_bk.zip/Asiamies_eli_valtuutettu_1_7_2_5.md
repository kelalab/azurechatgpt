#### 1.7.2.5 Asiamies eli valtuutettu
