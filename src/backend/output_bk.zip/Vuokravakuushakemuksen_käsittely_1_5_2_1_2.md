##### 1.5.2.1.2 Vuokravakuushakemuksen käsittely
Vuokravakuutta haetaan lomakkeella TO2 tai sähköisessä asiointipalvelussa perustoimeentulotukihakemuksen yhteydessä. Hakemukseen on liitettävä vuokrasopimus tai asuntotarjous.
Vuokrasopimuksesta tai asuntotarjouksesta on ilmettävä vuokravakuuden myöntämiseksi välttämättömät tiedot:
 - vuokrattava asunto
 - vuokralainen tai vuokralaiset
 - vuokranantaja
 - vuokran määrä
 - se, mille ajalle vuokrasopimus on tehty
 - vuokravakuuden määrä

Tarvittaessa hakijalta pyydetään tarkempia selvityksiä esimerkiksi
 - asunnon kokonaiskustannuksista, esimerkiksi vuokranantajan selvitys edellisen vuoden kustannuksista tai kuukausittaisista kustannuksista
 - asuinkelpoisuudesta esimerkiksi rakennusviranomaisen todistus

Vuokravakuus myönnetään yleensä etukäteen ja se käsitellään vuokravakuuden erääntymiskuukaudelle. Vuokravakuutta ei yleensä myönnetä takautuvalle ajalle. Vakuus voidaan myöntää takautuvalle ajalle kuitenkin sellaisessa tilanteessa, jos asiakas ei ole esimerkiksi elämäntilanteestaan johtuen kyennyt hakemaan vakuutta ajoissa.
Jos vuokravakuutta haetaan kimppa-asuntoon, johon on tehty yhteinen vuokrasopimus, jokaiselle asukkaalle myönnetään oma vakuus pääluvun mukaiselle osuudelle vuokravakuuden kokonaismäärästä.
