#### 1.3.8.1 Arvioidun tulon tarkistaminen
Jos arvioitu tulo ei vastaa tosiasiallisesti maksettua tuloa, Kela tarkistaa arvioidun tulon vastaamaan todellista tuloa, jos toimeentulotukea haetaan seuraavan kahden kuukauden aikana.Hakijan pyynnöstä arvio voidaan tarkistaa myöhemminkin. Jos vain osa kuukauden tuloista on arvioitu, tarkistetaan tulot vain arvioiduilta osin. 
Jos arvio on ollut liian suuri tai maksukuukauden päätös tarkistetaan muusta syystä, tulot tarkistetaan maksukuukaudelle. 
Jos arvio on ollut liian pieni, huomioidaan arvion ylittävä tulo jälkikäteen tulona, jos hakija hakee toimeentulotukea uudelleen seuraavan kahden kuukauden aikana. 
 
 
