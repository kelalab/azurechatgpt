##### 1.3.11.1.b Etuustulot
Perustoimeentulotuessa voidaan yleensä käyttää tulorekisterin muodostamaa huomioitavaa määrää.
Tulorekisterissä etuustulot ilmoitetaan maksuajankohdan perusteella. Tulorekisterissä näkyy hakijan saama etuustulo bruttona (ennakonpidätyksen alainen määrä) sekä tulorekisterin muodostama huomioitava määrä, joka sisältää ne tulolajit ja vähennykset, jotka on määritelty otettavan toimeentulotuessa huomioon. Etuudenmaksaja voi ilmoittaa tulorekisteriin myös etukäteen asiakkaalle maksuun tulevasta suorituksesta.
Lue lisää etuustuloista .
