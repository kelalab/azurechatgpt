##### 1.5.1.1.1 Vuokra-asunto
Vuokra-asunnon huomioitavia menoja ovat
 - vuokra,
 - erilliset vesimaksut,
 - erilliset lämmityskulut ja
 - saunamaksu.

Asunnon vuokraaminen tai hallinta osoitetaan kirjallisella vuokrasopimuksella. Alaikäisen itsensä allekirjoittama vuokrasopimus ei ole pätevä. Alaikäisen puolesta vuokrasopimuksessa tulee olla huoltajan allekirjoitus. Jos sopimuksesta ei käy ilmi kuukausittain maksettavien asumismenojen määrä, pyydetään asiakkaalta erittely menoista esimerkiksi vuokralasku.
Vuokra ja vuokrasopimuksessa määritellyt toimeentulotuessa huomioitavat menot voidaan huomioida asiakkaan menona vuokrasopimuksen voimassaoloaikana, jos asiakas tosiasiallisesti maksaa menot.
Jos hakija on vuokrannut kalustetun asunnon, voidaan vuokra hyväksyä kokonaisuudessaan. Jos vuokrasta on eritelty kalusteiden osuus, tätä osuutta ei hyväksytä menona.
Jos hakija on vuokralla kuolinpesän omistamassa asunnossa, jossa hän on itse osakkaana, katso kohdasta Kuolinpesän omistama asunto , miten asumismenot huomioidaan perustoimeentulotuessa.
Jos toimeentulotuen hakija tai perheenjäsen omistaa asunnosta alle 50 %, katsotaan, että kyseessä on vuokra-asunto ja asumismenot hyväksytään vuokrasopimuksen mukaisesti.
Katso kohdasta Asumismenot, joita ei huomioida , mitä menoja vuokra-asunnossa ei huomioida.
