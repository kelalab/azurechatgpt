#### 1.7.4.2 Selvitykset tuloista
