#### 1.3.11.1 Tulona huomioitava määrä
