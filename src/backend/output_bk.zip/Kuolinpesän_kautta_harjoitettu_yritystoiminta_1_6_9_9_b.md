##### 1.6.9.9.b Kuolinpesän kautta harjoitettu yritystoiminta
Yritystoimintaa voidaan harjoittaa myös kuolinpesän nimissä. Kuolinpesä on kuolinpesän osakkaista erillinen verovelvollinen. Kuolinpesä on toiminnastaan kirjanpitovelvollinen, lukuun ottamatta maatilataloustoimintaa harjoittavaa kuolinpesää. Kuolinpesän kautta harjoitettu yritystoiminta ei yleensä tee asiakkaasta yrittäjää toimeentulotuen näkökulmasta. Asiassa huomioidaan TE-palvelujen tulkinta tilanteesta.
Kuolinpesän nimissä harjoitetusta toiminnasta saadut tulot huomioidaan kuitenkin laskelmalla ansiotulona, jos rahat on saatu omalle tilille tai nostettu esimerkiksi käteisellä omaan elatukseen käytettäväksi. Myös kuolinpesän rahavaroista maksatetut oman yksityistalouden kulut huomioidaan asiakkaan tulona. Kuolinpesän rahavaroja ei yleensä voida huomioida asiakkaan käytettävissä oleviksi tuloiksi tai varoiksi. Jos asiakas on osakkaana kuolinpesässä, tulee tarvittaessa määrätä myös takaisinperinnästä. Lue lisää kuolinpesistä ja takaisinperinnästä.
Jos asiakkaalla on estävä työvoimapoliittinen lausunto kuolinpesän kautta harjoitetun yritystoiminnan vuoksi, tulee tarkemmin selvittää, voidaanko asiakasta pitää myös toimeentulotuessa yrittäjänä. Arviossa otetaan huomioon esimerkiksi
 - yritysmuoto,
 - määräysvallan suuruus ja
 - muiden pesän osakkaiden lukumäärä.

