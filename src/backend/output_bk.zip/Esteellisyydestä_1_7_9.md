### 1.7.9 Esteellisyydestä
