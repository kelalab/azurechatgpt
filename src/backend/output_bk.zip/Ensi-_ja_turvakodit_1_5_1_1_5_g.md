###### 1.5.1.1.5.g Ensi- ja turvakodit
Ensi- ja turvakodissa asuvan osalta selvitetään, mitä palveluja asukas asuessaan saa tai mitä palveluja vuokraan sisältyy. Jos asumiseen sisältyy myös ruokailu tai esimeriksi hygieniatarvikkeet, niiden osuus vähennetään perusosasta.
