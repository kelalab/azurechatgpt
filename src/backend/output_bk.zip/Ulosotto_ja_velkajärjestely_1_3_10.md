### 1.3.10 Ulosotto ja velkajärjestely
Jos hakijan tai hänen perheensä tulot ovat ulosoton kohteena, niistä otetaan huomioon vain ulosoton jälkeinen, tosiasiassa käytettävissä oleva osuus. Hakijaa ohjataan päätöksessä tarkistamaan tarvittaessa ulosottoviranomaiselta suojaosuutensa oikeellisuus, jos suojaosuuteen vaikuttavissa perhesuhteissa on tapahtunut muutoksia eikä näistä ole ulosottoviranomaiselle ilmoitettu. Suojaosuuteen vaikuttavia perhesuhteiden muutoksia on
 - lapsen syntymä,
 - yhteen muutto avo- tai aviopuolison kanssa, jolla on lapsi, ja
 - yhteen muutto avo- tai aviopuolison kanssa, jonka tulot alittavat 600 euroa.

Jos hakija lyhentää vapaaehtoisesti ulosotossa olevaa velkaansa, ei ulosoton maksu vähennä huomioitavan tulon määrää. Vapaaehtoinen maksu rinnastuu velanhoitomenoihin.
