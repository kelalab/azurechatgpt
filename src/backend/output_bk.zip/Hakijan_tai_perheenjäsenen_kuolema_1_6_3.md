### 1.6.3 Hakijan tai perheenjäsenen kuolema
Hakemus voidaan ratkaista, kun henkilön kuolintieto on päivittynyt väestötietojärjestelmään. Hakemus voidaan kuitenkin ratkaista myös ennen kuolintiedon päivittymistä väestötietojärjestelmään, jos tieto saadaan luotettavasta lähteestä kuten esimerkiksi lesken tai lapsen yhteydenotosta.
Kuolleen henkilön hakemuksen käsittely riippuu siitä, onko
 - toimeentulotuen hakemus ollut vireillä ennen kuolemaa tai
 - asiakkaalle jo ehditty tehdä päätös perustoimeentulotuesta kuolinkuukaudelle tai
 - kyseessä uusi hakemus.

Jos kuolleella henkilöllä tai hänen perheellään ei ole ollut kuolinkuukaudelle päätöstä perustoimeentulotuesta, tulee perustoimeentulotuki ratkaista takautuvasti. Lue lisää ratkaisemisesta kohdasta Hakijalla tai perheenjäsenellä ei ole päätöstä kuolinkuukaudelle . Hakemus jätetään kuolleen henkilön nimellä, jos hän oli yksinasuva. Hakemuksen voi tehdä kuolinpesän hoitaja, sosiaalitoimen työntekijä, pesänselvittäjä tai kuolinpesän yhteishallinnossa pesän osakas muiden valtuuttamana. Jos kuollut henkilö on ollut avio- tai avoliitossa, hakijana voi olla edellä mainittujen lisäksi vainajan puoliso.
Jos kuolleella henkilöllä tai hänen perheellään on ollut kuolinkuukaudelle päätös perustoimeentulotuesta, tehdään tarkistus kuolinkuukaudelle.
Kuolleen henkilön tuloina huomioidaan kaikki ne tulot, jotka hänelle on maksettu kuolinkuukaudelta. Suurin osa etuuksista maksetaan normaalisti siltä kuukaudelta, jonka aikana henkilö kuolee ja etuudet lakkautetaan kuolemaa seuraavan kuukauden alusta alkaen. Maksetut etuudet ja niiden määrät tarkistetaan etuusjärjestelmistä, jotta ne tulevat huomioiduksi oikein. Muista vainajan tuloista ilmoitetaan hakemuksella ja liitteillä, ja esimerkiksi mahdolliset palkkatulot huomioidaan normaalisti laskelmalla kuolinkuukauden tulona.
Jos kuolleelle henkilölle on ehditty maksaa kuolinkuukautta seuraavan kuukauden toimeentulotuki, pyydetään kuolinpesää palauttamaan liikaa maksettu toimeentulotuki Kelaan. Jos maksettavaa tulee esimerkiksi kuolleen henkilön elinaikana erääntyneiden laskujen tai muutoksenhaun kautta, maksetaan nämä erät kuolinpesälle.
Lue lisää kuolleen henkilön hakemuksen käsittelystä .
