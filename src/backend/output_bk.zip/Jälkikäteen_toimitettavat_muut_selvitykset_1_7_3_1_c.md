##### 1.7.3.1.c Jälkikäteen toimitettavat muut selvitykset
Jos hakemus on hylätty puuttuvien liitteiden vuoksi ja asiakas toimittaa puuttuneet liitteet oikaisuvaatimusajan (37 vrk) sisällä, asia käsitellään uudelleen, eikä uutta hakemusta tarvita.
Jos hakija toimittaa liitteet vasta oikaisuvaatimusajan päättymisen jälkeen, asia käsitellään uudelleen takautuvana hakemuksena. Lisätietoa takautuvan laskelman tekemisestä .
