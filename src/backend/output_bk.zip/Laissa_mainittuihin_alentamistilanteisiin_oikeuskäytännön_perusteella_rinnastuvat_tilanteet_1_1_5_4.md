#### 1.1.5.4 Laissa mainittuihin alentamistilanteisiin oikeuskäytännön perusteella rinnastuvat tilanteet
Joissakin tilanteissa perusosaa voidaan oikeuskäytännön nojalla alentaa tapauskohtaisen kokonaisharkinnan perusteella rinnastamalla toiminta siihen, että henkilö on laiminlyönnillään aiheuttanut sen, ettei työtä tai julkista työvoimapalvelua ole voitu tarjota. Tällaisena tilanteena voi olla esimerkiksi:
 - pitkään jatkunut kannattamaton yritystoiminta , joka estää saamasta ensisijaisia toimeentuloa turvaavia etuuksia
 - toisen tutkinnon opiskelu ilman oikeutta opintoetuuksiin tai muihin ensisijaisiin toimeentuloa turvaaviin etuuksiin tai muutoin pitkittyneet opinnot, jotka estävät ensisijaisten etuuksien saamisen. Lue lisää opiskelijan perusosan alentamisesta .

