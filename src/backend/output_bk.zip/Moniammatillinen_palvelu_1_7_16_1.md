#### 1.7.16.1 Moniammatillinen palvelu
Moniammatillinen palvelu on
 - erityisen tuen tarpeessa
 - vaativassa muutostilanteessa oleville

asiakkaille tarkoitettu Kelan palvelu. Sillä täydennetään Kelan peruspalvelua silloin, kun asiakas tarvitsee elämäntilanteessaan linkkiä eri palveluiden välille, tukea ja seurantaa asioiden edistymisessä.
Kohderyhmään kuuluvat lapset ja lapsiperheet, nuoret, työikäiset ja ikäihmiset. Moniammatillinen palvelu on asiakkaalle aina vapaaehtoista.
