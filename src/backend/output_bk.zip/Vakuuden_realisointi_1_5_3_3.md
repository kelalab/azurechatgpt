#### 1.5.3.3 Vakuuden realisointi
Kun sähkösopimus päättyy, myös vakuuden voimassaolo päättyy.
Jos sähköyhtiö katsoo olevansa oikeutettu käyttämään sähkövakuutta, tulee sähköyhtiön tehdä Kelalle kirjallinen vaatimus vakuuden realisoimiseksi. Vakuudesta voidaan korvata enintään vakuutena myönnetty summa.
Energiayhtiö voi hakea saataviaan vakuudesta toimittamalla Kelaan joko sähkövakuuden realisointivaatimuksen (lomake TO6) tai vapaamuotoisen kirjallisen selvityksen. Sähköyhtiö voi vaatia sähkövakuuden realisointia, kun sähkösopimus päättyy. Sähköyhtiö voi vaatia vakuuden realisointia myös jo sopimuksen voimassaoloaikana, jos sähkön toimittamisen jatkaminen asiakkaalle sitä edellyttää.
Asiakkaalle ilmoitetaan sähkövakuuden realisoimisesta.
Jos sähkövakuus realisoituu, maksetaan asiakkaan toimittamat sähkölaskut jatkossa suoraan sähköyhtiölle.
