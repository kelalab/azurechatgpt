##### 1.7.4.2.a Perustoimeentulotukihakemuksen tuloselvitykset
 - Tiliotteet Uusi hakemus: Tiliotteet kaikilta perheenjäseniltä kaikista kotimaan ja ulkomaan pankkitileistä kahdelta edeltävältä kuukaudelta. Jatkohakemus: Kaikilta perheenjäseniltä kaikista kotimaan ja ulkomaan pankkitileistä, jos ne ovat tarpeellisia hakemuksen käsittelemiseksi sen mukaan, miten niitä on pyydetty edellisessä päätöksessä. Tiliotteen tietoja käytetään apuna asiakkaan ilmoittamien tietojen vahvistamiseen. Lisäksi tiliotteelta voi todeta sellaisia tietoja, joita asiakas ei ole ilmoittanut, mutta jotka on huomioitava perustoimeentulotukea käsiteltäessä. Kun tiliotetta ei ole saatavilla, on mahdollista käyttää tilistä saatavaa katkeamatonta tilitapahtumaluetteloa. Tilitapahtumaluettelossa tulee näkyä: Tilinomistaja Tilinumero Ajanjakso Saldo Sivujen määrä (asiakas toimittanut kaikki sivut) Lue lisää tiliotteista

 - Tulorekisteri sisältää tiedot Suomessa maksetuista palkkatuloista Suomessa maksetuista etuustuloista (pois lukien toimeentulotuki)

 - Tulorekisteri ei sisällä tietoja yritystoiminnan tuloista kaikkien laskutuspalveluyrittäjien tuloista ja vähennyksistä pääomatuloista ulkomaisista palkka- ja muista tuloista

 - Yrittäjän tuloselvityslomake (Kelan lomake TO4) tarvittavine liitteineen
 - Tarvittaessa vero- tai ulosottoviranomaisen tosite veronpalautuksen ulosmittauksesta

