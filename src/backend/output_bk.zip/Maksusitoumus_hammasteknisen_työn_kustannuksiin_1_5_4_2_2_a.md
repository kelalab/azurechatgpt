###### 1.5.4.2.2.a Maksusitoumus hammasteknisen työn kustannuksiin
Jos asiakas tarvitsee maksusitoumuksen hammaslaboratoriosta tilattavan hammasteknisen työn kustannuksiin, voidaan maksusitoumus myöntää hyvinvointialueen hammaslääkärin tekemän hoitosuunnitelman ja kustannusarvion pohjalta. Lisäksi edellytetään, että proteettisen hoidon kliinisen työn tekee hyvinvointialueen hammaslääkäri.
Kustannusarviossa tulee olla
 - eriteltynä kliinisen ja hammasteknisen työn kustannukset,
 - tieto hammasteknisen työn palveluntuottajasta tai palveluntuottajista ja
 - tieto mahdollisista vaihtoehtoisista hoitosuunnitelmista kustannusarvioineen.

Maksusitoumus voidaan antaa vain hammasteknisen työn kustannuksiin.
Lue lisää tarvittavista selvityksistä ja menettelystä prosessikuvauksesta .
