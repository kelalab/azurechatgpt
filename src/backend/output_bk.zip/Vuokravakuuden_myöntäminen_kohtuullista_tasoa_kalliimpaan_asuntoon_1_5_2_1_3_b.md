###### 1.5.2.1.3.b Vuokravakuuden myöntäminen kohtuullista tasoa kalliimpaan asuntoon
Jos asumismenot ylittävät Kelan kohtuullisena pitämät rajat ja asiakas esittää erityisiä perusteita korkeammille kustannuksille, harkinnassa on otettava huomioon asiakkaan:
 - oma selvitys sekä hakijan tai perheen kokonaistilanne- ja tarpeet
 - sosiaalitoimen selvitys
 - terveydentilaan liittyvät selvitykset

Katso lisää asumismenojen kohtuullisuusharkinnasta muuttotilanteessa .
Jos asiakkaalla on perusteet kohtuullista tasoa kalliimmalle asunnolle, hyväksytään asumismenot kokonaisuudessaan ja muuttokehotus edullisempaan asuntoon voidaan antaa
 - aikaisintaan vuoden kuluttua tai
 - kun vuokrasopimus päättyy tai
 - jos asiakkaan olosuhteissa tapahtuu muutos vuokrasopimuksen voimassaoloaikana.

Jos kunta on tarjonnut hakijalle esimerkiksi tukiasunnon, joka ylittää kohtuullisena pidetyt kustannukset, myönnetään vuokravakuus ja hyväksytään asumiskustannukset kokonaisuudessaan toistaiseksi, jollei asiakkaan tilanteessa tapahdu muutosta.
Jos vuokravakuutta ei myönnetä, hakijaa ohjataan tarvittaessa hankkimaan itse vakuuteen tarvittavat varat, esimerkiksi säästämällä, hakemalla kunnalta sosiaalista luototusta tai pankkilainaa tai ohjattava etsimään edullisempaa asuntoa.
