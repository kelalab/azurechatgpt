##### 1.5.1.4.4 Asumismenot hyväksytään kokonaisuudessaan määräajan jälkeen
Asumismenot voidaan hyväksyä määräajan jälkeen kokonaisuudessaan, jos hakija etsii aktiivisesti kunnan alueelta edullisempaa asuntoa, mutta kunnassa ei ole tarjolla hakijan tarpeita vastaavia asuntoja.
Hakija ei saa asettaa edullisemmalle asunnolle perusteettomia rajauksia esimerkiksi:
 - asuinalue
 - asunnon koko
 - mukavuussyyt, esimerkiksi sauna tai lasitettu parveke.

Hakijan tulee toimittaa Kelaan selvitys siitä, että hän on hakenut edullisempaa asuntoa kunnalliselta vuokranantajalta ja yksityisiltä vuokranantajilta. Selvitys voi olla esimerkiksi
 - kunnan vuokra-asuntohakemus, josta ilmenee, että hakija hakee kunnan vuokra-asuntoja ilman perusteettomia rajauksia ja hänelle ei ole pystytty osoittamaan edullisempaa asuntoa.
 - hakijan toimittama asiakirja kohteista, joita hän on hakenut yksityisiltä markkinoilta esimerkiksi Oikotieltä.

Hakijan tulee pitää asuntohakemukset voimassa koko ajan.
Jos vuokra hyväksytään kokonaisuudessaan sillä perusteella, että kunnassa ei ole tarjolla hakijan tarpeita vastaavia asuntoja, tarkastellaan hakijan tilannetta säännöllisesti uudelleen. Käsittelyssä huomioidaan paikkakunnan asuntotilanne. Hakijaa pyydetään toimittamaan yleensä jatkohakemuksen liitteeksi selvitys siitä, että hänellä on voimassa asuntohakemus sekä kunnan asuntojonossa, että yksityisille vuokranantajille sekä tiedon, onko hänelle tarjottu kunnasta asuntoa.
