##### 1.6.5.1.1 Kotiin annettavat palvelut
 
Sosiaalihuollon palveluja järjestetään yleensä niin, että asiakas asuu kotona. Kotiin annettavilla palvelulla tarkoitetaan kotihoitoa. Kotihoito pitää sisällään kotipalvelun ja kotisairaanhoidon. Kotihoidolla tarkoitetaan palvelua, jolla huolehditaan, että henkilö suoriutuu jokapäiväiseen elämään kuuluvista toiminnoista kodissaan ja asuinympäristössään. Kotihoidon lisäksi asiakkaalle voidaan tarjota tarpeen mukaan turvapalveluita tai tukipalveluita. 
 
Kotihoito  
Kotiin annettavista palveluista hyvinvointialue perii tulosidonnaisen kuukausimaksun, joka määräytyy 
 - palvelupäätökseen kirjattujen palvelutuntien määrän, 
 - asiakkaan maksukyvyn ja 
 - perheen koon mukaan. 

 
Kotihoidon laskut voidaan huomioida menona ja niistä ei pyydetä erittelyä. 
 
Turvapalvelut 
Turvapalvelut tai turva-auttamispalvelut (turvapuhelin, turvaranneke ja hälytyskäynnit) voidaan huomioida menona 
 - kun käytölle on todettu terveysperuste ja 
 - maksu peritään hyvinvointialueen asiakasmaksun yhteydessä tai 
 - hyvinvointialueen ostopalveluntuottajan laskuttamana. 

Asiakkaan itse hankkimia turvapalveluja yksityisiltä palvelujentuottajilta ei huomioida menona. 
 
Tukipalvelut 
Hyvinvointialue voi järjestää kotihoidon lisäksi tukipalveluita ja periä niistä erillisen maksun. Tukipalveluita ovat: 
 - ateriapalvelu 
 - vaatehuoltopalvelu 
 - siivouspalvelu 
 - asiointipalvelu 
 - osallisuutta ja sosiaalista kanssakäymistä edistävä tai tukeva palvelut. 

Tukipalveluita ei huomioida menona, sillä ne sisältyvät perusosaan. Poikkeuksellisesti tukipalveluista aiheutuvia menoja voidaan asiakkaan pyynnöstä siirtää suoraan hyvinvointialueelle käsiteltäväksi. 
Kotipalvelu-termiä käytetään jatkossa enää lapsiperheiden kotipalvelusta, joka on jatkossa oma palvelunsa.
Jos asiakkaalle syntyy toimeentulotukioikeus, ohjaa asiakasta hakemaan asiakasmaksun alentamista tai perimättä jättämistä.
Lue lisää avo- ja laitospalvelut prosessista.
