###### 1.6.9.1.4.a Yrittäjän asumismenot
Jos yritystoimintaa harjoitetaan samassa asunnossa tai samalla kiinteistöllä, jolla yrittäjä itse asuu, on selvitettävä miltä osin asumiskustannukset kuuluvat yritystoiminnan menoihin. Siltä osin kuin asumiskustannuksissa on kyse yrityksen kustannuksista, ei niitä huomioida laskelmalla menona. Yritystoiminnan menoja voidaan vähentää vain yritystoiminnan tulosta harkittaessa yrittäjän käytettävissä olevien tulojen määrää.
 - Sähkö- ja vesilaskuista huomioidaan asiakkaan henkilökohtaisen asumisen osuus, eli yleensä Kelan sähkö- ja vesimaksunormin mukainen osuus.

 - Jos yritystoimintaa harjoitetaan samalla kiinteistöllä, huomioidaan kiinteistövero vain asuinkiinteistön osalta, jos muut rakennukset kuuluvat yrittäjätoimintaan. Jos kiinteistön verotus on määrätty yrityksen nimissä olevalla verotuspäätökselle, ei mitään osuutta verosta huomioida asiakkaan menona.

 - Jos yrittäjä yksin tai yhdessä toimeentulotukiperheensä kanssa omistaa yrityksestä vähintään 50 % ja asuu tämän yrityksen omistamassa asunnossa vuokralla, katsotaan kyseessä olevan omistusasunto eikä vuokramenoa huomioida menona laskelmalla. Asumismenot huomioidaan kuten muidenkin omistusasuntojen osalta. Lue lisää omistusasunnon menoista .

>ESIMERKKI: Niko harjoittaa elinkeinotoimintaa asuinkiinteistöllään. Nikon verotuspäätöksen mukaan kiinteistövero vakituiseen asuinkäyttöön tarkoitetun pientalon osalta on 200 euroa ja vapaa-ajan asunnon ja kasvihuoneen osalta 100 euroa. Laskelmalla voidaan huomioida menona 200 euroa kiinteistöveroa, joka on Nikon omaan kotiin liittyvä meno.

