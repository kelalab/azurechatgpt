#### 1.5.2.2 Muuttokustannukset
Yleensä asiakkaan tulee järjestää muutto omatoimimuuttona ja vain erityisestä syystä muuttoa voidaan tukea myöntämällä maksusitoumus muuttopalveluun.
Varastointipalvelu voidaan korvata vain tietyissä erityistilanteissa.
