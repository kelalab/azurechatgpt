###### 1.5.2.1.3.a Vuokravakuuden myöntäminen tuloylijäämätilanteessa
Poikkeustilanteissa vuokravakuus voidaan myöntää harkinnalla myös silloin, kun hakijan laskelma on tuloylijäämäinen. Kyse on aina yksilöllisestä ja tapauskohtaisesta harkinnasta ja asiakkaan kokonaistilanne on huomioitava. Harkinnassa tulee ottaa huomioon seuraavat asiat:
 - hakijan oma selvitys
 - hakijan tai perheen kokonaistilanne- ja tarpeet
 - ylijäämän määrän suhde vuokravakuuden määrään

