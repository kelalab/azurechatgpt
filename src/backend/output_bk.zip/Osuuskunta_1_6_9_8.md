#### 1.6.9.8 Osuuskunta
Osuuskunta on yritysmuoto, jonka tarkoituksena on tarjota jäsenilleen hyötyä sen palveluita käyttämällä. Osuuskunta on itsenäinen verovelvollinen ja kirjanpitovelvollinen. Osuuskunnan osuuksia ei voi myydä eteenpäin. Kun jäsen eroaa osuuskunnasta, saa hän osuusmaksunsa takaisin. Osuuskunnalla voi osuuksien lisäksi olla myös osakkeita, joita voi myydä ja ostaa vapaasti. Voittovaroja eli ylijäämää voidaan jakaa, jos siitä on merkintä osuuskunnan säännöissä. Jäsen voi erota osuuskunnasta milloin tahansa.
Kun kyseessä on jäsenyys osuuskunnassa, on tapauskohtaisesti tutkittava, tekeekö pelkkä jäsenyys asiakkaasta yrittäjän. Jos osuuskunnassa työskentelevällä asiakkaalla on tämän toiminnan vuoksi YEL-vakuutus, on kyseessä toimeentulotuen näkökulmasta yleensä yrittäjä. Jos sen sijaan asiakas on osuuskunnan jäsen ja työskentelee yrityksessä työntekijän lakisääteisellä työeläkevakuutuksella, on hän yleensä palkansaaja. Asiassa huomioidaan TE-palvelujen tulkinta tilanteesta.
Jos osuuskunnan jäsenenä olevan asiakkaan ei katsota olevan osuuskuntayrittäjä, voidaan osuusmaksua ja osuuskunnan osakkeita pitää helposti realisoitavana omaisuutena, joka on käytettävä asiakkaan omaan elatukseen. Kuitenkin jos osuusmaksu on vähäinen tai kyseessä on tavanomainen esimerkiksi elintarvikkeiden osuuskauppaan tai vesiosuuskuntaan kuuluva osuusmaksu, ei sen realisoimista edellytetä.
Osuuskunnan jäsenen tuloa voi esimerkiksi olla
 - starttiraha
 - palkat ja palkkiot
 - osuuspääoman korko
 - ylijäämän palautus
 - luontoisedut, kuten asunto-, auto-, puhelin- tai ateriaetu
 - varat jotka olisi mahdollista nostaa kyseisenä kuukautena palkkoina
 - yritystilin yksityiskäyttö
 - tavaroiden yksityiskäyttö
 - kohtuuttoman suuret kilometrikorvaukset ja päivärahat
 - lainat

Osuuskunnan jäsen ei voi tehdä yksityisottoja. Jos asiakas on kuitenkin tehnyt yksityisottoja, eli nostanut rahaa yrityksestä omaan käyttöönsä, huomioidaan ne ansiotulona laskelmalla.
Koska jäsen ei voi nostaa yrityksestä rahaa valintansa mukaan, eivät yrityksen rahavarat ole yleensä sellaisenaan yrittäjän käytettävissä. Arvioitaessa jäsenen mahdollisuuksia saada tuloja yrityksestään, tulee aina huomioida ovatko tulot tai varat tosiasiallisesti yrittäjän omaan elatukseen käytettävissä. Yrityksestä saatavissa olevat tulot ja varat ovat asiakkaan käytettävissä esimerkiksi silloin, kun hän
 - on saanut tuloja yrityksestä käyttöönsä,
 - on käyttänyt yritystiliä omiin henkilökohtaisiin menoihinsa tai
 - itse tai yhdessä toimeentulotukiperheensä kanssa voisi päättää yrityksen varojen jakamisesta.

Jos osuuskunnan omistus on hajautunut ja asiasta saadun selvityksen perusteella voidaan arvioida, että osuuskunnan olisi pitänyt pystyä juoksevien kulujen ja investointien jälkeen maksamaan osakkaille palkkaa, mutta palkkaa ei ole maksettu, pyydetään asiakkaalta kirjanpitäjän selvitys siitä, olisiko varoja voitu jakaa yrityksestä.
Osuuskunnan jäsenenä yritystoimintaa harjoittavalta voidaan pyytää esimerkiksi seuraavat selvitykset tulojen ja varojen selvittämiseksi
 - TO4-lomake
 - yritystoiminnan esitäytetty veroilmoitus
 - yrittäjän ja yrityksen tiliotteet
 - kuukausikohtainen kirjanpito
 - tilinpäätös
 - yrityksen perustamissopimus ja osuuskunnan säännöt varojen jakamisesta
 - kassavirtalaskelma käteisvaroista tai muu selvitys käteisvarojen määrästä ja käytöstä
 - kirjanpitäjän selvitys yrityksestä saaduista tuloista edelliseltä kuukaudelta, esimerkiksi palkat, luontoisedut
 - kirjanpitäjän selvitys siitä, olisiko varoja voitu jakaa yrityksestä.

Jos yrityksellä ei ole kirjanpitäjää, pyydetään asiakkaan oma selvitys vastaavista tiedoista.
