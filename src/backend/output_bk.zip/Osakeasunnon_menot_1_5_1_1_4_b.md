###### 1.5.1.1.4.b Osakeasunnon menot
Osakeasunnon huomioitavia menoja ovat:
 - hoitovastike, ylimääräinen vastike ja tontinvuokravastike
 - pääoma- tai rahoitusvastikkeesta osuus, jolla katetaan yhtiölainaosuuden korkomenoja
 - erilliset vesimaksut ja lämmitysmaksut
 - saunamaksu
 - henkilökohtaisen asuntolainan korot

Osakeasunnossa ei huomioida seuraavia menoja:
 - Pääoma- tai rahoitusvastikkeesta yhtiölainan lyhennykseen käytettävää osuutta

Rahoitus- tai pääomavastikkeen korko osoitetaan toimittamalla selvitys koron määrästä tai isännöitsijältä saatu selvitys, josta käy ilmi lainan kokonaismäärä, asiakkaan osuus lainoista sekä lainojen koron määräytyminen. Isännöitsijältä saadun selvityksen perusteella voidaan laskea kuukausittain huomioitavan koron määrä.
