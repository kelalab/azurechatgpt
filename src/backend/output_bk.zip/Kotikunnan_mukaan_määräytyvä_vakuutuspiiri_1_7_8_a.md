#### 1.7.8.a Kotikunnan mukaan määräytyvä vakuutuspiiri
Kelan etuusjärjestelmien toiminta pohjautuu henkilön toimistotietoon. Toimisto määräytyy yleensä henkilön väestötietojärjestelmän (VTJ) vakituisen asuinkunnan ja postinumeron mukaan.
