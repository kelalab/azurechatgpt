##### 1.6.5.5.a Palveluseteli ympärivuorokautisessa palveluasumisessa
Jos palveluseteli on myönnetty ympärivuorokautiseen palveluasumiseen tai perhehoitoon, selvitetään palvelua vastaavan asiakasmaksun suuruus, jos asiakas ei olisi ottanut palvelua vastaan, vaan palvelu olisi järjestetty hyvinvointialueen omana palveluna tai ostopalveluna. Selvityksestä on käytävä ilmi henkilökohtainen käyttövara. Kun henkilökohtainen käyttövara on selvillä, hakemus ratkaistaan ympärivuorokautisen palveluasumisen ohjeistuksen mukaisesti.
Lue lisää avo- ja laitospalvelut prosessista.
