## 1.1 Perustoimeentulotuki
Toimeentulotuki on viimesijainen sosiaalihuoltoon kuuluva taloudellinen tuki. Sen tarkoituksena on turvata henkilön ja perheen välttämätön toimeentulo sekä edistää itsenäistä selviytymistä. Toimeentulotuki on tarkoitettu lyhytaikaiseksi tueksi, ja sen tavoite on auttaa tilapäisten vaikeuksien yli tai ehkäistä sellaisten syntymistä. Toimeentulotuen myöntäminen edellyttää hakemista.
Toimeentulotuki koostuu perustoimeentulotuesta, täydentävästä toimeentulotuesta ja ehkäisevästä toimeentulotuesta. Kela vastaa perustoimeentulotuesta, joka muodostuu perusosasta ja muista perusmenoista. Hyvinvointialueet vastaavat täydentävästä ja ehkäisevästä toimeentulotuesta.
Jokaisella on oikeus saada perustoimeentulotukea, jos hän on tuen tarpeessa, eikä voi saada toimeentuloa
 - ansiotyöllään,
 - yrittäjätoiminnallaan,
 - toimeentuloa turvaavilla muilla etuuksilla,
 - muilla tuloillaan tai varoillaan,
 - häneen nähden elatusvelvollisen henkilön huolenpidolla tai
 - muulla tavalla.

Perustoimeentulotuen viimesijaisuudesta johtuen ennen tuen myöntämistä tulee selvittää henkilön ja perheen mahdollisuudet tulla toimeen omilla tuloillaan, varoillaan tai muilla tulonlähteillä. Lähtökohtana perustoimeentulotuen tarvetta arvioitaessa on, että jokaisella on kykynsä mukaan velvollisuus pitää huolta itsestään ja omasta elatuksestaan. Asiakkaan ja hänen perheensä kokonaistilanne tulee kartoittaa ja heitä tulee ohjata hakemaan ensisijaisia sosiaaliturvaetuuksia tai muita etuuksia. Asiakasta tulee neuvoa etuuksien hakemisessa. Asiakas ohjataan hyvinvointialueelle, jos hänen arvioidaan tarvitsevan myös sosiaalihuollon palveluita. Jos toimeentulotuen hakemuksen käsittelyn yhteydessä havaitaan, että asiakkaalla on haasteellinen elämäntilanne esimerkiksi terveyden, elämänhallinnan tai toimeentulon osalta, hän voi hyötyä Kelan muista palvelusta. Lue lisää sosiaalityön tarpeen arvioimisesta ja yhteydenotosta hyvinvointialueelle ja Kelan palveluista .
Perustoimeentulotuen määrä on toimeentulotukilaissa määriteltyjen menojen sekä käytettävissä olevien tulojen ja varojen erotus. Tuen myöntäminen tai hylkääminen edellyttää yleensä laskelman tekemistä. Henkilöllä tai perheellä voi tilanteesta riippuen olla oikeus täydentävään tai ehkäisevään toimeentulotukeen tai molempiin. Asiakkaalle tulee kertoa mahdollisuudesta hakea täydentävää tai ehkäisevää tukea hyvinvointialueelta.
Perustoimeentulotuessa voidaan huomioida vain Suomessa oleskelusta syntyneitä kuluja. Jos toimeentulotuen asiakas oleskelee osittain Suomessa ja osittain ulkomailla, oikeus toimeentulotukeen rajoittuu niihin kustannuksiin, jotka ovat aiheutuneet Suomessa oleskelusta. Ulkomailla syntyneisiin kustannuksiin ei myönnetä perustoimeentulotukea.
