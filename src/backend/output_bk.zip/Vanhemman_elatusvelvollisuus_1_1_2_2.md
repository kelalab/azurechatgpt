#### 1.1.2.2 Vanhemman elatusvelvollisuus
Vanhemmat vastaavat lastensa elatuksesta siihen asti, kunnes lapsi täyttää 18 vuotta. Poikkeuksen muodostaa alaikäisenä solmittu avioliitto, jonka johdosta vanhempien elatusvelvollisuus päättyy ja elatusvelvollisuus siirtyy aviopuolisolle.
Vanhempien elatuskyky tulee aina selvittää, jos toisesta tai molemmista vanhemmistaan erillään asuvalle alaikäiselle lapselle haetaan toimeentulotukea. Myös vuoroasuvan lapsen kohdalla vanhempien elatuskyky selvitetään riippumatta siitä, kenen luona lapsen väestörekisteritietoihin merkitty osoite on.
Lapsen elatuksesta ei tarvitse olla kunnan tai hyvinvointialueen toimielimen vahvistamaa sopimusta tai tuomioistuimen päätöstä, vaan riittävää on, että elatusvelvollinen tosiasiallisesti maksaa elatuskykyynsä nähden riittävää elatusapua lapselle. Jos lapsen elatuksesta on tehty sopimus tai annettu tuomioistuimen päätös, tulee se toimittaa Kelaan. Vanhemman tosiasiallisesti maksama elatusapu huomioidaan asiakkaan laskelmalla tulona riippumatta siitä, onko elatuksesta tehty sopimusta tai päätöstä. Lue myös elatuksen määrän arvioimisesta .
Jos lapsi asuu vain toisella vanhemmallaan ja lapsen kanssa asuva vanhempi hakee toimeentulotukea, tulee selvittää erillään asuvan vanhemman elatuskyky:
 - Asiakkaalle lähetetään ennen ensimmäisen päätöksen antamista kuulemiskirje, jossa: kysytään, osallistuuko lapsesta erillään asuva vanhempi lapsen elatukseen ja millä summalla sekä pyydetään asiakasta toimittamaan mahdollinen kunnan tai hyvinvointialueen toimielimen vahvistama sopimus tai tuomioistuimen päätös lapsen elatusavusta, ellei sitä ole jo toimitettu Kelaan.

 - Tämän jälkeen kuullaan tarvittaessa myös lapsesta erillään asuvaa vanhempaa siitä, osallistuuko hän lapsen elatukseen ja minkä verran hänellä on elatuskykyä.
 - Jos lapsesta on elatustukea maksussa puuttuvan elatuskyvyn vuoksi, ei vanhemman elatuskykyä yleensä tarvitse selvittää eikä suorittaa kuulemista.

Jos lapsi ei asu kummankaan vanhempansa luona, tulee nämä seikat selvittää molempien vanhempien osalta erikseen. Jos lapsi ei asu kummankaan vanhempansa luona, voi hän saada kaksi elatustukea maksuun.
Käytettävissä olevien tietojen perusteella arvioidaan, onko elatusvelvollisen maksaman elatuksen määrä riittävän suuri ottaen huomioon hänen elatuskykynsä vai laiminlyökö hän elatusvelvollisuutensa kokonaan tai osittain. Yleensä riittävä selvitys elatusvelvollisuuden täyttämisestä on elatusavun maksaminen vahvistetun elatussopimuksen tai tuomioistuimen päätöksen mukaisesti, paitsi jos:
 - lapselle ei ole vahvistettu maksettavaksi elatusapua muusta syystä, kuin puuttuvan elatuskyvyn vuoksi,
 - elatusapu on vahvistettu liian pieneksi elatusvelvollisen elatuskykyyn nähden tai
 - elatusavun vahvistamisen jälkeen vanhemman elatuskyky on suurentunut.

Jos erillään asuva vanhempi pystyisi osallistumaan lapsen elatukseen ja hän on tahallisesti laiminlyönyt elatusvelvollisuutensa kokonaan tai osittain, toimeentulotukipäätöksessä määrätään lapsen osuus myönnetystä toimeentulotuesta takaisinperittäväksi erillään asuvalta vanhemmalta. Vastaavasti jos molempien vanhempien voidaan katsoa tahallisesti laiminlyöneen elatusvelvollisuutensa, voidaan lapselle maksettua tukea periä molemmilta vanhemmilta takaisin. Tuki voidaan määrätä takaisinperittäväksi myös vuoroasuvan lapsen vanhemmalta.
Lue lisää takaisinperinnän perusteista , takaisinperintäprosessista ja elatusvelvollisuuden selvittämisestä.
