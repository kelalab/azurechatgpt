### 1.4.5 Alle 18-vuotiaan varallisuus
Alle 18-vuotiaan lapsen varoina ei oteta huomioon hänen varojaan siltä osin kuin ne ylittävät hänen osaltaan perusosan ja muut perusmenot. Lapsella ei ole velvollisuutta elättää vanhempiaan tai sisaruksiaan. Jos alaikäisellä on varoja, niistä otetaan varoina huomioon vain se osa, jonka katsotaan kattavan hänen osaltaan toimeentulotuessa huomioon otettavat menot. Lapsen menoina huomioidaan lapsen perusosa ja hänen muut perusmenonsa.
Yksinasuvalle lapselle tehdään oma laskelma ja laskelmalla huomioidaan lapsen varat kuten muidenkin alle 18-vuotiaiden osalta.
Vuoroasuva lapsi kuuluu kahteen toimeentulotukiperheeseen. Vuoroasuvan lapsen osalta lapsen nimissä olevat varat huomioidaan yleensä puoliksi kahden toimeentulotukiperheen laskelmilla.
Jos alle 18-vuotias on avioliitossa, hänen varansa huomioidaan kuten täysi-ikäisellä asiakkaalla.
Lue lisää alle 18-vuotiaan varallisuudesta .
Katso myös Alaikäinen , Vuoroasuminen ja Alle 18-vuotiaan lapsen tulojen huomioiminen.