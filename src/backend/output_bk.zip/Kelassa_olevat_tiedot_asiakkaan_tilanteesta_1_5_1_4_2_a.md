###### 1.5.1.4.2.a Kelassa olevat tiedot asiakkaan tilanteesta
Kohtuullisuusarvioinnissa selvitetään aina ensin, onko Kelassa sellaista tietoa, joka puoltaa asumiskustannusten huomioimista kokonaisuudessaan, esimerkiksi
 - terveydentilaan liittyvät selvitykset,
 - asiakkaan yhteydenotot,
 - sosiaalitoimen selvitys.

Lue lisää erityisten tarpeiden huomioimisesta .
Jos hakijalla tai perheellä on perusteltu syy asumisnormin ylittäville kustannuksille ja kustannukset eivät ole kohtuuttoman suuret, voidaan asumismenot hyväksyä kokonaisuudessaan niin kauan kuin hakijan tilanne pysyy ennallaan. Tilannetta tarkastellaan määräajoin uudelleen tilanteesta riippuen 3 – 12 kuukauden välein. Perusteltu syy voi olla liittyä esimerkiksi asiakkaan terveydentilaan tai toimintakykyyn.
>ESIMERKKI: Panu on vaimonsa Maijan omaishoitaja. Panu ja Maija ovat yli 80-vuotiaita ja asuvat hissillisessä kerrostalossa keskustan tuntumassa. Kelan yhteydenotoista selviää, että Panu hoitaa Maijan asioita ja käyttää Maijaa useamman kerran kuukaudessa lääkärissä. Heillä ei ole autoa ja Maija liikkuu rollaattorilla. Panun ja Maijan vuokra on 720 euroa, joka ylittää paikkakunnan kahden hengen asumisnormin 624 euroa noin 100 eurolla. Panun ja Maijan vuokrakustannukset voidaan huomioida kokonaisuudessaan, koska muuttaminen olisi heille kohtuuttoman raskasta heidän elämäntilanteensa huomioon ottaen ja muuttaminen halvempaan asuntoon voisi vaikeuttaa perheen kokonaistilannetta entisestään.

Jos asiakas on Kelan ohjauksesta huolimatta muuttanut kohtuullista tasoa kalliimpaan asuntoon, voidaan asumismenot kohtuullistaa heti ja määräaikaa ei näissä tilanteissa anneta.
