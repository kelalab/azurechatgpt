##### 1.6.7.8.3 EU/ETA- ja Sveitsin kansalaisten työntekijäaseman säilyminen
Jos hakija on EU/ETA-kansalainen, joka ei enää ole työntekijä, oleskelun tilapäisyyttä ei tarvitse tarkemmin selvittää, jos:
 - joutuu tilapäisesti työkyvyttömäksi sairauden tai tapaturman vuoksi.
 - yli vuoden työskenneltyään joutuu tahtomattaan työttömäksi ja on rekisteröity työnhakijaksi TE-toimistossa.
 - aloittaa ammatillisen koulutuksen, joka liittyy hänen aiempaan työskentelyynsä
 - aloittaa muun ammatillisen koulutuksen, jos on tahtomattaan työttömänä tai
 - Työntekijä, joka alle vuoden kestäneen määräaikaisen työsuhteen päätyttyä tai kahdentoista ensimmäisen kuukauden aikana joutuu työttömäksi tahtomattaan ja on rekisteröity työttömäksi työnhakijaksi, säilyttää työntekijäasemansa kuuden kuukauden ajan. Lue lisää kohdasta taloudellista toimintaa harjoittavat EU/ETA- kansalaiset ja Sveitsin kansalaiset ja heidän perheensä. 

Muissa tilanteissa on tehtävä tapauskohtainen kokonaisarvio oleskelun luonteesta . Oikeus kiireelliseen ja välttämättömään toimeentulotukeen tulee tarvittaessa aina turvata.
Katso myös työelämän ulkopuolella olevat EU/ETA-kansalaiset sekä vastaavat Sveitsin kansalaiset .
