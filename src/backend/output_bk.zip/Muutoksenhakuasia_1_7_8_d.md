#### 1.7.8.d Muutoksenhakuasia
Perustoimeentulotuen muutoksenhakuasian käsittelee Kelassa oikaisuvaatimuskeskus.
