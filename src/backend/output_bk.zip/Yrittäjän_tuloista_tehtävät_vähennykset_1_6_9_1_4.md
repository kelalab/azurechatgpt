##### 1.6.9.1.4 Yrittäjän tuloista tehtävät vähennykset
Toimeentulotukea ei ole tarkoitettu yritystoiminnan tukemiseen, eikä laskelmalla voida koskaan huomioida menona yritystoiminnasta aiheutuvia menoja. Sen sijaan, kun selvitetään minkä verran yrittäjä voisi käyttää yritystoiminnasta saatavissa olevia tuloja omaan elatukseensa, voidaan yritystulosta harkinnalla vähentää esimerkiksi seuraavia yritystoiminnan kuluja:
 - YEL- ja MYEL-vakuutusmaksut
 - arvonlisävero
 - maksettu yritystoiminnan ennakkovero
 - työntekijöiden palkat Palkanmaksu tulee kuitenkin selvittää luotettavasti, esimerkiksi pyytämällä palkkatodistuksia tai kirjanpitäjän selvitys maksetuista palkoista. Jos palkkoja ei ilmoiteta Verohallinnolle, ei kyse ole yritystulosta vähennettävästä palkkamenosta, vaan yksityisistä siirroista. Yksityisiä siirtoja ei voida huomioida yritystoiminnan tulon vähennyksinä.

 - toimitilan vuokra

Perustoimeentulotuessa hyväksyttävät vähennykset eivät voi olla määrältään suurempia kuin samasta yritystoiminnasta huomioitavat ansiotulot.
Yritystulosta tehtävät vähennykset kohdistetaan yleensä sille kuukaudelle, jona kyseinen kuluerä on maksettu. Jos rahat ovat yrittäjän omalla tilillä, tulee yritystoiminnan kulun olla jo maksettu, jotta sen voitaisiin katsoa vähentävän laskelmalla huomioitavan yritystulon määrää. Jos rahat ovat yrityksen tilillä, tulee arvioida minkä verran yrittäjä voisi nostaa tililtä rahaa itselleen omaan elatukseensa käytettäväksi. Yrityksen tilillä olevien varojen vähennyksenä voidaan harkinnalla huomioida sellaisia yritystoiminnasta aiheutuvia kuluja, jotka erääntyvät samassa kuussa maksettavaksi tai kulu on suuri ja erääntyy lähiviikkoina.
Velka ja sen hoitokulut eivät ole toimeentulotuessa huomioitavia menoja. Jos yrittäjä on velkaantunut yritystoiminnassaan siten, että toiminnan jatkaminen ei ole mahdollista, yrittäjä voidaan ohjata järjestelemään yritystoimintaansa kannattavammaksi tai lopettamaan se .
