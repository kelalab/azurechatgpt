#### 1.5.1.2 Asumismenot, joita ei huomioida
Perustoimeentulotukea ei myönnetä asuntovaunuun, telttaan, hotelliin, täysihoitolaan, yömajaan tai muihin majoitusliikkeisiin.
Toimeentulotuessa ei huomioida myöskään seuraavia asumismenoja:
 - kodinkoneisiin ja huonekaluihin liittyvät menoja
 - pyykkitupamaksua, joka kuuluu perusosaan
 - autopaikkamaksua, ellei autopaikan tarve johdu terveydellisistä syistä. Autopaikan tarpeellisuus voidaan osoittaa esimerkiksi vammaisen pysäköintiluvalla.

 - häkkikellarin tai vastaavien tilojen vuokraa
 - majoitussopimuksen perusteella syntyviä menoja
 - tiettyjä omakotitalon menoja, esimerkiksi pihanhoito ja lumityöt uudistamiseen, korjaamiseen tai uudisrakentamiseen liittyvät kustannukset asumiseen liittyvät investoinnit esimerkiksi lämmityskattilan tai öljysäiliön hankinta vesijohtoputkien rakentaminen

 - laajakaistamaksu Jos vuokraan kuuluu laajakaistamaksu, mutta laajakaistamaksun määrää ei ole eritelty esimerkiksi vuokrasopimuksessa, vuokra voidaan hyväksyä kokonaisuudessaan.

