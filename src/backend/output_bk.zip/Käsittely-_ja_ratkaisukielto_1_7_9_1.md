#### 1.7.9.1 Käsittely- ja ratkaisukielto
