#### 1.8.4.1 Edunvalvojalle tai edunvalvontavaltuutetuille
Perustoimeentulotuki voidaan maksaa edunvalvojalle, jos tuomioistuin tai holhousviranomainen on määrännyt tuen saajalle edunvalvojan hoitamaan taloudellisia asioita. Perustoimeentulotuki voidaan maksaa myös edunvalvontavaltuutetulle, kun edunvalvontavaltuutus on vahvistettu.
