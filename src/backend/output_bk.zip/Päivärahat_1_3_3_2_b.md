##### 1.3.3.2.b Päivärahat
Kohtuullisina pidettäviä päivärahoja ei huomioida tuloina. Jos päivärahat ovat kohtuuttoman suuret suhteessa ansiotuloon, ne voidaan huomioida kokonaan tai osittain tulona.
