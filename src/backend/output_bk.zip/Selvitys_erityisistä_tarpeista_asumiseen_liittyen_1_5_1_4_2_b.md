###### 1.5.1.4.2.b Selvitys erityisistä tarpeista asumiseen liittyen
Jos Kelassa olevista tiedoista ei käy ilmi erityisiä perusteita asumisnormin ylittäville asumismenoille, selvitetään asia hakijalta. Asumismenot voidaan huomioida kokonaisuudessaan, jos hakijalla on perusteet asumisnormin ylittäville kustannuksille.


Hakijaa kuullaan ensisijaisesti puhelimitse ja käydään läpi esimerkiksi
 - onko hänellä tai hänen perheenjäsenillään asumiseen liittyen erityisiä perusteita
 - hakijan kokonaistilanne
 - mitä kohtuullistaminen tarkoittaa hakijalle
 - mitä liitteitä tai selvityksiä hakijan tulee toimittaa Kelaan ja mihin mennessä
 - minkälaista asuntoa hakijan tulee etsiä, jos erityisiä perusteita ei ole
 - Kelassa määritellyt kuntakohtaiset asumisnormit ja mitä asumisnormeihin sisältyy

Hakija voi esittää perusteet korkeammille asumiskustannuksille puhelimitse.
 - Jos hakijalla on erityiset perusteet korkeammille asumiskustannuksille, voidaan asumiskustannukset huomioida päätöksellä kokonaisuudessaan.
 - Jos hakijalla ei ole erityisiä perusteita korkeammille asumiskustannuksille, annetaan hakijalle päätöksessä määräaika, jonka aikana hänen tulee etsiä edullisempaa asuntoa.

Tarvittaessa hakijalta pyydetään puhelimessa kirjallisia selvityksiä asumismenojen kohtuullisuusarvioinnin tueksi, esimerkiksi lääkärinlausunto terveydentilasta tai sosiaalitoimen selvitys asumistilanteesta. Tällöin asiakkaalle tehdään kuukauden päätös ja selvitykset pyydetään toimittamaan seuraavan hakemuksen liitteeksi. Hakijalle ei anneta päätöksellä määräaikaa edullisemman asunnon etsimiseen.
Jos asiakasta ei tavoiteta puhelimitse, asiakkaalle tehdään kuukauden päätös ja lähetetään lisäselvityspyyntö erityisistä perusteita ja pyydetään toimittamaan selvitys seuraavan hakemuksen liitteeksi. Hakijalle ei anneta päätöksellä määräaikaa edullisemman asunnon etsimiseen.
Jos hakija tai perhe esittää asumiseen liittyviä erityisiä perusteita, voidaan asumismenot huomioida kokonaisuudessaan joko määräaikaisesti tai toistaiseksi asiakkaan tilanteesta riippuen.
Harkintaan vaikuttavia erityisiä perusteita voivat olla esimerkiksi
 - lasten koulunkäyntimahdollisuudet
 - erityinen hoidon tarve
 - lasta tapaavan vanhemman tilan tarve tapaamisten vuoksi, kun tapaamisoikeus on vahvistettu kunnan toimielimen tai hyvinvointialueen vahvistamalla sopimuksella tai tuomioistuimen päätöksellä yleensä huomioidaan yksi lisähuone, jokaiselle lapselle ei voida huomioida omaa huonetta. Harkinnassa otetaan huomioon muun muassa lasten lukumäärä ja ikä sekä tapaamisten tiheys. 

 - vammaisen henkilön tarvitsemien apuvälineiden aiheuttama lisätilan tarve yleensä voidaan huomioida yhtä henkilöä suurempi asumisnormi katso yleisen asumistuen ohjeesta , milloin apuvälineet voivat aiheuttaa lisätilan tarvetta

 - yllättävä elämänmuutos esimerkiksi perheenjäsenen kuoleman vuoksi
 - hakijan tai perheenjäsenen terveydentilaan liittyvät tekijät tai muutoin alentunut toimintakyky
 - vammaispalvelulain mukaan tehdyt muutokset asunnossa
 - hakijan tai perheenjäsenen korkea ikä, yli 80 vuotias
 - hakijalla ei ole luottotietoja tai asunnon saaminen on muutoin haastavaa
 - kunnan järjestämä tuettu asumispalvelu esimerkiksi tukiasunto tai palveluasuminen

Lue lisää erityisiin tarpeisiin liittyvien selvitysten pyytämisestä .
