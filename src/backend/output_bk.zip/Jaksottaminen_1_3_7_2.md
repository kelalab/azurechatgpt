#### 1.3.7.2 Jaksottaminen
Jaksottamisessa tulo jaetaan eriin ja nämä erät otetaan kuukausittain tulona huomioon. Jos hakija saa tulon, josta hänen on mahdollista saada riittävä toimeentulo itselleen ja perheelleen pidemmäksi aikaa, jaetaan tulo niille kuukausille, joille sen voidaan kohtuudella katsoa riittävän hakijan ja tämän perheen elatukseen. Päätöksellä hakijalle kerrotaan, miten tulo on jaksotettu ja mihin saakka jaksotus kestää. Jaksotettavista eristä mahdollisesti syntyvää kuukausittaista tuloylijäämää ei vyörytetä seuraavalle kuukaudelle.
Jaksotettava tulo voi olla esimerkiksi
 - lomaraha
 - irtisanomisajankorvaus
 - muu suuri kertaluonteinen ansiotulo
 - takautuvasti maksettu etuustulo
 - pelivoitto
 - perintö
 - lahjoitus
 - kiinteistön tai auton myynnistä saatu myyntitulo

Jaksottamista käytetään myös esimerkiksi työttömyysetuuden ja opintolainan kohdalla.
Harkittaessa kuinka pitkälle ajalle tulon jaksottaminen on mahdollista, on otettava huomioon
 - jaksotettavan tulon suuruus ja maksuajankohta,
 - hakijan ja hänen perheensä kuukausittaiset menot sekä tulojen ja varojen määrät.

Jos hakija luotettavasti esittää käyttäneensä jaksotettavan tulon osittain tai kokonaan toimeentulotuessa hyväksyttäviin tarkoituksiin, ei tuloa siltä osin huomioida toimeentulotuen laskelmalla.
 
>ESIMERKKI: Jaakolle on myönnetty toimeentulotuki joulukuulle. Jaakko ilmoittaa saaneensa 15.12. perintönä 6 000 euroa. Jaakon toimeentulotuessa huomioitavat menot ovat noin 900 euroa kuukaudessa. Lisäksi tukioikeutta määritettäessä otetaan huomioon Jaakon kuukausittaiset tulot ja varat. Perustoimeentulotukea on maksettu Jaakolle kuukausittain noin 700 euroa. Perintönä saadun tulon voidaan katsoa turvaavan Jaakon toimeentuloa pidemmän aikaa. Päätöksessä Jaakolle kerrotaan, että saatu perintö 6 000 euroa on jaksotettu 1 200 euron eriin ja otetaan huomioon joulu-, tammi-, helmi-, maalis- ja huhtikuun laskelmilla. 

Lue lisää jaksottamisesta .
