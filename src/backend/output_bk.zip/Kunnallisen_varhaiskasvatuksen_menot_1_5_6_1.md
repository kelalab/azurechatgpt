#### 1.5.6.1 Kunnallisen varhaiskasvatuksen menot
Kunnan järjestämän varhaiskasvatuksen maksu voidaan jättää perimättä tai sitä voidaan alentaa siltä osin kuin maksun periminen vaarantaa henkilön tai perheen toimeentulon edellytyksiä tai henkilön elatusvelvollisuuden toteuttamista. Varhaiskasvatusmaksun alentaminen tai siitä vapauttaminen on ensisijaista toimeentulotukeen nähden. Jos asiakas hakee toimeentulotukea kunnallisen varhaiskasvatuksen maksuihin, tulee häntä ohjata välittömästi hakemaan kunnasta maksun alennusta tai vapautusta maksusta.
Varhaiskasvatusmaksu voidaan huomioida kokonaan menona laskelmalla hakemiskuukauden ja enintään sitä seuraavan kuukauden ajalta riippuen siitä, missä vaiheessa kuukautta toimeentulotukihakemus ratkaistaan. Asiakkaalta pyydetään seuraavan hakemuksen liitteeksi:
 - kunnan päätös maksun alentamisesta tai maksuvapautuksesta tai
 - tosite siitä, että maksun alentamishakemus on vireillä kunnassa.

Kun asiakas on toimittanut kunnan uuden maksupäätöksen, menot huomioidaan sen mukaisina.Jos asiakas ei kirjallisesta ohjauksesta huolimatta hae vapautusta tai alennusta maksuihinsa, maksuja ei tämän jälkeen huomioida menona.
