### 1.1.6 Muut perusmenot
Perusosalla katettavien menojen lisäksi voidaan muina perusmenoina huomioida:
 1. asumismenot
 2. omakotitalon välttämättömät hoitomenot
 3. välttämättömät muuttoon liittyvät menot
 4. taloussähkö ja lämmitysmenot
 5. kotivakuutusmaksu
 6. muut kuin perusosaan sisältyvät terveydenhuoltomenot
 7. lasten varhaiskasvatuksen menot
 8. koululaisten aamu- ja iltapäivätoiminnan menot
 9. lapsen tapaamisesta aiheutuvat menot
 10. tarpeellisen henkilötodistuksen, oleskeluasiakirjan tai matkustusasiakirjan hankintamenot

Muihin perusmenoihin kuuluvat menot huomioidaan tarpeellisen suuruisina. Asiakkaan tulee tarvittaessa esittää menoihin liittyvät selvitykset eli yleensä laskut. Menot huomioidaan todellisen suuruisina, jos ne eivät ole kohtuuttomia. Laskut huomioidaan menoina alkuperäisen eräpäivän mukaisesti kyseiselle kuukaudelle.
