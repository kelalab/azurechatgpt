###### 1.5.1.4.8.c Kotivakuutusmaksun kohtuullisuus
Katso kohtuulliset kotivakuutusmenot täältä .
Jos kotivakuutusmaksu
 - ylittää vähäisesti Kelan kohtuullisena pidetyn rajan, hyväksytään lasku kokonaisuudessaan.
 - ylittää huomattavasti kohtuullisen tason, selvitetään hakijalta ennen laskun käsittelyä, onko hänellä erityisiä perusteita kohtuullista tasoa korkeammille kustannuksille.

Jos menoa ei voida selvitysten perusteella hyväksyä kokonaisuudessaan tai selvitystä ei saada, kotivakuutusmaksu kohtuullistetaan Kelan normin mukaisiksi.
Jos autotallin ja piharakennuksien osuudet vakuutusmaksusta eivät ole erotettavissa, ne voidaan hyväksyä menoksi osana kotivakuutusmaksua, jos kohtuullisena pidetyn kotivakuutuksen määrä ei ylity.
