#### 1.7.2.1 Henkilö itse
18 vuotta täyttänyt
 - hakee etuutta yleensä itse
 - voi valtuuttaa toisen henkilön eli asiamiehen toimimaan puolestaan (esimerkiksi hakemaan etuutta)
 - voi itse hakea etuutta, vaikka hänelle olisi määrätty edunvalvoja ellei holhousviranomainen ole rajoittanut hänen toimintakelpoisuuttaan

 - on täysivaltainen, ellei holhousviranomainen edunvalvojan määrätessään ole julistanut häntä vajaavaltaiseksi vajaavaltaiseksi julistetun puolesta etuutta hakee edunvalvoja

Lue lisää etuuksien yhteisistä ohjeista:
 - valtuutukseen perustuva oikeus toimia päämiehen puolesta ,
 - asiamies ilman valtakirjaa, avustaja ,
 - alaikäisen puhevallan käyttäminen ,
 - edunvalvoja täysi-ikäiselle ja edunvalvontavaltuutus

Alle 18-vuotias
 - on vajaavaltainen ja hänen puolestaan toimeentulotukea hakee yleensä hänen kanssaan asuva vanhempi
 - voi kuitenkin hakea toimeentulotukea itse tai
 - toimeentulotukea voi lapsen puolesta hakea myös esimerkiksi lapsen huoltaja, muutoin hänestä tosiasiallisesti huolta pitävä henkilö, perhehoitaja, sosiaalitoimi tai edunvalvoja.

Kun on kyse alaikäisestä hakijasta, täytyy vanhempien elatusvelvollisuus selvittää.
