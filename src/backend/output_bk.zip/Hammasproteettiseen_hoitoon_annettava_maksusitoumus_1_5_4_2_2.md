##### 1.5.4.2.2 Hammasproteettiseen hoitoon annettava maksusitoumus
