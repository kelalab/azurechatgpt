#### 1.1.5.3 Perusosan alentaminen enintään 40 prosenttia
Uutta perusosan alentamista tulee edeltää uusi tai toistuva kieltäytyminen tai laiminlyönti.
Perusosan suuruutta voidaan alentaa enintään 40 prosenttia, jos 
 - asiakas sen jälkeen, kun hänen perusosaansa on alennettu enintään 20 prosentilla, menettelee edelleen tavalla, joka mahdollistaisi perusosan alentamisen edelleen enintään 20 prosentilla ja 
 - hän kieltäytyy ilman perusteltua syytä osallistumasta hyvinvointialueen sosiaalipalvelujen palvelutarpeen arviointiin. 

Perustoimeentulotuen perusosaa on mahdollista alentaa vain, jos kaikki alentamiselle asetetut edellytykset täyttyvät. 


