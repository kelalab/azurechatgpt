#### 1.3.5.c Pankkilaina ja muut lainat
Pankista nostettua lainaa ei oteta tulona huomioon. Poikkeuksena tästä on opintolaina , joka huomioidaan tulona. Pankkilainoista tai muista lainoista aiheutuvia korkomenoja tai lainan lyhennystä ei myöskään hyväksytä menoiksi. Katso lisää kohdasta asumisoikeusasunto .
Myöskään sosiaalista luottoa, takuusäätiön myöntämää pienlainaa tai muuta vastaavaa yhteisöltä tai yritykseltä saatua lainaa esimerkiksi pikavippi yritykseltä, ei huomioida tulona tai menona. Näistä edellytetään pääsääntöisesti velkakirjaa.
Yleensä yksityishenkilöltä otettu laina otetaan tulona huomioon. Jos hakija esittää velkakirjan ja lainan takaisinmaksu on todennettavissa etuusjakson aikana, voidaan laina jättää tältä osin tulona huomiomatta.

