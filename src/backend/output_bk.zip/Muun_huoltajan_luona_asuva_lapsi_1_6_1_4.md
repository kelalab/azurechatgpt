#### 1.6.1.4 Muun huoltajan luona asuva lapsi
Kunnan tai hyvinvointialueen toimielimen vahvistamalla sopimuksella voidaan sopia tai tuomioistuimen päätöksellä määrätä, että lapsi asuu muun huoltajansa, kuin oman vanhempansa luona. Lapsi ei kuitenkaan muodosta yhteistä toimeentulotukiperhettä muun huoltajansa kanssa. Lapselle tehdään oma laskelma, jossa huomioidaan:
 - tulona lapsilisä, elatusapu- ja tuki, lapselle kuuluvat eläkkeet sekä muut lapsen tulot, jos ne ovat maksussa lapsen tai muun huoltajan tilille,
 - lapsen käytettävissä olevat varat,
 - lapsen iän mukainen perusosa sekä
 - lapsen muut perusmenot.

Tarvittaessa lasta tai muuta huoltajaa ohjataan hakemaan lapsen etuudet itselleen maksuun. Vanhempien elatuskyky tulee aina selvittää. Lue lisää vanhemman elatusvelvollisuudesta .
Muulle huoltajalle voidaan huomioida yksinhuoltajan perusosa, jos hänellä ei ole puolisoa.
>ESIMERKKI: Niko on 15-vuotias ja asuu isoäitinsä Selman luona. Selma hakee molemmille toimeentulotukea ja kummankin toimeentulotuki ratkaistaan erikseen. Selman laskelmalla huomioidaan vain Selman tulot ja menot ja perusosaksi huomioidaan yksinhuoltajan perusosa. Nikolle tehdään oma laskelma, jolla huomioidaan vain Nikon tulot ja menot ja perusosaksi huomioidaan lapsen iänmukainen perusosa. Selman tilille maksettava Nikon lapsilisä huomioidaan Nikon laskelmalla tulona.

