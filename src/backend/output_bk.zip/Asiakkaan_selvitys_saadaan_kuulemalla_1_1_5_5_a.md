##### 1.1.5.5.a Asiakkaan selvitys saadaan kuulemalla 
Kun asiakasta kuullaan , hänelle annetaan mahdollisuus kertoa oma näkemyksensä syistä, joiden vuoksi perusosaa ei pitäisi alentaa tai se olisi kohtuutonta. Perusosan alentamiseen liittyvässä kuulemispyynnössä asiakkaalle on 
 - yksilöitävä laiminlyönti tai kieltäytyminen 
 - tiedotettava seurauksista, joita hänelle voi tulla kieltäytymisestä tai laiminlyönnistä ja 
 - informoitava alentamisen edellyttämästä kohtuullisuusharkinnasta. 

Lisäksi hakijaa kehotetaan ilmoittamaan Kelaan, jos hän on jo korjannut tilanteen, jonka perusteella perusosaa voitaisiin alentaa. 
Kun kyse on perusosan alentamisen harkinnasta, kuuleminen tehdään aina kirjallisesti. 
