#### 1.6.6.2 Opintolaina
Kela voi myöntää opintolainan valtiontakauksen opiskelijalle, joka saa opintorahaa tai aikuiskoulutustukea. Jos asiakas opiskelee korkeakoulussa ja saa opintorahaa, hän saa päätöksen opintolainan valtiontakauksesta automaattisesti. Jos asiakas opiskelee toisella asteella tai aikuiskoulutustuella, hänen on haettava lainatakausta.
Kela voi myöntää opintolainan lainatakauksen myös seuraavissa tilanteissa:
 - täysi-ikäinen, vanhempansa luona asuva opiskelija ei ole vanhempiensa tulojen vuoksi oikeutettu opintorahaan
 - opiskelijalla on maksuhäiriömerkintä
 - opiskelijan aiempi opintolaina on Kelan perittävänä jos opiskelija on tästä syystä saanut hylkäävän päätöksen lainatakauksesta, voi hän hakea lainatakauksen myöntämistä poikkeuksellisten syiden perusteella antamalla asiasta Kelalle selvityksen. Ohjeet selvityksen tekemiseen on annettu opintotukipäätöksen liitteenä.

Täysi-ikäisen päätoimisesti opiskelevan toimeentulotukea hakevan asiakkaan tulee aina hakea opintolainaa. Opintolainan hakemista edellytetään yleensä kaikilta, joilla on oikeus opintotukeen. Myös aikuiskoulutustuella opiskelevalta edellytetään opintolainan hakemista. Jos opiskelija ei ole hakenut opintolainan valtiontakausta ja opintolainaa, vaikka hän olisi voinut ne saada, voidaan laskennallinen opintolainan määrä yleensä ottaa huomioon tulona laskelmalla. Opintolainan korkoavustusta ei huomioida tulona.
