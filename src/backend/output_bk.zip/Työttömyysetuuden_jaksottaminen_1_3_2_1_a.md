##### 1.3.2.1.a Työttömyysetuuden jaksottaminen
Työttömyysetuus maksetaan yleensä 20 työttömyysetuuspäivän maksuerissä. Tästä johtuen pitkäaikaistyöttömälle tulee aina kerran vuodessa yksi sellainen kuukausi, jolloin saman kuukauden aikana maksetaan kaksi 20 työttömyysetuuspäivän maksuerää. Työttömyysetuutta maksetaan siis vuoden aikana keskimäärin 21,5 työttömyysetuuspäivältä kalenterikuukautta kohden.
Kun toimeentulotuen asiakkaalle on myönnetty oikeus työttömyysetuuteen, huomioidaan työttömyysetuus tosiasiallisesti maksetun yleensä 20 työttömyysetuuspäivän mukaisena siihen saakka, kunnes hakijalle maksetaan ensimmäisen kerran kaksi 20 työttömyysetuuspäivän maksuerää saman kuukauden aikana. Tämän jälkeen arvioidaan, voidaanko työttömyysetuuden osalta siirtyä tulon jaksottamiseen.
Työttömyysetuuden jaksottamisella tarkoitetaan sitä, että yhdeltä päivältä maksettava työttömyysetuuden määrä kerrotaan 21,5:lla Hakijalle tulee aina tiedottaa kertoimen käytöstä ennen työttömyysetuuden jaksottamisen aloittamista. Kerrointa ei ole mahdollista ottaa käyttöön jälkikäteen tarkistamalla.
Työttömyysetuus voidaan jaksottaa, jos
 - hakijalle on maksettu kaksi 20 työttömyysetuuspäivän maksuerää saman kuukauden aikana
 - hakijalle on tiedotettu kertoimen käytöstä ennen jaksottamisen aloittamista
 - toimeentulotukea on haettu sinä kuukautena, jona kaksi 20 työttömyysetuuspäivän maksuerää maksetaan. Jaksottamiseen ei vaikuta, onko toimeentulotukea tullut maksettavaksi kyseisenä kuukautena
 - hakija toimittaa työttömyysaikaa koskevan ilmoituksen työttömyysetuuteen myöhässä ja perustoimeentulotuen etuusjaksolle osuu kaksi 20 päivän työttömyysetuuden maksujaksoa

Työttömyysetuutta ei voida jaksottaa, jos
 - toimeentulotukea ei ole haettu sinä kuukautena, jona kaksi 20 työttömyysetuuspäivän maksuerää maksetaan eikä kerrointa ole jo aiemmin otettu käyttöön
 - hakija saa soviteltua työttömyysetuutta
 - hakijalle maksetaan työttömyysetuuden lisäksi osaeläkettä

Kun työttömyysetuuden jaksottaminen on aloitettu
 - työttömyysetuus huomioidaan tulona 21,5 työttömyysetuuspäivän mukaisena siitä etuusjaksosta alkaen, jolle kaksi 20 työttömyysetuuspäivän maksuerää sijoittuvat tai viimeistään kun perustoimeentulotukea seuraavan kerran ratkaistaan

 - kerrointa 21,5 käytetään johdonmukaisesti niin kauan kuin sama työttömyyskausi jatkuu eikä työttömyysturvatuloissa tapahdu muutoksia.
 - jaksottaminen jatkuu myös silloin, kun hakija saa seuraavan kerran kaksi 20 työttömyyspäivän maksukautta samassa kuussa.

Kertoimen käytöstä luovutaan, jos
 - työttömyysetuuteen tulee vähintään 30 vuorokauden katkos ja alkaa uusi työttömyysturvakausi.
 - Katkoksen jälkeen kertoimen käyttöön siirrytään uudelleen, kun toimeentulotuen hakijalle on maksettu kaksi 20 työttömyysetuuspäivän maksukautta saman kuukauden aikana. Katso myös alle 20 työttömyysetuuspäivän maksukausi .

>ESIMERKKI: Lauri on saanut perustoimeentulotukea tammikuusta alkaen. Hänellä on tulona työmarkkinatuki. Työmarkkinatuen kaksi 20 työttömyysetuuspäivän maksuerää maksetaan Laurille heinäkuussa, maksupäivät ovat 1.7. ja 29.7. Laurin työmarkkinatuki huomioidaan heinäkuusta alkaen kertoimella 21,5.

>ESIMERKKI: Millalle on myönnetty toimeentulotukea 27.3. annetulla päätöksellä ajalle 1.1. - 31.7. Millan tulona on työmarkkinatuki ja se on huomioitu laskelmilla tulona 20 työttömyysetuuspäivän mukaisena. Kun jatkohakemusta elokuulle ratkaistaan, huomataan, että Millalle on maksettu toukokuussa työmarkkinatukea kaksi 20 työttömyysetuuspäivän maksuerää. Kerroin 21,5 otetaan käyttöön elokuusta alkaen.

Lue lisää työttömyysetuuden jaksottamisesta .
