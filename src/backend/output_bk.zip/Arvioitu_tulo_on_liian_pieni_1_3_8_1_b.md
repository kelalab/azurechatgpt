##### 1.3.8.1.b Arvioitu tulo on liian pieni 
Jos arvio on ollut pienempi kuin tosiasiallisesti käytettävissä olleet ansiotulot, voidaan arvion ylittävät ansiotulot ottaa jälkikäteen tulona huomioon, jos toimeentulotukea haetaan päätöstä seuraavien kahden kuukauden aikana ja jollei sitä voida pitää kohtuuttomana. Mitään tuloa ei kuitenkaan voida huomioida kahteen kertaan, joten jos tulo on sisältynyt jo maksukuukauden arvioituun tuloon, ei kyseistä tuloa voida tältä osin huomioida enää seuraavana kuukautena tulona. Vain ylimenevä osa voidaan huomioida. 
 
>ESIMERKKI: Piialle on arvioitu huhtikuun laskelmalle ansiotuloksi 700 euroa. Kun Pia hakee toukokuulle toimeentulotukea ja huhtikuun kaikki ansiotulot ovat jo tiedossa huomataan, että hänelle on maksettu ansiotuloja huhtikuussa 1 500 euroa. Koska huhtikuun laskelmalla on huomioitu ansiotuloja vain 700 euroa, voidaan arvion ylittävä osuus 800 euroa huomioida toukokuun laskelmalla tulona. Lisäksi arvioidaan toukokuun ansiotulon määrä.  

 
 
>ESIMERKKI: Matille on arvioitu tammikuun tuloksi avustuksia 300 euroa. Kun Matti hakee helmikuulle toimeentulotukea, tammikuun kaikki tulot ovat jo tiedossa. Matti on saanut avustuksia tammikuussa tosiasiassa yhteensä 500 euroa. Tammikuun arvio oli liian pieni, joten arvion ylittävä osuus 200 euroa huomioidaan helmikuun laskelmalla tulona.  

 
Lue lisää tulon jälkikäteisestä huomioimisesta . 
Lue lisää arvioidun ansiotulon tarkistamisesta. 
