##### 1.6.9.10.c Porotalouden harjoittaja
Porotaloutta harjoitetaan paliskunnissa. Paliskunnat ovat kirjanpitovelvollisia. Poronhoitajat pitävät muistiinpanoja poronhoitotuloista ja menoista. Porotalouden harjoittajalla on yleensä MYEL-vakuutus toiminnalleen.
Porotalouden tuloa ovat esimerkiksi:
 - myyntitulot,
 - erilaiset tuet ja korvaukset liikennevahingoissa menehtyneistä poroista sekä korvaukset petovahingoista sekä
 - paliskunnan poronomistajalle maksamat työpalkat, kulukorvaukset sekä erilaiset palkkiot ja korvaukset.

Kuten muidenkin yritystoimintojen kohdalla, myös porotaloudesta saatavissa olevaa tuloa harkittaessa tulee vähentää yritystoiminnasta aiheutuneita menoja ennen tulon huomioimista yrittäjän ansiotuloksi.
TE-palvelut antaa työvoimapoliittisen lausunnon siitä, onko porotalouden harjoittaminen päätoimista. Joka tapauksessa kaikki porotaloudesta saatu omaan elatukseen käytettävissä oleva tulo huomioidaan laskelmalla tulona. Jos porotalouden harjoittaminen on kausiluonteista, voi asiakkaalla olla oikeus työttömyysturvaan toimintakauden ulkopuolella.
