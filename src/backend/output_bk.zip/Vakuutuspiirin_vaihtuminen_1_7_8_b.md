#### 1.7.8.b Vakuutuspiirin vaihtuminen
Jos henkilö muuttaa toiseen vakuutuspiiriin, vastuuyksikkötiedot muodostuvat etuusjärjestelmiin yleensä ohjelmallisesti. Lue lisää henkilön yleistietojen muutoksista .
Vakuutuspiirin tulee siirtää asiakasta koskevat vireillä olevat asiat uuteen vakuutuspiiriin käsiteltäviksi.
