#### 1.6.7.8 EU/ETA-kansalaiset

Pääsääntöisesti EU-/ETA-kansalaisten perustoimeentulotukioikeuden osalta sovelletaan ainoastaan toimeentulotukilain säännöksiä. Taloudellisesti aktiivisten EU-/ETA-kansalaisten osalta on kuitenkin huomioitava myös EU-oikeudellinen sääntely sekä Pohjoismaan kansalaisten osalta pohjoismainen sosiaalipalvelusopimus.
EU:n jäsenmaat ovat:
 - Alankomaat, Belgia, Bulgaria, Espanja, Irlanti, Italia, Itävalta, Kreikka, Kroatia, Kypros, Latvia, Liettua, Luxemburg, Malta, Portugali, Puola, Ranska, Romania, Ruotsi, Saksa, Slovakia, Slovenia, Suomi, Tanska, Tšekki, Unkari, Viro.

ETA-valtiot: EU:n jäsenmaat sekä Islanti, Liechtenstein, Norja.
