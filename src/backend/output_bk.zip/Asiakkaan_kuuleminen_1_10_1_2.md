#### 1.10.1.2 Asiakkaan kuuleminen
Asiakasta täytyy yleensä kuulla olosuhdemuutoksen vaikutuksesta perustoimeentulotukeen, jos hän ei ole itse ilmoittanut olosuhdemuutoksesta Kelalle ja jos muutos voi vaikuttaa vähentävästi etuuden määrään.
Asiakasta kuullaan esimerkiksi seuraavissa tilanteissa:
 - Kelaan on tullut asiakasta koskevia uusia tietoja ja selvityksiä, joiden vaikutuksesta hänellä ei ole tietoa ja jotka voivat johtaa etuuden lakkauttamiseen, hylkäämiseen joko kokonaan tai osittain tai muutoin voivat vaikuttaa asian ratkaisemiseen hänelle epäedulliseen suuntaan.
 - Asiakkaasta on ristiriitaisia selvityksiä, esimerkiksi eri etuuksia varten annetut tiedot poikkeavat toisistaan.

Kuulemista ei tarvitse tehdä, kun se olisi ilmeisen tarpeetonta tai siitä voisi aiheutua haittaa asiakkaalle. Asiakkaan kuuleminen ei ole välttämätöntä esimerkiksi seuraavissa tilanteissa:
 - tieto olosuhdemuutoksesta on tullut Kelaan asiakkaalta itseltään tai olosuhdemuutos käy ilmi asiakkaan Kelaan toimittamista liitteistä esimerkiksi tulotieto
 - asiakkaalle on myönnetty ensisijainen etuus
 - tieto on tullut Kelaan muun viranomaisen toimittamana esimerkiksi vero- ja tulorekisteritiedot
 - asiakas on toimittanut tarvittavan tiedon johonkin muuhun Kelan etuuteen
 - kuulemisesta aiheutuvat asian käsittelyn viivästyminen aiheuttaa huomattavaa haittaa ihmisten terveydelle esimerkiksi kiireellisen tuen tilanteet,
 - päätös tarkistetaan asiakkaan eduksi.

