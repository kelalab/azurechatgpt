##### 1.6.5.1.3 Pitkäaikainen ympärivuorokautinen palveluasuminen
Pitkäaikaista ympärivuorokautista palveluasumista (jatkossa ympärivuorokautinen palveluasuminen) järjestetään henkilöille, joilla hoidon ja huolenpidon tarve on ympärivuorokautista. Ympärivuorokautisesta palveluasumisesta hyvinvointialue perii tulosidonnaisen asiakasmaksun, joka kattaa asiakkaan saaman palvelun kokonaisuudessaan, mukaan lukien esimerkiksi ateriat.
Asiakkaalle jätetään asiakasmaksua määritettäessä käyttövara, jonka määrä on vähintään 167 euroa kuukaudessa vuonna 2023. Ympärivuorokautisessa palveluasumisessa asiakas maksaa käyttövarallaan esimerkiksi
 - mahdollisten kuljetusten omavastuuosuudet (vastaavat matkat, joiden katsotaan kuuluvan toimeentulotuen perusosaan muun muassa asiointimatkat kauppaan ja apteekkiin)
 - vaatteet
 - henkilökohtaisen hygienian
 - puhelimesta aiheutuvat kulut
 - muut mahdolliset kulut, jotka eivät sisälly palveluun.

Tulona perustoimeentulotuessa huomioidaan asiakasmaksupäätöksessä asiakkaan henkilökohtaiseen käyttöön varattu määrä, joka on vähintään 167 euroa vuonna 2023. Tulona huomioidaan myös esimerkiksi veronpalautukset tai muut vastaavat tulot, joita ei ole huomioitu asiakasmaksua laskettaessa.
Asiakkaan varallisuus huomioidaan laskelmalla varoina niin kauan kuin ne ovat tosiasiallisesti asiakkaan käytettävissä. Lue lisää kohdasta Varat .
Sosiaali- ja terveydenhuollon asiakasmaksulaissa on määritelty asiakkaan omaan käyttöön jätettävä vähimmäiskäyttövara. Perustoimeentulotuessa ympärivuorokautisessa palveluasumisessa olevan henkilön perusosaa vastaavana määränä pidetään sosiaali- ja terveydenhuollon asiakasmaksulaissa määriteltyä vähimmäiskäyttövaraa, joka on 167 e/kk vuonna 2023.
Asiakkaan laskelmalla voidaan huomioida menona muita perusmenoja (pois lukien asumismenot, jotka on vähennetty asiakasmaksupäätöksellä) esimerkiksi
 - sairaalalasku,
 - terveydenhuollon matkakulut,
 - lääkkeet tai
 - henkilöasiakirja.

Ympärivuorokautisessa palveluasumisen asumismenoja (esimerkiksi vuokra, sähkö ja kotivakuutus) ei huomioida perustoimeentulotuen laskelmalla menona, jos ne on vähennetty kokonaan asiakasmaksua määriteltäessä. Asumismenoista voidaan huomioida menona se osuus, jota ei ole vähennetty asiakasmaksupäätöksellä.
>ESIMERKKI: Salla on ympärivuorokautisessa palveluasumisessa. Sallan vuokra on 600 euroa sekä hänellä on 30 euron sähkölasku. Asumismenot Salla maksaa itse. Asiakasmaksupäätöksessä on asiakasmaksua määriteltäessä vähennetty vuokrasta 550 euroa sekä sähkömenosta 20 euroa. Asiakasmaksupäätöksellä on määritelty Sallan henkilökohtaiseksi käyttövaraksi 167 euroa. Perustoimeentulotuen laskelmalla huomioidaan tulona henkilökohtainen käyttövara 167 euroa. Asumismenoista voidaan huomioida menona se osuus, jota ei ole vähennetty asiakasmaksupäätöksellä. Menona huomioidaan Sallan vuokrasta 50 euroa ja sähkölaskusta 10 euroa sekä perusosaa vastaavana määränä 167 euroa.

Jos toinen avo- tai aviopuolisoista asuu kotona ja toinen on ympärivuorokautisessapalveluasumisessa, käytetään kotona asuvalla yksin asuvan perusosaa. Avo- tai aviopuolisoille tehdään erilliset päätökset.
Jos hakijan aviopuoliso on selvästi suurituloisempi, tulee aviopuolison elatuskyky selvittää. Jos molemmat aviopuolisot saavat toimeentulotukea, ei elatuskykyä yleensä ole eikä asiaa tarvitse selvittää enempää.
Jos asiakkaalle on myönnetty palveluseteli tehostettuun palveluasumiseen, katso myös palveluseteli ja asumismenot siirryttäessä avo- tai laitospalveluihin .
Lue lisää avo- ja laitospalvelut - prosessista. 
