#### 1.7.2.2 Lähiomainen tai muu henkilö
Lähiomainen tai muu henkilö, joka pääasiallisesti huolehtii henkilöstä, voi hakea toimeentulotukea toisen puolesta, kun
 - henkilö ei sairauden, vanhuuden tai muun sellaisen syyn takia itse pysty hakemaan etuutta ja
 - henkilöllä ei ole edunvalvojaa ja
 - kyseessä on tilapäinen asiointi, esimerkiksi hakemuksen vireille saattaminen ja
 - ei ole aihetta epäillä, ettei asiointi olisi asiakkaan tahdon mukaista.

Tällaisessa tilanteessa lähiomainen tai muu henkilö voi tehdä toimeentulotuen hakemuksen toisen puolesta, vaikka toimeentulotukilaissa ei ole tästä erikseen säännöstä. Tämä perustuu siihen, että toimeentulotuki on sosiaalihuoltoon kuuluva viimesijainen taloudellinen tuki ja olennaista on, että toimeentulotuen tarpeessa olevat saavat tukea.
Tällaisen henkilön ei tarvitse esittää valtakirjaa, vaan hänen esiintymisensä perustuu Kelan hyväksyntään.
Lue lisää miten lähiomainen tai muu päämiehestä huolehtinut henkilö voi käyttää puhevaltaa ja miten hyväksyminen kirjataan.
