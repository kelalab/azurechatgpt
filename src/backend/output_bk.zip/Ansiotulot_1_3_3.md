### 1.3.3 Ansiotulot
Toimeentulotuessa huomioidaan kaikki hakemiskuukauden aikana maksetut ansiotulot, joita ovat esimerkiksi
 - palkka,
 - palkkio (esimerkiksi kokouspalkkio, Teosto-palkkio, omaishoitajan, perhehoitajan tai kokemusasiantuntijan palkkio tai sijaisvanhemman hoitopalkkio),
 - osapalkkio sekä muu niihin rinnastettava korvaus tai rahasuoritus.
 - erilaiset lisät ja korvaukset (kuten ilta- ja yölisä, vuorotyölisä sekä lauantai- ja sunnuntaityölisä),
 - lomaraha,
 - lomakorvaus,
 - arkipyhäkorvaus,
 - osa luontoiseduista,
 - veronalaiset henkilökuntaedut,
 - työnantajan maksamat joulurahat ja lahjapalkkiot sekä tulospalkkiot.

Ansiotulona laskelmalla huomioidaan se määrä maksetusta palkasta, josta ei ole vähennetty tulonhankkimiskustannuksia. Katso myös ansiotuloista tehtävät vähennykset .
Myös työpaikalta tehdyt tavara- ja palveluostot, jotka on vähennetty palkasta, huomioidaan tulona ansiotulon maksukuukaudelle.
Palkkaennakko huomioidaan ansiotuloksi sille kuukaudelle, jona palkkaennakko maksetaan.
>ESIMERKKI: Pekalle on maksettu toukokuussa palkkaennakkoa 500 euroa säännöllisen kuukausiansiotulon lisäksi. Pekan tuloksi toukokuun laskelmalla huomioidaan säännöllisesti maksussa olevan ansiotulon lisäksi toukokuussa maksettu palkkaennakko 500 euroa.

Jos ansiotulon määrä vaihtelee, eikä hakemiskuukauden ansiotulon määrä ole tiedossa päätöstä annettaessa, ansiotulon määrä voidaan arvioida .
Jos hakijalla on etuusjakson aikana alkava työsuhde, eikä muita riittäviä tuloja tai varoja ole alkukuukaudesta, voidaan perustoimeentulotukioikeus ratkaista osalle kuukautta ensimmäiseen palkanmaksupäivään saakka. 
Jos ansiotulo ei ole ollut tiedossa toimeentulotuesta päätettäessä, katso tulon jälkikäteinen huomioiminen .
Katso myös miten alle 18- vuotiaan tuloja huomioidaan .
