#### 1.5.4.8 Hyvinvointialueen myöntämä palveluseteli yksityisen terveydenhuollon kustannuksiin
Palvelusetelillä tarkoitetaan hyvinvointialueen terveyspalvelujen saajalle myöntämää sitoumusta korvata palvelujen tuottajan antaman palvelun kustannukset hyvinvointialueen ennalta määrittelemään arvoon asti. Palveluseteli on yksi tapa järjestää hyvinvointialueen vastuulle kuuluvia terveyspalveluja.
Palvelusetelillä edistetään terveyspalveluiden käyttäjien valinnanvapautta ja mahdollisuuksia hankkia tarvitsemiaan palveluita hyvinvointialueen hyväksymiltä yksityisiltä palvelujen tuottajilta.
Hyvinvointialue päättää, ottaako se palvelusetelin käyttöön ja mihin palveluihin se antaa setelin. Palveluseteli on tarkoitettu kaikille terveyspalveluja tarvitseville. Setelin saaminen edellyttää, että hyvinvointialueen terveydenhuollon edustaja arvioi henkilön palvelun tarpeen. Jos asiakas tai potilas ei halua käyttää palveluseteliä, hyvinvointialueen on ohjattava hänet hyvinvointialueen muulla tavoin järjestämiin palveluihin.
Hyvinvointialueella on informointivelvoite suhteessa asiakkaaseen. Hyvinvointialueen on selvitettävä palveluseteliä myönnettäessä asiakkaalle tämän
 - asema palveluseteliä käytettäessä,
 - palvelusetelin arvo,
 - palvelun tuottajien hinnat,
 - omavastuuosuuden määräytymisen perusteet ja arvioitu suuruus sekä vastaavasta palvelusta lain mukaan määräytyvä asiakasmaksu.

Palvelusetelillä ostetusta palvelusta hyväksytään perustoimeentulotuessa menona se määrä, mitä palvelu olisi maksanut asiakkaalle hyvinvointialueen itse tuottamana eli julkisen palvelun asiakasmaksun osuus. Asiakkaan tulee toimittaa nämä tiedot Kelalle hakemuksen liitteenä. Jos asiakas käyttää palveluseteliä, laskussa tulee näkyä, mitä palvelua asiakas on käyttänyt esimerkiksi lääkärissä käynti.
