##### 1.6.9.1.1 Yrittäjän tulojen arvioiminen
Pääsääntö on, että tulot ja varat otetaan huomioon siltä ajanjaksolta, jolle toimeentulotuki määrätään. Yrittäjän tulot kuitenkin yleensä vaihtelevat kuukausittain ja yrittäjällä voi olla itsellään mahdollisuus vaikuttaa siihen, minkä verran tuloa hän yrityksestä kunakin kuukautena nostaa. Yrittäjän mahdollisuus nostaa yrityksestään tuloja vaihtelee yritysmuodon mukaan.
Jos yrittäjän tulot vaihtelevat vähäistä enemmän eikä riittävää selvitystä hakukuukaudelle tosiasiallisesti maksuun tulevista tuloista voida vielä päätöstä tehtäessä saada, voidaan yrittäjän tulot arvioida, jollei sitä voida pitää kohtuuttomana. Tulot voidaan arvioida ottaen huomioon esimerkiksi:
 - edellisten kuukausien aikana yrityksestä saadut ja saatavissa olleet tulot,
 - yrittäjän oma arvio tulojen määrästä,
 - yrittäjän antamat selvitykset, kuten kirjanpito ja tiliotteet,
 - mahdolliset olosuhdemuutokset, kuten toimintakauden loppuminen sekä
 - yrittäjän omat mahdollisuudet päättää siitä nostaako hän yrityksestä tuloja.

Kela tarkistaa arvioitujen tulojen määrän jälkikäteen, jos toimeentulotukea haetaan seuraavan kahden kuukauden aikana. Asiakkaan pyynnöstä arvio voidaan tarkistaa myöhemminkin. Jos vain osa kuukauden tuloista on arvioitu, tarkistetaan tulot vain arvioiduilta osin. Arvioitu tulo tarkistetaan seuraavasti:
 - Jos arvio on ollut liian pieni, huomioidaan arvion ylittävät yritystoiminnan tulot jälkikäteen kahden seuraavan kuukauden aikana tulona kuten muutkin ansiotulot .
 - Jos arvio on ollut liian suuri, tarkistetaan laskelma vastaamaan todellisia käytettävissä olleita tuloja, kun kaikki kyseisenä kuukautena maksetut tulot sekä nostettavissa olleet yrityksen varat ovat tiedossa. Laskelmaa ei tarkisteta, jos yrittäjällä olisi ollut mahdollisuus nostaa yrityksestä itselleen tuloja, vaikka hän ei ole niitä omasta valinnastaan nostanut. Tällöin tulojen voidaan yleensä katsoa olleen yrittäjän käytettävissä.

>ESIMERKKI: Samille on arvioitu tammikuun laskelmalle yritystoiminnan tuloksi 1000 euroa, koska hän on edeltävinä kuukausina nostanut noin 1000 euroa palkkaa yrityksestään. Sami omistaa 100% osakeyhtiöstä ja voi siten itse päättää palkan maksusta. Sami hakee helmikuussa tarkistusta tammikuun päätökseen ja toimittaa tiliotteet, joiden mukaan hän ei ole nostanut lainkaan palkkaa yrityksestään. Yrityksen tammikuun tiliotteilla nähdään kuitenkin 5000 euroa tilivaroja, joista Sami olisi omalla päätöksellään voinut maksaa itselleen palkkaa. Samin tammikuun laskelmaa ei tarkisteta, sillä Sami olisi voinut nostaa 1000 euroa palkkaa.

