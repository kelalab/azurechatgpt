#### 1.7.1.a Hakemus sähköisesti OmaKelan kautta
Asiakas saa asian vireille täyttämällä hakemuksen OmaKelassa. Asiakkaan on tällöin tunnistauduttava joko pankin verkkotunnuksilla, mobiilivarmenteella tai sähköisen henkilökortin avulla. OmaKelan kautta jätetyistä hakemuksista lähtee automaattinen vastaanottokuittaus asiakkaalle.
Asiakas voi saada asian vireille myös lähettämällä viestin OmaKelassa.
Tutustu verkkoasiointiin Kelassa .
