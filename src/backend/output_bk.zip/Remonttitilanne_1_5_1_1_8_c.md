###### 1.5.1.1.8.c Remonttitilanne
Vuokralaisella on yleensä oikeus saada vapautus vuokran maksamisesta tai vuokran alennusta siltä ajalta, jolta huoneistoa ei voi käyttää tai jolta huoneisto ei ole ollut vaadittavassa tai sovitussa kunnossa. Hakijaa ohjataan hakemaan vapautusta vuokranmaksusta vuokranantajalta, jos toimeentulotukea haetaan tilapäiseen asuntoon.
Jos asiakas ei voi saada vapautusta vuokranmaksusta tai asiakas asuu omistusasunnossa ja kysymyksessä on perusteltu ja välttämätön remontti, asumismenoja voidaan korvata sekä vakituiseen asuntoon että tilapäiseen asuntoon remontin ajan. Vahinkotilanteessa asiakasta ohjataan ensisijaisesti hakemaan korvausta kotivakuutuksesta
Perusteltu ja välttämätön remontti voi olla esimerkiksi
 - taloyhtiön putkiremontti
 - vesivahingosta tai homevauriosta johtuva remontti
 - terveydellisistä syistä johtuva remontti

Remontista tai terveydellisistä syistä tarvitaan yleensä luotettava selvitys. Jos varsinainen asunto osoittautuu asuinkelvottomaksi, perustoimeentulotukea ei myönnetä kyseisen asunnon asumismenoihin.
