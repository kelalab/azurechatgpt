##### 1.3.3.3.b Autoetu
Jos auto on välttämätön työssäkäynnin kannalta ja autoetu on määrältään kohtuullinen suhteessa hakijan rahapalkkaan, voidaan autoetu jättää huomioimatta tulona. Jos autoetu on suuri suhteessa rahapalkkaan tai autoedun määrä ylittää rahapalkan määrän, pyydetään hakijaa toimittamaan työnantajan selvitys, josta selviää:
 - Onko mahdollisuutta vaihtaa autoetu edullisempaan?
 - Onko mahdollisuutta luopua autoedusta?
 - Onko mahdollisuutta käyttää työajoihin työnantajan autoa autoedun sijaan?

Jos hakija ei voi vaihtaa autoetua edullisempaan ja työnantaja ei mahdollista muita vaihtoehtoja, voidaan autoetu jättää harkinnalla huomioimatta tulona. Jos autoetu ei ole välttämätön hakijan työssäkäynnin kannalta tai hakija ei toimita selvitystä työnantajalta, voidaan autoetu ottaa ansiotulona huomioon.
