##### 1.5.1.4.2 Asumismenot ylittävät Kelan asumisnormin
Asumismenot voidaan ylityksestä huolimatta hyväksyä kokonaisuudessaan, jos
 - asumismenot ylittävät vähäisesti, noin 5 %:lla, Kelan asumisnormin,
 - hakija asuu kunnan järjestämässä asunnossa, jossa hakijalle tarjotaan hänen elämäntilannettaan tukevia palveluita tai
 - hakija asuu jo kunnan vuokra-asunnossa ja asunto on kooltaan sopiva. Tällöin tulee tapauskohtaisesti arvioida, onko hakijalla mahdollista löytää edullisempaa asuntoa kyseisestä kunnasta.

Jos ylitystä ei voida pitää vähäisenä, on arvioitava kustannusten kohtuullisuutta ja tarpeellisuutta.
>ESIMERKKI: Nella asuu yksin vuokralla. Nellan vuokra on 510 euroa kuussa. Nellan vuokra ylittää paikkakunnan yhden hengen normin 478 euroa noin 30 eurolla. Nellan vuokra voidaan huomioida kokonaisuudessaan, sillä asumismenot ylittävät vähäisesti asumisnormin.

>ESIMERKKI: Lasse on ollut asunnoton. Lasse on saanut kunnan järjestämän tukiasunnon. Lasse tarvitsee ohjausta raha-asioiden hoitamisessa ja kodinhoidossa sekä tukea jokapäiväiseen elämään liittyvissä toimissa. Lassen vuokra on 800 euroa kuussa ja vuokra ylittää kunnan yhden hengen normin 100 eurolla. Lassen vuokra voidaan huomioida kokonaisuudessaan, sillä Lasselle tarjotaan hänen elämäntilannettaan tukevia palveluja.

>ESIMERKKI: Antti ja Maija asuvat kunnan vuokra-asunnossa, joka on pieni kolmio. Heidän vuokransa ylittää paikkakunnan kahden hengen normin noin 40 euroa. Käsittelyn yhteydessä selvitetään, että kunnasta ei ole mahdollista löytää edullisempaa asuntoa. Antin ja Maija vuokra voidaan huomioida kokonaisuudessaan, sillä he asuvat kunnan vuokra-asunnossa.

