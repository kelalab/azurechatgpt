#### 1.6.3.2 Hakijalla tai perheenjäsenellä ei ole päätöstä kuolinkuukaudelle

