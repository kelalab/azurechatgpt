##### 1.6.5.1.4 Pitkäaikainen perhehoito
Pitkäaikaisella perhehoidolla (jatkossa perhehoito) tarkoitetaan henkilön hoidon tai muun osa- tai ympärivuorokautisen huolenpidon järjestämistä perhehoitajan yksityiskodissa tai hoidettavan kotona.
Perhehoidosta hyvinvointialue perii tulosidonnaisen asiakasmaksun, joka kattaa asiakkaan saaman palvelun kokonaisuudessaan, mukaan lukien esimerkiksi ateriat.
Perhehoito huomioidaan perustoimentulotuessa samalla tavalla kuin ympärivuorokautinen palveluasuminen. Lue lisää pitkäaikaisesta ympärivuorokautisesta palveluasumisesta .
Pitkäaikaisen perhehoidon ohje ei koske:
 - lastensuojelun perhehoitoa
 - kehitysvammaisten erityishuollon perhehoitoa
 - vammaisuuden perusteella järjestettäviä perhehoidon palveluja ja tukitoimia
 - perhehoitoa, joka järjestetään lääkinnällisenä kuntoutuksena laitoksessa.

Näiden osalta tulee selvittää tarkemmin miltä osin perhehoidon menoja voidaan huomioida perustoimeentulotuessa muina perusmenoina. Tarvittaessa pyydetään erittelyt palveluun liittyvistä menoista, jos ne eivät selviä asiakasmaksupäätökseltä.
