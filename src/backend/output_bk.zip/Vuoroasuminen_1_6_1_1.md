#### 1.6.1.1 Vuoroasuminen
Jos lapsi vuoroasuu molempien vanhempiensa luona, katsotaan lapsen kuuluvan molempien vanhempiensa toimeentulotukiperheeseen puoliksi. Vuoroasumisesta tulee olla sovittu 
 - kunnan tai hyvinvointialueen vahvistamalla sopimuksella, 
 - tuomioistuimen päätöksellä tai 
 - vanhempien kesken. 

 
Vuoroasuvan lapsen perusosa jaetaan vanhempien kesken ja lapsen tulot ja varat huomioidaan pääsääntöisesti puoliksi kummankin toimeentulotukiperheen laskelmalla. Lapsen menoja voidaan huomioida kummallekin vanhemmalle, ei kuitenkaan päällekkäisiä kuluja. Kummallekin vanhemmalle voidaan huomioida perusosaksi yksinhuoltajan perusosa, jos heillä ei ole puolisoita. Katso myös lapsen tulojen ja varojen huomioiminen vuoroasumisessa.
>ESIMERKKI: Timo hakee toimeentulotukea itselleen ja vuoroasuvalle 7-vuotiaalle lapselleen Neealle. Timon laskelmalla huomioidaan Neean iänmukaisesta perusosasta puolet ja Timolle huomioidaan yksinhuoltajan perusosa.

Myös silloin, jos lapsen tapaamisesta on edellä mainituin tavoin sovittu tai määrätty siten, että lapsi tapaa erillään asuvaa vanhempaansa vähintään 40 % ajasta, on kyseessä lapsen toimeentulotuentarpeen kannalta yleensä vuoroasuminen. Harkittaessa voidaanko lapsen katsoa asuvan kahdessa kodissa, otetaan huomioon esimerkiksi seuraavat seikat:
 - tapaamisten paikka sekä
 - yöpymisten määrä lapsen kanssa erillään asuvan vanhemman luona.

Vuoroasumisessa lapsen tapaamiskustannuksia eli lapsen ruokarahaa tai matkakuluja ei huomioida menona, koska lapsi asuu molempien vanhempiensa kanssa samassa taloudessa. Vuoroasuva lapsi huomioidaan sen sijaan korottavasti molempien perheiden asumisnormia valittaessa.
>ESIMERKKI: Leo on 5 –vuotias lapsi ja hän vuoroasuu vanhemmillaan Nooralla ja Samilla. Noora hakee toimeentulotukea itselleen ja Leolle. Nooralle huomioidaan 2 henkilön asumisnormin mukaiset asumismenot. Sami hakee toimeentulotukea itselleen, uudelle puolisolleen Lauralle sekä Leolle. Samille huomioidaan 3 henkilön asumisnormin mukaiset asumismenot.

Vuoroasuvan lapsen kohdalla vanhempien elatuskyky selvitetään riippumatta siitä, kenen luona lapsen väestörekisteritietoihin merkitty osoite on. Se vanhempi, jolla on suurempi elatuskyky, voidaan velvoittaa suorittamaan lapselle elatusapua, vaikka kumpikin vanhempi vuorollaan huolehtisi lapsen jokapäiväisestä elatuksesta yhtä laajasti ja he muutenkin suorittaisivat yhtä suuren osuuden lapsen elatuksesta aiheutuvista kustannuksista. Lue lisää vanhemman elatusvelvollisuudesta .
Lue lisää vuoroasumisesta .
