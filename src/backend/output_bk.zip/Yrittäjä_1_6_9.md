### 1.6.9 Yrittäjä
Toimeentulotuessa yrittäjänä pidetään esimerkiksi asiakasta, joka omistaa riittävän suuren osuuden yrityksestä, jossa hän työskentelee. Yrittäjänä pidetään myös esimerkiksi laskutuspalvelun kautta itsensä työllistäviä henkilöitä sekä omassa työssä työllistyviä. Yrittäjänä pidetään myös henkilöä, joka on TE-palveluiden työvoimapoliittisen lausunnon mukaan yrittäjä. Katso tarkemmin yrittäjän määrittelemisestä kunkin yritysmuodon kohdalta:
 - omassa työssä työllistyvät
 - laskutuspalveluyrittäjä
 - yksityinen elinkeinonharjoittaja
 - avoin yhtiö ja kommandiittiyhtiö
 - osakeyhtiö
 - osuuskunta
 - yhtymät ja kuolinpesän kautta harjoitettu yritystoiminta
 - maatalousyrittäjät, metsäyrittäjät ja poronhoitajat 

Yritystoiminnasta saatava tulo on ensisijainen tulonlähde toimeentulotukeen verrattuna. Jos asiakas toimii yrittäjänä, tulee selvittää
 - mitä tuloja ja varoja hänellä on tosiasiallisesti käytettävissä omaan ja perheensä elatukseen,
 - miltä osin kyse on yrityksen varallisuudesta, jota ei voida huomioida yrittäjän toimeentulotuen tarvetta laskettaessa sekä
 - onko yrittäjä edellisinä kuukausina saanut riittävästi toimeentuloa yrityksestä ja voidaanko yrittäjän katsoa jatkossa voivan turvata elatuksensa yritystoiminnallaan.

Yritysmuoto ja yrityksestä omistetun osuuden suuruus vaikuttavat siihen, millaiset mahdollisuudet yrittäjällä on itse päättää nostaako hän tuloja yrityksestä.
Selvästi kannattamatonta yritystoimintaa harjoittavan yrittäjän toimeentuloa ei ole tarkoituksenmukaista pitkäaikaisesti turvata toimeentulotuella. Jokaisella on velvollisuus kykynsä mukaan pitää huolta itsestään ja omasta elatuksestaan ja jos yrittäjä harjoittaa pitkäaikaisesti toimeentulotuen turvin kannattamatonta yritystoimintaa, voidaan yrittäjän perusosan alentamista harkita. Lue lisää kannattamattomasta yritystoiminnasta .

