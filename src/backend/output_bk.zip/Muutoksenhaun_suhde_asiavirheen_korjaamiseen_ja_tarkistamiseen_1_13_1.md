### 1.13.1 Muutoksenhaun suhde asiavirheen korjaamiseen ja tarkistamiseen
Ennen kuin asiakasta ohjataan tekemään oikaisuvaatimus, on selvitettävä, voidaanko päätös korjata tai tarkistaa vakuutuspiirissä. Päätös voidaan korjata tai tarkistaa oikaisuvaatimuksesta riippumatta ja oikaisuvaatimuksen vireillä olon aikana. Oikaisuvaatimuskeskus huomioi asian omassa päätöksessään tai välittää tiedon hallinto-oikeudelle.
Välittömästi korjattavia tai tarkistettavia tilanteita ovat esimerkiksi:
 - selkeät virheet
 - tilanteet, joissa päätös on tehty puutteellisten tietojen perusteella
 - päätöksen antamisen jälkeen tapahtunut olosuhdemuutos

Virheet on korjattava tai päätös tarkistettava välittömästi käsittelyajasta riippumatta. Lue lisää päätöksen tarkistamisesta ja korjaamisesta .
