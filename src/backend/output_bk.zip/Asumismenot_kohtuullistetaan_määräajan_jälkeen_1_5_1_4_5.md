##### 1.5.1.4.5 Asumismenot kohtuullistetaan määräajan jälkeen
Asumismenot kohtuullistetaan vastaamaan Kelan asumisnormia, jos hakija esimerkiksi
 - ilmoittaa, että hän ei aio etsiä edullisempaa asuntoa tai muuttaa asunnosta
 - kieltäytyy vastaanottamasta hänelle tarjotun edullisemman asunnon
 - ei toimita selvitystä aktiivisesta edullisemman asunnon etsimisestä

Jos hakija toimittaa oman selvityksen, jonka mukaan kunnassa ei ole tarjolla hänen tarpeitaan vastaavaa kohtuuhintaista asuntoa, tarkistetaan kunnan asuntotilanne vuokra-asuntoja tarjoavista palveluista ja tarvittaessa kunnan vuokrataloyhtiöstä tai sosiaalitoimesta. Jos kunnassa on tarjolla edullisempia asuntoja, kohtuullistetaan asumismenot.
Kohtuullistamistilanteissa voi olla tarpeen olla yhteydessä kuntaan asiakkaan sosiaalihuollon tarpeesta.
Asumismenojen kohtuullistaminen voidaan tehdä määräajan jälkeen, vaikka välissä olisi katkos perustoimeentulotukiasiakkuudessa, jos asiakkaan elämäntilanne ei ole muuttunut.
>ESIMERKKI: Jenniä on kehotettu joulukuun päätöksessä etsimään edullisempaa asuntoa ja hänelle on annettu määräaika maaliskuun loppuun. Jenni ei ole hakenut toimeentulotukea ajalla 1.1.-31.3. Jenni hakee toimeentulotukea huhtikuulle. Hän ei ole muuttanut halvempaan asuntoon, eikä esittänyt selvityksiä edullisemman asunnon etsimisestä. Jenni ei toimita Kelaan pyydettyjä selvityksiä. Jennin asumismenot voidaan kohtuullistaa 1.4. alkaen.

