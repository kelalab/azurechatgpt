#### 1.6.9.10 Maatalousyrittäjät, metsäyrittäjät ja poronhoitajat
