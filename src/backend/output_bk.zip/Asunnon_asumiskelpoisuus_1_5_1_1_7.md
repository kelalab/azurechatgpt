##### 1.5.1.1.7 Asunnon asumiskelpoisuus
Jos asuntoa ei ole tarkoitettu vakinaiseen asuinkäyttöön, tulee harkita, voidaanko asunnon katsoa soveltuvan vakinaiseen asumiseen. Jos hakijalla on vuokrasopimus ja hänellä on asunnosta esimerkiksi vuokra-, vesi-, sähkö- ja/tai lämmityskuluja, voidaan ne yleensä huomioida menona, jos asunto soveltuu vakinaiseen asumiseen.
Harkinnassa on otettava huomioon seuraavia asioita:
 - Millaisesta asumismuodosta on kysymys esimerkiksi vapaa-ajan asunto, mökki
 - Mikä on asunnon varustelutaso, onko asunnossa esimerkiksi ruuanlaittomahdollisuus, peseytymis- ja WC-tilat?
 - Soveltuuko asunto ympärivuotiseen käyttöön?
 - Onko asunto yksinomaan hakijan käytettävissä?

>ESIMERKKI: Erkki asuu liikehuoneiston yhteydessä olevassa vuokra-asunnossa. Erkki esittää Kelalle vuokrasopimuksen ja selvityksen siitä, että asunnossa on liiketilasta erillinen keittiö, vessa ja peseytymistilat. Erkin vuokra voidaan hyväksyä menona toimeentulotuen laskelmalla. Erkki esittää lisäksi koko liikehuoneisto koskevan sähkölaskun. Koska sähkölaskusta ei ole eriteltävissä, mikä on Erkin osuus sähkön kulutuksesta, sähkölaskua ei voida hyväksyä menona.

>ESIMERKKI: Taina on jäänyt asunnottomaksi ja hän kertoo hakemuksella, että asuu sukulaisen mökillä, jossa ei ole sähköjä tai juoksevaa vettä. Juomavettä saa kaivosta ja saunatiloihin tulee vesi järvestä. Taina on tehnyt sukulaisen kanssa vuokrasopimuksen ajalle 1.6.-31.12 ja esittää perustoimeentulotukeen vuokramenoksi 300e/kk. Vuokrameno voidaan harkinnalla huomioida menona ottaen huomioon Tainan kokonaistilanne määräaikaisen vuokrasopimuksen ajalta.

