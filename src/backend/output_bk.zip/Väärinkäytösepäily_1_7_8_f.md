#### 1.7.8.f Väärinkäytösepäily
Useimmiten epäily väärinkäytöksestä syntyy liikamaksun havaitsemisen yhteydessä. Kelan maksamaan etuuteen kohdistuvan väärinkäytösepäilyn selvittäminen aloitetaan Kelan vakuutuspiirissä. Useamman vakuutuspiirin alueella tehdyksi epäillyn väärinkäytöksen selvittämisestä neuvotellaan asianomaisten vakuutuspiirien kesken. Yhteisten palvelujen Lakipalveluryhmän asiantuntija päättää tutkintapyynnön tekemisestä tai päättää siitä, että tutkintapyyntöä ei kyseessä olevassa tapauksessa tehdä.
Lue lisää:
Tietojenanto ja ilmoitusvelvollisuus 
Väärinkäytösepäilyn tunnistaminen
Väärinkäytökset
