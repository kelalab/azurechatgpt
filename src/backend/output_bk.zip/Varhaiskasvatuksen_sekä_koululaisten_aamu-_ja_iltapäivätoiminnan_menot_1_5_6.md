### 1.5.6 Varhaiskasvatuksen sekä koululaisten aamu- ja iltapäivätoiminnan menot
Lasten varhaiskasvatuksesta sekä koululaisten aamu- ja iltapäivätoiminnasta aiheutuvia menoja voidaan ottaa tarpeellisen suuruisena huomioon laskelmalla. Toimeentulotukeen nähden ensisijainen keino on kuitenkin kunnan mahdollisuus jättää tällaiset maksut perimättä tai alentaa niitä.
