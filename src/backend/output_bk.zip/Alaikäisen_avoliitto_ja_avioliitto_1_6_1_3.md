#### 1.6.1.3 Alaikäisen avoliitto ja avioliitto
Jos alaikäinen asuu avoliitossa toisen henkilön kanssa, eivät he muodosta yhteistä toimeentulotukiperhettä ennen kuin molemmat osapuolet ovat täysi-ikäisiä. Alaikäisille avoliiton osapuolille tehdään erilliset laskelmat, joissa
 - asumismenot on jaettu puoliksi ja
 - perusosana on yhteistaloudessa asuvan perusosa.

Alaikäisen asiakkaan vanhempien elatuskyky tulee selvittää ja myönnetty toimeentulotuki voidaan tarvittaessa määrätä takaisinperittäväksi vanhemmilta. Lue lisää vanhemman elatusvelvollisuudesta .
>ESIMERKKI: Tiia on 17-vuotias ja asuu avoliitossa 18-vuotiaan Miikan kanssa. Koska Tiia on alaikäinen, tehdään kummallekin oma erillinen laskelma. Tiiaa tulee kuulla vanhemmilta saadusta elatuksesta ennen päätöksen antamista ja Tiialle maksettu toimeentulotuki voidaan määrätä takaisinperittäväksi hänen vanhemmiltaan, jos vanhemmat ovat tahallisesti laiminlyöneet elatusvelvollisuutensa.

Jos alaikäisellä on kuitenkin avopuolisonsa kanssa yhteinen lapsi, joka asuu heidän kanssaan, muodostavat he yhteisen toimeentulotukiperheen ja heille tehdään yhteinen laskelma. Tällöinkin alaikäisen avoliiton osapuolen omien vanhempien elatuskyky tulee selvittää.
Jos alaikäinen on solminut avioliiton ja hän asuu yhteistaloudessa aviopuolisonsa kanssa, muodostavat he yhteisen toimeentulotukiperheen ja heille tehdään yhteinen laskelma. Tällöin myös elatusvelvollisuus vanhempien osalta päättyy ja siirtyy aviopuolisolle.
