###### 1.5.2.1.4.b Vuokravakuuden myöntäminen alaikäiselle
Alaikäiselle voidaan poikkeuksellisesti myöntää vuokravakuus
 - kotoutumista edistävän lyhytaikaisen opiskelun vuoksi tai
 - lastensuojelullisen tai jälkihuollon tarpeen vuoksi tai
 - muusta painavasta syystä.

Alaikäisen vuokravakuutta myönnettäessä tulee yhdessä sosiaalitoimen kanssa selvittää muuton perusteet ja alaikäisen kyky selviytyä itsenäisestä asumisesta.
Päätöksen antamisen yhteydessä tulee varmistaa, että hyvinvointialueella, johon alaikäinen muuttaa, on tieto sinne muuttavasta alaikäisestä, jotta alaikäiselle voidaan varmistaa sosiaalihuollon tuki. Asiakkaalta pyydetään lupa siihen, että Kela voi ilmoittaa muutosta hyvinvointialueelle. Jos lupaa ei saada, voidaan ilmoitus tehdä ilman suostumusta edellytysten täyttyessä. Lue lisää sosiaalihuollon tarpeen ilmoituksen tekemisestä .
Lue lisää Takaisinperintä- ja elatusprosessista .
