#### 1.5.7.5 Tapaamisten toteutuminen
Jos asiakas hakee toimeentulotukea lapsen tapaamisesta aiheutuviin kustannuksiin, voi joissain tilanteissa olla tarpeen selvittää tapaamisten toteutumista, sillä perustoimeentulotuessa voidaan huomioida menona vain tosiasiallisesti aiheutuneita kustannuksia. Tapaamisten toteutumisesta ei yleensä tarvita erillistä selvitystä, jos lasta tavataan säännöllisinä tapaamisaikoina eikä ole muuta syytä epäillä tapaamisten toteutumista. Tapaamisten toteutumisesta on kuitenkin esitettävä lisäselvitystä esimerkiksi silloin, jos 
 - säännöllisiä tapaamispäiviä ei ole sovittu, 
 - lasta tavataan lähes joka päivä, 
 - tapaamisesta aiheutuvat kulut ovat huomattavan korkeat tai 
 - on syytä epäillä tapaamisten toteutumista. 

Lisäselvityksenä voidaan pyytää esimerkiksi alla lueteltuja selvityksiä, jotka pyydetään aina asiakkaalta itseltään: 
 - lapsen kanssa asuvan vanhemman tai huoltajan allekirjoittama selvitys tapaamisten toteutumisesta, josta käy ilmi toteutuneiden tapaamispäivien päivämäärät 
 - asiakkaan vapaamuotoinen selvitys tapaamisten toteutumisesta ja tapaamisjärjestelyistä – esimerkiksi missä tapaamiset tapahtuvat, mistä lapsi haetaan ja minne lapsi viedään, kuinka usein tapaamiset toteutuvat sekä kuinka usein ne peruuntuvat 
 - päiväkodin tai koulun selvitys lapsen kulkemisesta päiväkotiin tai kouluun 
 - kopiot matkalipuista, jos niitä ei ole vielä toimitettu 
 - kopiot polttoainekuiteista, jos polttoainekulujen suuren määrän ja asiakkaan tiliotteiden perusteella herää epäilys, ettei polttoainetta osteta yhtä paljon, kuin siihen haetaan tukea. 

