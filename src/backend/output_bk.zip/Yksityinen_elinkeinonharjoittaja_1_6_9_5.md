#### 1.6.9.5 Yksityinen elinkeinonharjoittaja
Yksityinen elinkeinonharjoittaja tekee yritystään koskevat päätökset itsenäisesti ja vastaa kaikella omaisuudellaan yrityksen taloudellisista sitoumuksista. Yksityisen elinkeinonharjoittajan yritystoiminta ei ole yrittäjästä erillinen oikeushenkilö ja yritystoimintaa verotetaan pelkästään yrittäjän tulona. Yksityinen elinkeinonharjoittaja on yritystoiminnastaan kirjanpitovelvollinen. Maatalouden ja kalastuksen elinkeinonharjoittajilla ei kuitenkaan ole kirjanpitovelvollisuutta. Lue lisää maatalousyrittäjistä .
Yksityisen elinkeinonharjoittajan tuloa voi esimerkiksi olla:
 - starttiraha
 - yksityisotot
 - varat jotka olisi mahdollista nostaa kyseisenä kuukautena yksityisottoina
 - yritystilin yksityiskäyttö
 - tavaroiden yksityiskäyttö

Yksityinen elinkeinonharjoittaja ei voi maksaa palkkaa itselleen, puolisolleen eikä yrittäjän alle 15-vuotiaalle lapselle. Yksityinen elinkeinonharjoittaja ei voi myöskään lainata yritykseltään tai yritykselle varoja, koska tässä yritysmuodossa yritystoiminta ei ole yrittäjästä erillinen oikeushenkilö.
Elinkeinonharjoittajan tuloksi katsotaan aina hänen tekemänsä yksityisotot yrityksen varoista sekä hänen nostamansa määrältään olennaiset tai poikkeukselliset kulukorvaukset. Jos yrittäjä on tehnyt yritykseen yksityispanoja tai sijoituksia, ei niitä voida vähentää tehdyistä yksityisotoista, koska ne ovat olleet hänen käytettävissään ainakin sijoittamiskuukautena.
Yksityisen elinkeinonharjoittajan yritystoiminnasta peräisin olevat tulot ja varat eivät ole erillään hänen henkilökohtaisista tuloistaan ja varoistaan. Siten ansiotulona huomioidaan myös ne yrityksen varat, jotka hänen olisi mahdollista nostaa yksityisottoina. Yrityksen rahavarat voidaan yleensä huomioida yrittäjän käytettävissä olevana ansiotulona, kun niistä on ensin vähennetty niihin samalle ajalle kohdistuvat yritystoiminnan menot. Jos yrityksen rahavaroja tulisi kerralla huomioitavaksi yrittäjän ansiotulona suuri määrä, voidaan se tarvittaessa jaksottaa pidemmälle ajalle. Lue lisää yrittäjän tulojen jaksottamisesta.
Jos yritystoiminnalle ei ole erillistä tiliä, vaan yrittäjän henkilökohtainen käyttötili ja yrityksen pankkitili on yksi yhteinen tili, voidaan tilin saldo yleensä huomioida asiakkaan varoina samoin edellytyksin kuin muidenkin toimeentulotuen asiakkaiden tilivarat. Asiakkaan tulona voidaan kuitenkin huomioida varat vain siltä osin, kuin ne ovat hänen omaan elatukseensa käytettävissä. Lue lisää yritystulosta tehtävistä vähennyksistä .
Yksityiseltä elinkeinonharjoittajalta voidaan pyytää esimerkiksi seuraavat selvitykset tulojen ja varojen selvittämiseksi:
 - TO4-lomake
 - yritystoiminnan esitäytetty veroilmoitus
 - yrittäjän ja yrityksen tiliotteet
 - omaisuusluettelo yrityksen varoista
 - kuukausikohtainen kirjanpito
 - kassavirtalaskelma käteisvaroista tai muu selvitys käteisvarojen määrästä ja käytöstä
 - kirjanpitäjän todistus yksityisotoista ja yksityispanoista sekä yritystilin yksityiskäytöstä
 - jos yrityksellä ei ole kirjanpitäjää, pyydetään asiakkaan oma selvitys vastaavista tiedoista.

