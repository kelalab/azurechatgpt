##### 1.7.16.1.d Milloin palvelu päättyy
Moniammatillinen palvelu pyritään päättämään hallitusti sopimalla siitä asiakkaan kanssa. Yleisimmät palvelun päättymistilanteet ovat seuraavanlaisia:
 - asiakkaan tilanne on edennyt siinä määrin parempaan suuntaan, että hän pärjää Kelan peruspalvelulla tai ei tarvitse palveluita enää ollenkaan
 - vastuu asiakkaan asiasta siirretään sovitusti jollekin yhteystyökumppanille
 - emme pysty Kelassa auttamaan asiakasta enempää

Asiakas voi myös koska tahansa perua suostumuksensa yhteistyöhön Kelan kumppaneiden kanssa ja/tai ilmoittaa, ettei halua enää moniammatillista palvelua.
Moniammatillisen palvelun päättymisen jälkeen asiakkaan asiat hoidetaan peruspalvelussa. Jos asiakkaalla on myöhemmin uudelleen tarvetta moniammatilliselle palvelulle, asia käynnistyy samalla tavalla keskustelulla asiantuntijan kanssa, kuten edelliselläkin kerralla.