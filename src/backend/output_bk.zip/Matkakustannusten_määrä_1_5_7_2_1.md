##### 1.5.7.2.1 Matkakustannusten määrä
Matkakustannukset huomioidaan edullisimman kulkuneuvon mukaan. Valittaessa matkustustapaa (esimerkiksi linja-auto, metro, juna, lentokone sekä kulkuneuvon vaihtaminen) tulee arvioida myös sitä, millä matkustustavalla matkustaminen ei muodostu lapselle kohtuuttoman raskaaksi ja siten vaaranna tapaamisoikeuden toteutumista. Harkinnassa otetaan huomioon esimerkiksi: 
 - lapsen ikä ja kehitystaso, 
 - matka-aika sekä 
 - kokonaisrasitus. 

Yleensä matkakustannukset huomioidaan jälkikäteen tositteita vastaan. Kuitteja ei kuitenkaan tarvita, jos asiakkaalle myönnetään matkakuluihin maksusitoumus. Lisäksi Kela voi tilata VR:n lipun tai lentolipun asiakkaan puolesta. 
Hakemiskuukaudelta voidaan huomioida yleensä enintään lapsen perusosaa vastaavan määrän verran tapaamiskustannuksia eli tosiasiallisia matkakustannuksia ja ruokarahaa yhteensä. Jos kustannukset on vahvistettu jaettavan lasta tapaavan vanhemman ja lapsen kanssa asuvan vanhemman tai huoltajan kesken, huomioidaan asiakkaalle yleensä lapsen tapaamismenona enintään puolet lapsen perusosaa vastaavasta määrästä 
Oman auton käytöstä aiheutuvat kustannukset hyväksytään menona vain erityisestä syystä. Erityisenä syynä voidaan pitää sitä, että 
 - lasta tapaavan vanhemman tai lapsen kotiin on enemmän kuin alle 2 kilometrin kävelymatka julkisilta kulkuneuvoilta tai 
 - jos kävelymatka on alle 2 kilometriä, voidaan oman auton käyttö hyväksyä myös lapsen tai tarvittavan saattajan terveydellisillä syillä, esimerkiksi lapsen tai tarvittavan saattajan vaikea liikuntarajoite, kuten pyörätuoli. 

Jos matkakustannukset tulevat huomioitavaksi oman auton käytön mukaisina, selvitetään tosiasialliset kustannukset yleensä pyytämällä asiakkaan arvio aiheutuneista matkakuluista. Matkakustannuksia voidaan huomioida enintään 0,20 e/km 30.6.2022 asti ja 0,33 e/km 1.7.2022 alkaen. Menona huomioidaan kuitenkin vain tosiasiallisesti aiheutuneet matkakustannukset. Jos oman auton käytölle ei ole erityistä syytä, mutta asiakas ei halua käyttää julkista kulkuneuvoa, voidaan jälkikäteen matkakustannukset huomioida menona edullisimman kulkuneuvon mukaisesti toteutuneilta tapaamispäiviltä. Lue lisää matkakustannusten huomioimisesta . 

>ESIMERKKI: Martti tapaa 4-vuotiasta lastaan joka toinen viikonloppu omassa kodissaan. Lapsi tarvitsee iän puolesta saattajan ja Martille hyväksytään oman auton käyttö pyörätuolin vuoksi. Martti asuu Rovaniemellä ja lapsi asuu Kemissä. Martti hakee toimeentulotukea matkakuluihin. Martilta kysytään, kuinka paljon hänelle aiheutuu tosiasiallisesti matkakuluja. Koska Martin esittämiä kuluja voidaan pitää kohtuullisina matkan pituus huomioiden ja Martti on ne itse tosiasiallisesti maksanut, voidaan Martin esittämien matkakulujen määrä huomioida laskelmalla menona. 

>ESIMERKKI: Raisa tapaa sopimuksen mukaan 10-vuotiasta lastaan joka toinen viikonloppu Raisan kotona Espoossa. Raisa kuitenkin tapaa lasta lapsen kotona Turussa ja Raisa haluaa kulkea matkat omalla autolla. Oman auton käytöstä aiheutuvia kustannuksia ei hyväksytä menona ilman erityistä syytä. Raisa ilmoittaa helmikuussa, että hän on tavannut lastaan tammikuun aikana. Koska oman auton käytöstä aiheutuvia kustannuksia ei voida pitää välttämättöminä ja tapaamissopimuksen mukaan lapsi matkustaa Espooseen, voidaan Raisan tammikuun menoksi huomioida edullisimman kulkuneuvon, kuten lapsen junalippujen, mukaiset matkakustannukset toteutuneiden tapaamispäivien osalta.

