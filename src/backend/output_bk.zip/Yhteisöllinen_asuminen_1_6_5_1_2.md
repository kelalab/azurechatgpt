##### 1.6.5.1.2 Yhteisöllinen asuminen
Yhteisöllisellä asumisella tarkoitetaan hyvinvointialueen järjestämää asumista esteettömässä ja turvallisessa asumisyksikössä, jossa henkilön hallinnassa on hänen tarpeitaan vastaava asunto ja jossa asukkaille on tarjolla sosiaalista kanssakäymistä edistävää toimintaa. 
Yhteisöllistä asumista järjestetään henkilölle, jonka 
 - toimintakykynsä on alentunut ja 
 - hoidon ja huolenpidon tarve on kohonnut korkean iän, sairauden, vamman tai muun vastaavaan syyn vuoksi 

Yhteisöllisessä asumisessa hyvinvointialue perii sosiaalihuoltolain mukaisen tulosidonnaisen kuukausimaksun, joka määräytyy:
 - palvelupäätökseen kirjattujen palvelutuntien määrän,
 - asiakkaan maksukyvyn ja
 - perheen koon mukaan.

Kuukausimaksuun sisältyy hoidon lisäksi sellaiset asiakassuunnitelman mukaiset jatkuvaluonteisesti ja säännöllisesti annettavat palvelut, jotka liittyvät kiinteästi hoitoon ja huolenpitoon. Maksuun ei sisälly asumiskustannuksia tai lääkemenoja.
Perustoimeentulotuessa voidaan huomioida palveluista ne menot, jotka kuuluvat muihin perusmenoihin:
 - terveydenhuoltoon liittyvät hoidon ja huolenpidon menot esimerkiksi saunottamis- ja peseytymispalveluta 
 - asumismenot 

 
Tukipalvelut 
Hyvinvointialue voi järjestää tukipalveluita ja periä niistä erillisen maksun. Tukipalveluita ovat: 
 - ateriapalvelu 
 - vaatehuoltopalvelu 
 - siivouspalvelu 
 - asiointipalvelu 
 - osallisuutta ja sosiaalista kanssakäymistä edistävä tai tukeva palvelut. 

Tukipalveluita ei huomioida menona, sillä ne sisältyvät perusosaan. Poikkeuksellisesti tukipalveluista aiheutuvia menoja voidaan asiakkaan pyynnöstä siirtää suoraan hyvinvointialueelle käsiteltäväksi. 
 
Turvapalvelut 
Turvapalvelut tai turva-auttamispalvelut (turvapuhelin, turvaranneke ja hälytyskäynnit) voidaan huomioida menona 
 - kun käytölle on todettu terveysperuste ja 
 - maksu peritään hyvinvointialueen asiakasmaksun yhteydessä tai 
 - hyvinvointialueen ostopalveluntuottajan laskuttamana. 

Asiakkaan itse hankkimia turvapalveluja yksityisiltä palvelujentuottajilta ei huomioida menona. 

Jos palvelut, joista asiakas- ja palvelumaksut peritään, eivät kuulu muihin perusmenoihin tai ne sisältyvät perusosaan, niitä ei huomioida menoina perustoimeentulotuessa. Tällaisia menoja ovat esimerkiksi:
 - ateriapalvelumaksut,
 - siivouspalvelut ja
 - sosiaalista kanssakäymistä tukevat palvelut.

Poikkeuksellisesti näitä avopalveluista syntyviä kuukausittain toistuvia menoja voidaan asiakkaan pyynnöstä siirtää suoraan hyvinvointialueelle käsiteltäväksi.
Perustoimeentulotuen hakemuksen ratkaisemiseksi tarvitaan seuraavat liitteet:
 - asiakasmaksupäätös sekä
 - erittelyt palveluun liittyvistä menoista, jos erittelyä ei ole asiakasmaksupäätöksessä. Erittelyistä pitää käydä ilmi eri palveluiden osuudet euroissa tai niiden prosenttiosuudet koko maksun määrästä.

Jos asiakasmaksun sisällöstä ei saada riittäviä tietoja, ei asiakasmaksua huomioida menona.
Jos toinen puoliso asuu kotona ja toinen asumisyksikössä, puolisoille tehdään erilliset päätökset ja käytetään molemmilla yksin asuvan perusosaa. Jos hakijan aviopuoliso on selvästi suurituloisempi, tulee aviopuolison elatuskyky selvittää. Jos molemmat aviopuolisot saavat toimeentulotukea, ei elatuskykyä yleensä ole eikä asiaa tarvitse selvittää enempää.
Lue lisää avo- ja laitospalvelut prosessista ja asumismenoista siirryttäessä avo- tai laitospalveluihin .
