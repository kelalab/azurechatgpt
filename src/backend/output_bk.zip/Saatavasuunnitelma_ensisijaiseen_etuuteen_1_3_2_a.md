#### 1.3.2.a Saatavasuunnitelma ensisijaiseen etuuteen
Ensisijaiset Kelan etuudet on aina ratkaistava ennen toimeentulotukihakemuksen ratkaisemista, kun se on mahdollista. Toimeentulotuen hakemuksen käsittely ei kuitenkaan saa viivästyä tämän vuoksi.
Jos hakijalla ei ole ensisijaista etuutta maksussa, toimeentulotuki voidaan periä suoraan henkilölle tulevasta etuudesta kuittaamalla eli tekemällä saatavasuunnitelma.
Lue lisää saatavasuunnitelman tekemisestä .
