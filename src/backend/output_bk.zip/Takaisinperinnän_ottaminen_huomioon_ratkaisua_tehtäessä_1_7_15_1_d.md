##### 1.7.15.1.d Takaisinperinnän ottaminen huomioon ratkaisua tehtäessä
Perustoimeentulotuen päätöstä tehtäessä, selvitetään aina, onko myöhemmässä vaiheessa mahdollista periä tuki takaisin esimerkiksi tulevista tuloista tai varallisuuden realisoinnista. Takaisinperinnästä on aina päätettävä jo silloin, kun tukea myönnetään. 
Alaikäisen kohdalla mahdollinen takaisinperintä voi kohdistua hänen vanhempiinsa. Ennen ratkaisun tekoa selvitetään, onko vanhempien tosiasiallisesti mahdollista vastata lapsensa elatuksesta. Tällöin selvitetään heidän vuositulonsa ja varallisuutensa verotustiedoista ja pyydetään tarvittaessa selvitys asiaan. Jos vanhemmat ovat pitkäaikaisia toimeentulotuen saajia, takaisinperintää ei tehdä. 
Lue lisää takaisinperintämenettelystä ja elatusvelvollisuudesta . 
