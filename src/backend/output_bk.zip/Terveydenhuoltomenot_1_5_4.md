### 1.5.4 Terveydenhuoltomenot
Terveydenhuoltomenoja katetaan sekä toimeentulotuen perusosalla, että muina perus-menoina.
Vähäiset terveydenhuoltomenot sisältyvät toimeentulotuen perusosaan, eikä niitä hyväksytä erikseen menoina. Tällaisia menoja ovat esimerkiksi ilman lääkärin määräystä ostettavat käsikauppalääkkeet ja -valmisteet, perusvoiteet, vitamiinit ja laastarit.
Perustoimeentulotuessa voidaan perusosan lisäksi muina perusmenoina ottaa huomioon terveydenhuoltomenoja todellisen suuruisina, jos niitä ei ole korvattu muista ensisijaisista järjestelmistä, kuten esimerkiksi sairausvakuutuksesta. Tällaisia menoja ovat esimerkiksi:
 - terveydenhuollon ammattihenkilön määräyksellä hankitut lääkkeet ja haavanhoitotuotteet
 - terveydenhuollon asiakasmaksut
 - silmälasien hankintamenot

Toimeentulotuessa huomioon otettavien terveyden- ja sairaanhoidon maksujen osalta edellytetään yleensä, että palvelut ovat julkisen terveydenhuollon itse tuottamia tai ostamia.
