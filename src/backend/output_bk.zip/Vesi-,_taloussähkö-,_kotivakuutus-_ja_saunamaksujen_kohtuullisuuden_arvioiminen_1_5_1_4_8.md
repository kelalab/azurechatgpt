##### 1.5.1.4.8 Vesi-, taloussähkö-, kotivakuutus- ja saunamaksujen kohtuullisuuden arvioiminen
Taloussähkö- ja vesinormi määräytyy asunnossa asuvien henkilöiden todellisen lukumäärän mukaisesti, koska taloussähkö- ja vesimaksujen määrä perustuu kulutukseen.
Yleensä vesi-, taloussähkö ja kotivakuusmaksut huomioidaan todellisen kulutuksen mukaisesti. Kelassa on käytössä näille kohtuullisen kulutuksen mukaiset normit, jotka määräytyvät perheen henkilöluvun mukaisesti.

