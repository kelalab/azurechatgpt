### 1.3.1 Varautumisvelvollisuus
Hakijalla ja hänen perheellään on velvollisuus kykynsä mukaan pitää huolta omasta elatuksestaan. Tähän velvollisuuteen voidaan katsoa sisältyvän myös varautumisen velvollisuus. 
Varautumisvelvollisuudesta kerrotaan hakijalle päätöksellä, jotta hän voi varautua säästämään tuloja ja varoja elatukseensa pidemmän ajan. Hakija ei voi tarkoituksellisesti kuluttaa tulojaan haluamallaan tavalla. Näin toimeentulotuessa tulojen jakaminen useammalle kuukaudelle tai tulojen jälkikäteinen huomioiminen ei muodostu hakijalle yllättäväksi tai kohtuuttomaksi. 
Yleensä tulot otetaan huomioon siltä ajanjaksolta, jolta toimeentulotuki määrätään. Tulo voidaan kuitenkin jakaa myös eriin ja ottaa huomioon useamman etuusjakson aikana, jos se on
 - tulon kertaluonteisuus,
 - tulon saamisen peruste tai
 - käyttötarkoitus

huomioon ottaen on kohtuullista.
Tulo, joka ei ole ollut tiedossa toimeentulotukipäätöstä tehtäessä, voidaan ottaa jälkikäteen huomioon tulona, jos toimeentulotukea haetaan päätöstä seuraavien kahden ensimmäisen kalenterikuukauden aikana, jollei sitä voida pitää kohtuuttomana. Hakijalle ilmoitetaan päätöksessä, miten tulo huomioidaan jälkikäteen. Katso lisää tulo ei ole ollut tiedossa toimeentulotuesta päätettäessä.

Katso myös tulojen jakaminen osiin .

