#### 1.3.2.1 Työttömyysetuus
Työttömyysetuus eli työmarkkinatuki, peruspäiväraha ja ansiopäiväraha otetaan perustoimeentulotuessa tulona huomioon.
Tulona ei kuitenkaan huomioida
 - työttömyysetuutta saavan hakijan kulukorvausta
 - korotusosaa tai korotettua ansio-osaa, jota maksetaan työllistymistä edistävään palveluun osallistumisesta

Työttömyysetuuden lapsikorotus huomioidaan tulona. Poikkeuksena tästä on tilanne, jossa Kela kuittaa lapsikorotuksen elatusapusaatavaan.
Jos hakijalla on oikeus työttömyysetuuteen, sen voidaan katsoa olevan käytettävissä olevaa tuloa ensimmäisestä mahdollisesta maksupäivästä lukien, vaikka hakija ei omasta valinnastaan johtuen hae etuutta maksuun jättämällä ilmoitusta työttömyysajasta. Hakijalle myönnetty työttömyysetuus huomioidaan tulona sille päivälle, jolloin hän olisi aikaisintaan sen voinut saada.
>ESIMERKKI: Maaritin seuraava työttömyysajan ilmoituksen maksukausi on 8.6.-5.7. Maarit olisi voinut toimittaa työttömyysajan ilmoituksen Kelaan aikaisintaan 6.7. ja etuus olisi maksuerien perusteella käytettävissä 8.7. Maarit ei kuitenkaan ole vielä toimittanut työttömyysajan ilmoitusta, kun 20.7. toimeentulotuen jatkohakemusta heinäkuulle ratkaistaan. Heinäkuun tuloksi otetaan huomioon 20 työttömyysetuuspäivän maksukausi työmarkkinatukea, koska sen voidaan katsoa olevan Maaritin käytettävissä olevaa tuloa.

Katso myös työttömyysetuuden huomioiminen tulona ja työvoimapoliittiset lausunnot .
